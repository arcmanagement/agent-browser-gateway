"use strict";
(() => {
  // src/browserAdapter.ts
  function runtimeBrowser() {
    const globals = globalThis;
    const api = globals.browser ?? globals.chrome;
    if (!api) {
      throw new Error("No WebExtension browser API is available.");
    }
    return api;
  }
  function configuredKind() {
    return true ? "chrome" : "chrome";
  }
  function noopEvent() {
    return {
      addListener() {
      },
      removeListener() {
      },
      hasListener() {
        return false;
      },
      hasListeners() {
        return false;
      }
    };
  }
  function unsupportedDebugger() {
    const unavailable = async () => {
      throw new Error("The browser debugger API is not available in this target.");
    };
    return {
      attach: unavailable,
      detach: unavailable,
      sendCommand: unavailable,
      onDetach: noopEvent(),
      onEvent: noopEvent()
    };
  }
  function createLazyBrowserAdapter(kind) {
    return {
      get kind() {
        return kind;
      },
      get supportsDebugger() {
        return !!runtimeBrowser().debugger;
      },
      get supportsVisibleTabCapture() {
        return typeof runtimeBrowser().tabs?.captureVisibleTab === "function";
      },
      get action() {
        return runtimeBrowser().action;
      },
      get alarms() {
        return runtimeBrowser().alarms;
      },
      get debugger() {
        return runtimeBrowser().debugger ?? unsupportedDebugger();
      },
      get downloads() {
        return runtimeBrowser().downloads;
      },
      get extension() {
        return runtimeBrowser().extension ?? {
          isAllowedIncognitoAccess: async () => true
        };
      },
      get permissions() {
        return runtimeBrowser().permissions;
      },
      get runtime() {
        return runtimeBrowser().runtime;
      },
      get scripting() {
        return runtimeBrowser().scripting;
      },
      get storage() {
        return runtimeBrowser().storage;
      },
      get tabs() {
        return runtimeBrowser().tabs;
      },
      get windows() {
        return runtimeBrowser().windows;
      }
    };
  }
  var chromeBrowserAdapter = createLazyBrowserAdapter("chrome");
  var browserAdapter = createLazyBrowserAdapter(configuredKind());

  // src/popupLogic.ts
  function trustedAutomationNote(settings) {
    if (!settings.trustedAutomationEnabled) {
      return "When enabled, eval on shared tabs can skip the local approval popup. Scripts are still audited.";
    }
    return settings.evalEnabled ? "AutoMode is active: eval skips local approval popups for shared tabs and is still audited." : "AutoMode is active but eval is disabled until the eval switch is enabled.";
  }
  function allTabsAccessNote(settings, allTabsAccess) {
    if (allTabsAccess.active) {
      return `${allTabsAccess.shareableTabCount} tabs are shared in sandbox mode. Browser-owned automation controls are enabled for this isolated profile.`;
    }
    if (settings.allTabsAccessEnabled && !allTabsAccess.permissionGranted) {
      return "Chrome permission is missing. Toggle this on to re-authorize.";
    }
    return "For isolated sandbox profiles only. Do not enable this in mixed personal profiles.";
  }
  function annotationButtonLabel(annotationState) {
    const suffix = annotationState.count === 1 ? "" : "s";
    if (annotationState.enabled) return `${annotationState.count} annotation${suffix} - Done`;
    if (annotationState.count > 0) return `${annotationState.count} annotation${suffix} - Resume`;
    return "Annotate this tab";
  }
  function sharedTabSummary(tab) {
    return `${tab.accessMode === "all_tabs" ? "\u{1F310}" : "\u{1F513}"} [${tab.tabId}] ${tab.title || tab.url}`;
  }

  // src/popup.ts
  var browser = browserAdapter;
  var tabInfoEl = document.getElementById("tabInfo");
  var actionBtn = document.getElementById("actionBtn");
  var annotationBtn = document.getElementById("annotationBtn");
  var clearAnnotationsBtn = document.getElementById("clearAnnotationsBtn");
  var approvalToggleEl = document.getElementById("approvalToggle");
  var evalToggleEl = document.getElementById("evalToggle");
  var trustedAutomationToggleEl = document.getElementById(
    "trustedAutomationToggle"
  );
  var trustedAutomationNoteEl = document.getElementById("trustedAutomationNote");
  var allTabsToggleEl = document.getElementById("allTabsToggle");
  var allTabsNoteEl = document.getElementById("allTabsNote");
  var profileLabelEl = document.getElementById("profileLabel");
  var statusEl = document.getElementById("status");
  var sharedListEl = document.getElementById("sharedList");
  var incognitoNoticeEl = document.getElementById("incognitoNotice");
  var openExtensionsBtn = document.getElementById("openExtensionsBtn");
  var profileLabelTimer = null;
  async function send(msg) {
    return await browser.runtime.sendMessage(msg);
  }
  async function openExtensionSettings() {
    await browser.tabs.create({ url: `chrome://extensions/?id=${browser.runtime.id}` });
    window.close();
  }
  async function requestAllTabsPermission() {
    return await browser.permissions.request({ origins: ["<all_urls>"] });
  }
  async function removeAllTabsPermission() {
    await browser.permissions.remove({ origins: ["<all_urls>"] }).catch(() => false);
  }
  async function refresh() {
    const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      tabInfoEl.textContent = "(no active tab)";
      actionBtn.disabled = true;
      return;
    }
    const tabId = tab.id;
    tabInfoEl.textContent = tab.title ?? tab.url ?? "(untitled)";
    const state = await send({ type: "get_state", tabId });
    if (state.type !== "state") {
      statusEl.textContent = state.type === "error" ? state.message : "unknown state";
      return;
    }
    approvalToggleEl.checked = state.settings.operationsRequireApproval;
    approvalToggleEl.disabled = false;
    approvalToggleEl.onchange = async () => {
      const nextValue = approvalToggleEl.checked;
      approvalToggleEl.disabled = true;
      const response = await send({
        type: "set_operations_require_approval",
        value: nextValue
      });
      if (response.type === "error") {
        approvalToggleEl.checked = !nextValue;
        statusEl.textContent = `error: ${response.message}`;
      }
      approvalToggleEl.disabled = false;
    };
    evalToggleEl.checked = state.settings.evalEnabled;
    evalToggleEl.disabled = false;
    evalToggleEl.onchange = async () => {
      const nextValue = evalToggleEl.checked;
      evalToggleEl.disabled = true;
      const response = await send({
        type: "set_eval_enabled",
        value: nextValue
      });
      if (response.type === "error") {
        evalToggleEl.checked = !nextValue;
        statusEl.textContent = `error: ${response.message}`;
      }
      evalToggleEl.disabled = false;
    };
    trustedAutomationToggleEl.checked = state.settings.trustedAutomationEnabled;
    trustedAutomationToggleEl.disabled = false;
    trustedAutomationNoteEl.textContent = trustedAutomationNote(state.settings);
    trustedAutomationToggleEl.onchange = async () => {
      const nextValue = trustedAutomationToggleEl.checked;
      trustedAutomationToggleEl.disabled = true;
      const response = await send({
        type: "set_trusted_automation_enabled",
        value: nextValue
      });
      if (response.type === "error") {
        trustedAutomationToggleEl.checked = !nextValue;
        statusEl.textContent = `error: ${response.message}`;
      }
      trustedAutomationToggleEl.disabled = false;
      await refresh();
    };
    allTabsToggleEl.checked = state.allTabsAccess.active;
    allTabsToggleEl.disabled = false;
    allTabsNoteEl.textContent = allTabsAccessNote(state.settings, state.allTabsAccess);
    allTabsToggleEl.onchange = async () => {
      const nextValue = allTabsToggleEl.checked;
      allTabsToggleEl.disabled = true;
      if (nextValue) {
        const granted = await requestAllTabsPermission();
        if (!granted) {
          allTabsToggleEl.checked = false;
          allTabsNoteEl.textContent = "All-tabs permission was not granted.";
          allTabsToggleEl.disabled = false;
          return;
        }
      }
      const response = await send({
        type: "set_all_tabs_access",
        value: nextValue
      });
      if (response.type === "error") {
        allTabsToggleEl.checked = !nextValue;
        statusEl.textContent = `error: ${response.message}`;
        if (nextValue) await removeAllTabsPermission();
        allTabsToggleEl.disabled = false;
        return;
      } else if (!nextValue) {
        await removeAllTabsPermission();
      }
      allTabsToggleEl.disabled = false;
      await refresh();
    };
    if (document.activeElement !== profileLabelEl) {
      profileLabelEl.value = state.settings.profileLabel;
    }
    profileLabelEl.oninput = () => {
      if (profileLabelTimer !== null) clearTimeout(profileLabelTimer);
      profileLabelTimer = setTimeout(async () => {
        profileLabelTimer = null;
        const response = await send({ type: "set_profile_label", value: profileLabelEl.value });
        if (response.type === "error") {
          statusEl.textContent = `error: ${response.message}`;
        }
      }, 350);
    };
    const incognitoAccessAllowed = state.activeTab.incognitoAccessAllowed;
    const incognitoBlocked = state.activeTab.incognito && !incognitoAccessAllowed;
    const allTabsActive = state.allTabsAccess.active;
    incognitoNoticeEl.hidden = incognitoAccessAllowed;
    openExtensionsBtn.onclick = async () => {
      await openExtensionSettings();
    };
    if (allTabsActive) {
      actionBtn.textContent = "Disable all-tabs access";
      actionBtn.className = "danger";
      actionBtn.disabled = false;
      actionBtn.onclick = async () => {
        actionBtn.disabled = true;
        allTabsToggleEl.checked = false;
        const response = await send({ type: "set_all_tabs_access", value: false });
        if (response.type === "error") {
          statusEl.textContent = `error: ${response.message}`;
          actionBtn.disabled = false;
          return;
        }
        await removeAllTabsPermission();
        await refresh();
      };
      annotationBtn.disabled = !state.permitted;
      annotationBtn.textContent = annotationButtonLabel(state.annotationState);
      annotationBtn.className = state.annotationState.enabled ? "annotation-on" : "secondary";
      annotationBtn.onclick = async () => {
        if (!state.permitted) return;
        annotationBtn.disabled = true;
        const response = await send({
          type: "annotation_action",
          tabId,
          action: state.annotationState.enabled ? "stop" : "start"
        });
        if (response.type === "error") {
          statusEl.textContent = `error: ${response.message}`;
          annotationBtn.disabled = false;
          return;
        }
        window.close();
        await refresh();
      };
      clearAnnotationsBtn.disabled = !state.permitted || state.annotationState.count === 0;
      clearAnnotationsBtn.onclick = async () => {
        if (!state.permitted) return;
        clearAnnotationsBtn.disabled = true;
        await send({ type: "annotation_action", tabId, action: "clear" });
        await refresh();
      };
    } else if (incognitoBlocked) {
      actionBtn.textContent = "Enable incognito access first";
      actionBtn.className = "secondary";
      actionBtn.disabled = false;
      actionBtn.onclick = async () => {
        await openExtensionSettings();
      };
      annotationBtn.disabled = true;
      annotationBtn.textContent = "Annotate this tab";
      annotationBtn.className = "secondary";
      clearAnnotationsBtn.disabled = true;
    } else if (state.permitted) {
      actionBtn.textContent = "Revoke this tab";
      actionBtn.className = "danger";
      actionBtn.disabled = false;
      actionBtn.onclick = async () => {
        await send({ type: "revoke", tabId });
        await refresh();
      };
      annotationBtn.disabled = false;
      annotationBtn.textContent = annotationButtonLabel(state.annotationState);
      annotationBtn.className = state.annotationState.enabled ? "annotation-on" : "secondary";
      annotationBtn.onclick = async () => {
        annotationBtn.disabled = true;
        const response = await send({
          type: "annotation_action",
          tabId,
          action: state.annotationState.enabled ? "stop" : "start"
        });
        if (response.type === "error") {
          statusEl.textContent = `error: ${response.message}`;
          annotationBtn.disabled = false;
          return;
        }
        window.close();
        await refresh();
      };
      clearAnnotationsBtn.disabled = state.annotationState.count === 0;
      clearAnnotationsBtn.onclick = async () => {
        clearAnnotationsBtn.disabled = true;
        await send({ type: "annotation_action", tabId, action: "clear" });
        await refresh();
      };
    } else {
      actionBtn.textContent = "Share this tab with agent";
      actionBtn.className = "primary";
      actionBtn.disabled = false;
      actionBtn.onclick = async () => {
        await send({ type: "permit", tabId });
        await refresh();
      };
      annotationBtn.disabled = true;
      annotationBtn.textContent = "Annotate this tab";
      annotationBtn.className = "secondary";
      clearAnnotationsBtn.disabled = true;
    }
    statusEl.replaceChildren();
    const wsStateEl = document.createElement("span");
    wsStateEl.className = state.wsConnected ? "ws-ok" : "ws-err";
    wsStateEl.textContent = state.wsConnected ? "\u25CF Gateway connected" : "\u25CF Gateway disconnected";
    statusEl.append(wsStateEl);
    if (state.sharedTabs.length > 0) {
      const heading = document.createElement("h2");
      heading.textContent = `Shared tabs (${state.sharedTabs.length})`;
      const items = state.sharedTabs.map((t) => {
        const item = document.createElement("div");
        item.className = "shared-item";
        item.textContent = sharedTabSummary(t);
        return item;
      });
      sharedListEl.replaceChildren(heading, ...items);
    } else {
      sharedListEl.replaceChildren();
    }
  }
  refresh().catch((e) => {
    statusEl.textContent = `error: ${e}`;
  });
})();
