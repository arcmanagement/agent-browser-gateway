"use strict";
(() => {
  // src/approvalLogic.ts
  function approvalRemainingMs(createdAt, timeoutMs, nowMs = Date.now()) {
    return Math.max(0, createdAt + timeoutMs - nowMs);
  }
  function scriptBlockPresentation(script) {
    return script === void 0 ? { hidden: true, text: "" } : { hidden: false, text: script };
  }

  // src/browserAdapter.ts
  function runtimeBrowser() {
    const globals = globalThis;
    const api = globals.browser ?? globals.chrome;
    if (!api) {
      throw new Error("No WebExtension browser API is available.");
    }
    return api;
  }
  function configuredKind() {
    return true ? "chrome" : "chrome";
  }
  function noopEvent() {
    return {
      addListener() {
      },
      removeListener() {
      },
      hasListener() {
        return false;
      },
      hasListeners() {
        return false;
      }
    };
  }
  function unsupportedDebugger() {
    const unavailable = async () => {
      throw new Error("The browser debugger API is not available in this target.");
    };
    return {
      attach: unavailable,
      detach: unavailable,
      sendCommand: unavailable,
      onDetach: noopEvent(),
      onEvent: noopEvent()
    };
  }
  function extensionAccessApi(api) {
    const extensionApi = api.extension;
    return {
      isAllowedFileSchemeAccess: typeof extensionApi?.isAllowedFileSchemeAccess === "function" ? () => extensionApi.isAllowedFileSchemeAccess?.() ?? Promise.resolve(true) : async () => true,
      isAllowedIncognitoAccess: typeof extensionApi?.isAllowedIncognitoAccess === "function" ? () => extensionApi.isAllowedIncognitoAccess?.() ?? Promise.resolve(true) : async () => true
    };
  }
  function createLazyBrowserAdapter(kind) {
    return {
      get kind() {
        return kind;
      },
      get supportsDebugger() {
        return !!runtimeBrowser().debugger;
      },
      get supportsVisibleTabCapture() {
        return typeof runtimeBrowser().tabs?.captureVisibleTab === "function";
      },
      get action() {
        return runtimeBrowser().action;
      },
      get alarms() {
        return runtimeBrowser().alarms;
      },
      get debugger() {
        return runtimeBrowser().debugger ?? unsupportedDebugger();
      },
      get downloads() {
        return runtimeBrowser().downloads;
      },
      get bookmarks() {
        return runtimeBrowser().bookmarks;
      },
      get extension() {
        return extensionAccessApi(runtimeBrowser());
      },
      get permissions() {
        return runtimeBrowser().permissions;
      },
      get runtime() {
        return runtimeBrowser().runtime;
      },
      get scripting() {
        return runtimeBrowser().scripting;
      },
      get storage() {
        return runtimeBrowser().storage;
      },
      get tabs() {
        return runtimeBrowser().tabs;
      },
      get windows() {
        return runtimeBrowser().windows;
      },
      get readingList() {
        return runtimeBrowser().readingList;
      }
    };
  }
  var chromeBrowserAdapter = createLazyBrowserAdapter("chrome");
  var browserAdapter = createLazyBrowserAdapter(configuredKind());

  // src/approval.ts
  var browser = browserAdapter;
  var intentEl = document.getElementById("intent");
  var tabTitleEl = document.getElementById("tabTitle");
  var tabUrlEl = document.getElementById("tabUrl");
  var scriptBlockEl = document.getElementById("scriptBlock");
  var allowBtn = document.getElementById("allowBtn");
  var denyBtn = document.getElementById("denyBtn");
  var statusEl = document.getElementById("status");
  var approvalId = new URLSearchParams(window.location.search).get("id");
  var submitted = false;
  var timeoutId = null;
  var currentMethod = null;
  var currentTabId = null;
  async function send(msg) {
    return await browser.runtime.sendMessage(msg);
  }
  async function decide(decision, streamId) {
    if (!approvalId || submitted) return;
    submitted = true;
    if (timeoutId !== null) {
      clearTimeout(timeoutId);
      timeoutId = null;
    }
    allowBtn.disabled = true;
    denyBtn.disabled = true;
    statusEl.textContent = "Submitting decision...";
    try {
      await send({ type: "approval_decision", approvalId, decision, streamId });
    } finally {
      window.close();
    }
  }
  function getTabStreamId(targetTabId) {
    return new Promise((resolve, reject) => {
      chrome.tabCapture.getMediaStreamId({ targetTabId }, (streamId) => {
        const err = chrome.runtime.lastError;
        if (err || !streamId) reject(new Error(err?.message ?? "could not start tab capture"));
        else resolve(streamId);
      });
    });
  }
  async function load() {
    if (!approvalId) {
      showError("approval request missing");
      return;
    }
    const response = await send({ type: "get_approval_request", approvalId });
    if (response.type !== "approval_request") {
      showError(response.type === "error" ? response.message : "approval request unavailable");
      return;
    }
    const { request } = response;
    currentMethod = request.method;
    currentTabId = request.tab.tabId;
    intentEl.textContent = request.intent;
    tabTitleEl.textContent = request.tab.title || "(untitled)";
    tabUrlEl.textContent = request.tab.url || "(no URL)";
    const scriptBlock = scriptBlockPresentation(request.script);
    scriptBlockEl.textContent = scriptBlock.text;
    scriptBlockEl.hidden = scriptBlock.hidden;
    allowBtn.disabled = false;
    denyBtn.disabled = false;
    const remainingMs = approvalRemainingMs(request.createdAt, request.timeoutMs);
    statusEl.textContent = "This request expires in 60 seconds.";
    timeoutId = setTimeout(() => {
      decide("timeout").catch((e) => {
        showError(e instanceof Error ? e.message : String(e));
      });
    }, remainingMs);
  }
  function showError(message) {
    intentEl.textContent = "Unable to load approval request.";
    tabTitleEl.textContent = "";
    tabUrlEl.textContent = "";
    scriptBlockEl.textContent = "";
    scriptBlockEl.hidden = true;
    statusEl.textContent = message;
    allowBtn.disabled = true;
    denyBtn.disabled = true;
  }
  allowBtn.onclick = () => {
    if (currentMethod === "record_start" && currentTabId !== null) {
      let streamIdPromise;
      try {
        streamIdPromise = getTabStreamId(currentTabId);
      } catch (e) {
        showError(e instanceof Error ? e.message : String(e));
        return;
      }
      streamIdPromise.then((streamId) => decide("allow", streamId)).catch((e) => showError(e instanceof Error ? e.message : String(e)));
      return;
    }
    decide("allow").catch((e) => {
      showError(e instanceof Error ? e.message : String(e));
    });
  };
  denyBtn.onclick = () => {
    decide("deny").catch((e) => {
      showError(e instanceof Error ? e.message : String(e));
    });
  };
  load().catch((e) => {
    showError(e instanceof Error ? e.message : String(e));
  });
})();
