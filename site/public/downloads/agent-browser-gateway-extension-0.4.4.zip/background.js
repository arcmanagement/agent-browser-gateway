// src/browserAdapter.ts
function runtimeBrowser() {
  const globals = globalThis;
  const api = globals.browser ?? globals.chrome;
  if (!api) {
    throw new Error("No WebExtension browser API is available.");
  }
  return api;
}
function configuredKind() {
  return true ? "chrome" : "chrome";
}
function noopEvent() {
  return {
    addListener() {
    },
    removeListener() {
    },
    hasListener() {
      return false;
    },
    hasListeners() {
      return false;
    }
  };
}
function unsupportedDebugger() {
  const unavailable = async () => {
    throw new Error("The browser debugger API is not available in this target.");
  };
  return {
    attach: unavailable,
    detach: unavailable,
    sendCommand: unavailable,
    onDetach: noopEvent(),
    onEvent: noopEvent()
  };
}
function extensionAccessApi(api) {
  const extensionApi = api.extension;
  return {
    isAllowedFileSchemeAccess: typeof extensionApi?.isAllowedFileSchemeAccess === "function" ? () => extensionApi.isAllowedFileSchemeAccess?.() ?? Promise.resolve(true) : async () => true,
    isAllowedIncognitoAccess: typeof extensionApi?.isAllowedIncognitoAccess === "function" ? () => extensionApi.isAllowedIncognitoAccess?.() ?? Promise.resolve(true) : async () => true
  };
}
function createLazyBrowserAdapter(kind) {
  return {
    get kind() {
      return kind;
    },
    get supportsDebugger() {
      return !!runtimeBrowser().debugger;
    },
    get supportsVisibleTabCapture() {
      return typeof runtimeBrowser().tabs?.captureVisibleTab === "function";
    },
    get action() {
      return runtimeBrowser().action;
    },
    get alarms() {
      return runtimeBrowser().alarms;
    },
    get debugger() {
      return runtimeBrowser().debugger ?? unsupportedDebugger();
    },
    get downloads() {
      return runtimeBrowser().downloads;
    },
    get bookmarks() {
      return runtimeBrowser().bookmarks;
    },
    get extension() {
      return extensionAccessApi(runtimeBrowser());
    },
    get permissions() {
      return runtimeBrowser().permissions;
    },
    get runtime() {
      return runtimeBrowser().runtime;
    },
    get scripting() {
      return runtimeBrowser().scripting;
    },
    get storage() {
      return runtimeBrowser().storage;
    },
    get tabs() {
      return runtimeBrowser().tabs;
    },
    get windows() {
      return runtimeBrowser().windows;
    },
    get readingList() {
      return runtimeBrowser().readingList;
    }
  };
}
var chromeBrowserAdapter = createLazyBrowserAdapter("chrome");
var browserAdapter = createLazyBrowserAdapter(configuredKind());

// src/annotationOverlay.ts
var browser = browserAdapter;
function runAnnotationCommand(requestedCommand) {
  const stateWindow = window;
  const requestedAction = requestedCommand.action;
  const stableSelectorAttrs = [
    "data-testid",
    "data-test",
    "data-cy",
    "data-qa",
    "name",
    "alt",
    "aria-label",
    "title"
  ];
  const meaningfulSelector = [
    "button",
    "a[href]",
    "input",
    "textarea",
    "select",
    "summary",
    "label",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6",
    "p",
    "li",
    "td",
    "th",
    "dt",
    "dd",
    "blockquote",
    "figcaption",
    "pre",
    "code",
    "img[alt]",
    "svg[aria-label]",
    "svg[role='img']",
    "[role='img']",
    "[role='button']",
    "[role='link']",
    "[role='menuitem']",
    "[role='tab']",
    "[role='checkbox']",
    "[contenteditable='true']"
  ].join(",");
  const cssEscape = (value) => {
    const escaper = globalThis.CSS?.escape;
    return escaper ? escaper(value) : value.replace(/["\\]/g, "\\$&");
  };
  const cssStringEscape = (value) => value.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\a ");
  const isUniqueSelector = (selector) => {
    try {
      return document.querySelectorAll(selector).length === 1;
    } catch {
      return false;
    }
  };
  const trimText = (value) => value.replace(/\s+/g, " ").trim().slice(0, 180);
  const normalizeSelectionText = (value) => value.replace(/\s+/g, " ").trim();
  const normalizedTextMapFor = (root) => {
    const textParts = [];
    const points = [];
    let pendingSpace = null;
    const pushPendingSpace = () => {
      if (!pendingSpace || textParts.length === 0) {
        pendingSpace = null;
        return;
      }
      if (textParts[textParts.length - 1] !== " ") {
        textParts.push(" ");
        points.push(pendingSpace);
      }
      pendingSpace = null;
    };
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const textNode = node;
        const parent = textNode.parentElement;
        if (!parent || parent.closest("script, style, noscript")) {
          return NodeFilter.FILTER_REJECT;
        }
        return textNode.data.trim().length > 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    while (walker.nextNode()) {
      const node = walker.currentNode;
      for (let offset = 0; offset < node.data.length; offset += 1) {
        const char = node.data[offset] ?? "";
        if (/\s/.test(char)) {
          pendingSpace ??= { node, offset };
          continue;
        }
        pushPendingSpace();
        textParts.push(char);
        points.push({ node, offset });
      }
    }
    if (textParts[textParts.length - 1] === " ") {
      textParts.pop();
      points.pop();
    }
    return { text: textParts.join(""), points };
  };
  const rangeForTextMapSpan = (points, startIndex, length) => {
    const start = points[startIndex];
    const end = points[startIndex + length - 1];
    if (!start || !end) return null;
    const range = document.createRange();
    range.setStart(start.node, start.offset);
    range.setEnd(end.node, end.offset + 1);
    return range;
  };
  const rectsForClientRects = (rects) => rects.map((rect) => {
    const left = Math.max(0, rect.left);
    const top = Math.max(0, rect.top);
    const right = Math.min(innerWidth, rect.right);
    const bottom = Math.min(innerHeight, rect.bottom);
    if (right <= left || bottom <= top) return null;
    return {
      x: Math.round(left),
      y: Math.round(top),
      width: Math.round(right - left),
      height: Math.round(bottom - top)
    };
  }).filter((rect) => rect !== null);
  const rangeRects = (range) => {
    const clientRects = Array.from(range.getClientRects());
    const fallbackClientRect = range.getBoundingClientRect();
    const rects = rectsForClientRects(clientRects.length > 0 ? clientRects : [fallbackClientRect]);
    const rect = boundingRectForClientRects(clientRects) ?? boundingRectForClientRects([fallbackClientRect]);
    return rect && rects.length > 0 ? { rect, rects } : null;
  };
  const nodePathFromRoot = (root, node) => {
    const path = [];
    let current = node;
    while (current && current !== root) {
      const parent = current.parentNode;
      if (!parent) return null;
      const index = Array.prototype.indexOf.call(parent.childNodes, current);
      if (index < 0) return null;
      path.unshift(index);
      current = parent;
    }
    return current === root ? path : null;
  };
  const nodeFromPath = (root, path) => {
    let current = root;
    for (const index of path) {
      current = current?.childNodes[index] ?? null;
      if (!current) return null;
    }
    return current;
  };
  const rangeAnchorFor = (root, range, rect) => {
    const startPath = nodePathFromRoot(root, range.startContainer);
    const endPath = nodePathFromRoot(root, range.endContainer);
    if (!startPath || !endPath) return null;
    const directRects = rangeRects(range)?.rects ?? [];
    return {
      selector: selectorInfoFor(root).selector,
      startPath,
      startOffset: range.startOffset,
      endPath,
      endOffset: range.endOffset,
      fragments: directRects.map((fragment) => ({
        x: Math.round(fragment.x - rect.x),
        y: Math.round(fragment.y - rect.y),
        width: fragment.width,
        height: fragment.height
      }))
    };
  };
  const rangeForTextAnchor = (root, anchor) => {
    if (!anchor.startPath || !anchor.endPath || typeof anchor.startOffset !== "number" || typeof anchor.endOffset !== "number") {
      return null;
    }
    const startNode = nodeFromPath(root, anchor.startPath);
    const endNode = nodeFromPath(root, anchor.endPath);
    if (!startNode || !endNode) return null;
    try {
      const range = document.createRange();
      range.setStart(startNode, anchor.startOffset);
      range.setEnd(endNode, anchor.endOffset);
      return range;
    } catch {
      return null;
    }
  };
  const textSelectionRectsFor = (root, text) => {
    const needle = normalizeSelectionText(text);
    if (!needle) return [];
    const map = normalizedTextMapFor(root);
    const matches = [];
    let fromIndex = 0;
    while (matches.length < 30) {
      const index = map.text.indexOf(needle, fromIndex);
      if (index < 0) break;
      const range = rangeForTextMapSpan(map.points, index, needle.length);
      const rectInfo = range ? rangeRects(range) : null;
      if (rectInfo) matches.push({ ...rectInfo, index });
      fromIndex = index + Math.max(1, needle.length);
    }
    return matches;
  };
  const rectDistance = (a, b) => {
    const ax = a.x + a.width / 2;
    const ay = a.y + a.height / 2;
    const bx = b.x + b.width / 2;
    const by = b.y + b.height / 2;
    return Math.hypot(ax - bx, ay - by);
  };
  const normalizeRect = (start, end) => {
    const x = Math.min(start.x, end.x);
    const y = Math.min(start.y, end.y);
    const width = Math.abs(end.x - start.x);
    const height = Math.abs(end.y - start.y);
    return { x, y, width, height };
  };
  const boundingRectForClientRects = (rects) => {
    const visible = rects.filter((rect) => rect.width > 0 && rect.height > 0);
    if (visible.length === 0) return null;
    const left = Math.max(0, Math.min(...visible.map((rect) => rect.left)));
    const top = Math.max(0, Math.min(...visible.map((rect) => rect.top)));
    const right = Math.min(innerWidth, Math.max(...visible.map((rect) => rect.right)));
    const bottom = Math.min(innerHeight, Math.max(...visible.map((rect) => rect.bottom)));
    if (right <= left || bottom <= top) return null;
    return {
      x: Math.round(left),
      y: Math.round(top),
      width: Math.round(right - left),
      height: Math.round(bottom - top)
    };
  };
  const clampRect = (rect) => ({
    x: Math.round(Math.max(0, rect.x)),
    y: Math.round(Math.max(0, rect.y)),
    width: Math.round(Math.max(16, rect.width)),
    height: Math.round(Math.max(16, rect.height))
  });
  const resizedRect = (startRect, handle, dx, dy) => {
    let left = startRect.x;
    let top = startRect.y;
    let right = startRect.x + startRect.width;
    let bottom = startRect.y + startRect.height;
    if (handle.includes("w")) left += dx;
    if (handle.includes("e")) right += dx;
    if (handle.includes("n")) top += dy;
    if (handle.includes("s")) bottom += dy;
    const minSize = 16;
    if (right - left < minSize) {
      if (handle.includes("w")) left = right - minSize;
      else right = left + minSize;
    }
    if (bottom - top < minSize) {
      if (handle.includes("n")) top = bottom - minSize;
      else bottom = top + minSize;
    }
    return clampRect({ x: left, y: top, width: right - left, height: bottom - top });
  };
  const viewportToPageRect = (rect) => ({
    x: Math.round(rect.x + scrollX),
    y: Math.round(rect.y + scrollY),
    width: Math.round(rect.width),
    height: Math.round(rect.height)
  });
  const pageToViewportRect = (rect) => ({
    x: Math.round(rect.x - scrollX),
    y: Math.round(rect.y - scrollY),
    width: Math.round(rect.width),
    height: Math.round(rect.height)
  });
  const selectorInfoFor = (el) => {
    if (el.id && document.querySelectorAll(`#${cssEscape(el.id)}`).length === 1) {
      return { selector: `#${cssEscape(el.id)}`, quality: "stable" };
    }
    for (const attr of stableSelectorAttrs) {
      const value = el.getAttribute(attr);
      if (!value) continue;
      const selector = `${el.tagName.toLowerCase()}[${attr}="${cssStringEscape(value)}"]`;
      if (isUniqueSelector(selector)) return { selector, quality: "stable" };
    }
    const classNames = Array.from(el.classList).filter(Boolean);
    if (classNames.length > 0) {
      const classSelector = `${el.tagName.toLowerCase()}.${classNames.map(cssEscape).join(".")}`;
      if (isUniqueSelector(classSelector)) {
        return { selector: classSelector, quality: "structural" };
      }
    }
    const parts = [];
    let current = el;
    while (current && current.nodeType === Node.ELEMENT_NODE && parts.length < 6) {
      const parent = current.parentElement;
      const tag = current.tagName.toLowerCase();
      if (!parent) {
        parts.unshift(tag);
        break;
      }
      const sameTagSiblings = Array.from(parent.children).filter(
        (child) => child instanceof Element && child.tagName === current?.tagName
      );
      const nth = sameTagSiblings.indexOf(current) + 1;
      parts.unshift(sameTagSiblings.length > 1 ? `${tag}:nth-of-type(${nth})` : tag);
      current = parent;
    }
    return { selector: parts.join(" > "), quality: "structural" };
  };
  const isOverlayElement = (state2, element) => element === state2.host || state2.host.contains(element) || state2.shadow.contains(element);
  const elementAtViewportPoint = (state2, x, y) => document.elementsFromPoint(x, y).find((el) => !isOverlayElement(state2, el));
  const isFrameElement = (element) => {
    const tag = element.tagName.toLowerCase();
    return tag === "frame" || tag === "iframe";
  };
  const frameWindowFor = (element) => {
    if (!isFrameElement(element)) return null;
    try {
      const win = element.contentWindow ?? null;
      if (!win) return null;
      void win.scrollX;
      return win;
    } catch {
      return null;
    }
  };
  const isScrollableElement = (element) => {
    if (!(element instanceof HTMLElement)) return false;
    if (element === document.body || element === document.documentElement) return false;
    const style = getComputedStyle(element);
    const overflow = `${style.overflow} ${style.overflowX} ${style.overflowY}`;
    if (!/(auto|scroll|overlay)/.test(overflow)) return false;
    return element.scrollHeight > element.clientHeight + 1 || element.scrollWidth > element.clientWidth + 1;
  };
  const anchorForViewportRect = (state2, viewportRect) => {
    const centerX = viewportRect.x + viewportRect.width / 2;
    const centerY = viewportRect.y + viewportRect.height / 2;
    const element = elementAtViewportPoint(state2, centerX, centerY);
    if (!element) return { type: "window" };
    const frame = isFrameElement(element) ? element : element.closest("frame, iframe");
    if (frame && frameWindowFor(frame)) {
      return { type: "frame", selector: selectorInfoFor(frame).selector };
    }
    let current = element;
    while (current && current !== document.documentElement) {
      if (isScrollableElement(current)) {
        return { type: "element", selector: selectorInfoFor(current).selector };
      }
      current = current.parentElement;
    }
    return { type: "window" };
  };
  const scrollForAnchor = (anchor) => {
    if (anchor?.type === "frame") {
      const frame = document.querySelector(anchor.selector);
      const win = frame ? frameWindowFor(frame) : null;
      if (win) {
        return { x: Math.round(win.scrollX), y: Math.round(win.scrollY) };
      }
    }
    if (anchor?.type === "element") {
      const element = document.querySelector(anchor.selector);
      if (element instanceof HTMLElement) {
        return { x: Math.round(element.scrollLeft), y: Math.round(element.scrollTop) };
      }
    }
    return { x: Math.round(scrollX), y: Math.round(scrollY) };
  };
  const viewportToAnchoredRect = (state2, viewportRect) => {
    const clamped = clampRect(viewportRect);
    const anchor = anchorForViewportRect(state2, clamped);
    if (anchor.type === "frame") {
      const frame = document.querySelector(anchor.selector);
      const win = frame ? frameWindowFor(frame) : null;
      if (frame && win) {
        const frameRect = frame.getBoundingClientRect();
        const scroll = { x: Math.round(win.scrollX), y: Math.round(win.scrollY) };
        return {
          anchor,
          scroll,
          viewportRect: clamped,
          rect: {
            x: Math.round(clamped.x - frameRect.left + scroll.x),
            y: Math.round(clamped.y - frameRect.top + scroll.y),
            width: clamped.width,
            height: clamped.height
          }
        };
      }
    }
    if (anchor.type === "element") {
      const element = document.querySelector(anchor.selector);
      if (element instanceof HTMLElement) {
        const elementRect = element.getBoundingClientRect();
        const scroll = { x: Math.round(element.scrollLeft), y: Math.round(element.scrollTop) };
        return {
          anchor,
          scroll,
          viewportRect: clamped,
          rect: {
            x: Math.round(clamped.x - elementRect.left + scroll.x),
            y: Math.round(clamped.y - elementRect.top + scroll.y),
            width: clamped.width,
            height: clamped.height
          }
        };
      }
    }
    return {
      anchor: { type: "window" },
      scroll: { x: Math.round(scrollX), y: Math.round(scrollY) },
      viewportRect: clamped,
      rect: viewportToPageRect(clamped)
    };
  };
  const storedAnnotationRectToViewport = (annotation) => {
    if (annotation.anchor?.type === "frame") {
      const frame = document.querySelector(annotation.anchor.selector);
      const win = frame ? frameWindowFor(frame) : null;
      if (frame && win) {
        const frameRect = frame.getBoundingClientRect();
        return {
          x: Math.round(annotation.rect.x + frameRect.left - win.scrollX),
          y: Math.round(annotation.rect.y + frameRect.top - win.scrollY),
          width: Math.round(annotation.rect.width),
          height: Math.round(annotation.rect.height)
        };
      }
    }
    if (annotation.anchor?.type === "element") {
      const element = document.querySelector(annotation.anchor.selector);
      if (element instanceof HTMLElement) {
        const elementRect = element.getBoundingClientRect();
        return {
          x: Math.round(annotation.rect.x + elementRect.left - element.scrollLeft),
          y: Math.round(annotation.rect.y + elementRect.top - element.scrollTop),
          width: Math.round(annotation.rect.width),
          height: Math.round(annotation.rect.height)
        };
      }
    }
    return pageToViewportRect(annotation.rect);
  };
  const textSelectionMatchForAnnotation = (annotation, fallbackRect) => {
    if (annotation.kind !== "text" || !annotation.text || !annotation.textAnchor) return null;
    const root = document.querySelector(annotation.textAnchor.selector);
    if (!root) return null;
    const directRange = rangeForTextAnchor(root, annotation.textAnchor);
    const directRects = directRange ? rangeRects(directRange) : null;
    if (directRects) return { ...directRects, index: annotation.textAnchor.index ?? -1 };
    const matches = textSelectionRectsFor(root, annotation.text);
    if (matches.length === 0) return null;
    if (typeof annotation.textAnchor.index === "number") {
      const indexedMatch = matches.find((match) => match.index === annotation.textAnchor?.index);
      if (indexedMatch) return indexedMatch;
    }
    return matches.reduce(
      (best, candidate) => rectDistance(candidate.rect, fallbackRect) < rectDistance(best.rect, fallbackRect) ? candidate : best
    );
  };
  const rectForTextAnnotation = (annotation, fallbackRect) => {
    return textSelectionMatchForAnnotation(annotation, fallbackRect)?.rect ?? null;
  };
  const highlightRectsForTextAnnotation = (annotation, fallbackRect) => {
    const matchedRects = textSelectionMatchForAnnotation(annotation, fallbackRect)?.rects;
    if (matchedRects) return matchedRects;
    const fragments = annotation.textAnchor?.fragments;
    if (!fragments || fragments.length === 0) return null;
    return fragments.map((fragment) => ({
      x: Math.round(fallbackRect.x + fragment.x),
      y: Math.round(fallbackRect.y + fragment.y),
      width: fragment.width,
      height: fragment.height
    }));
  };
  const anchoredToViewportRect = (annotation) => {
    const fallbackRect = storedAnnotationRectToViewport(annotation);
    const textRect = rectForTextAnnotation(annotation, fallbackRect);
    if (textRect) return textRect;
    if (annotation.kind === "dom" && annotation.selector) {
      const element = document.querySelector(annotation.selector);
      if (element) {
        try {
          return rectForElement(element);
        } catch {
        }
      }
    }
    return fallbackRect;
  };
  const isAlwaysScreenshotElement = (element) => {
    const tag = element.tagName.toLowerCase();
    return tag === "canvas" || tag === "video";
  };
  const isMediaElement = (element) => {
    const tag = element.tagName.toLowerCase();
    return tag === "svg" || tag === "img";
  };
  const isLikelyLayoutWrapper = (element) => {
    const tag = element.tagName.toLowerCase();
    if (["html", "body", "main", "section", "article", "nav", "aside", "header", "footer"].includes(
      tag
    )) {
      return true;
    }
    const role = element.getAttribute("role")?.toLowerCase();
    if (role && ["main", "region", "presentation", "none", "group"].includes(role)) return true;
    const textLength = trimText(
      element.innerText || element.textContent || ""
    ).length;
    return element.children.length >= 3 && textLength > 240;
  };
  const nearestMeaningfulElement = (state2, start) => {
    let stableFallback = null;
    let current = start;
    while (current && current !== document.documentElement) {
      if (isOverlayElement(state2, current)) return null;
      if (current.matches(meaningfulSelector)) return current;
      if (!stableFallback) {
        const info = selectorInfoFor(current);
        if (info.quality === "stable") stableFallback = current;
      }
      current = current.parentElement;
    }
    return stableFallback;
  };
  const metadataForElement = (element) => {
    const html = element;
    const style = getComputedStyle(element);
    const selectorInfo = selectorInfoFor(element);
    return {
      tag: element.tagName.toLowerCase(),
      selector: selectorInfo.selector,
      selectorQuality: selectorInfo.quality,
      text: trimText(
        element.getAttribute("aria-label") || element.getAttribute("title") || html.innerText || element.textContent || ""
      ),
      color: style.color,
      backgroundColor: style.backgroundColor,
      fontSize: style.fontSize,
      fontFamily: style.fontFamily
    };
  };
  const metadataForTextSelection = (element, text) => ({
    ...metadataForElement(element),
    text: trimText(text)
  });
  const elementFromRangeContainer = (container) => {
    if (container instanceof Element) return container;
    const parent = container.parentElement;
    return parent ?? null;
  };
  const selectionRootElement = (state2, range) => {
    const common = elementFromRangeContainer(range.commonAncestorContainer);
    if (common && !isOverlayElement(state2, common)) return common;
    const start = elementFromRangeContainer(range.startContainer);
    const end = elementFromRangeContainer(range.endContainer);
    for (const candidate of [start, end]) {
      if (candidate && !isOverlayElement(state2, candidate)) return candidate;
    }
    return null;
  };
  const selectionAnnotationTarget = (state2) => {
    const selectedRange = getSelection();
    if (!selectedRange || selectedRange.isCollapsed || selectedRange.rangeCount === 0) return null;
    const text = selectedRange.toString().trim();
    if (!text) return null;
    const range = selectedRange.getRangeAt(0);
    const common = elementFromRangeContainer(range.commonAncestorContainer);
    if (common && isOverlayElement(state2, common)) return null;
    const root = selectionRootElement(state2, range);
    if (!root) return null;
    const rectInfo = rangeRects(range);
    const rect = rectInfo?.rect;
    if (!rect || rect.width < 2 || rect.height < 2) return null;
    const element = metadataForTextSelection(root, text);
    const match = textSelectionRectsFor(root, text).reduce(
      (best, candidate) => !best || rectDistance(candidate.rect, rect) < rectDistance(best.rect, rect) ? candidate : best,
      null
    );
    const textAnchor = rangeAnchorFor(root, range, rect) ?? {
      selector: selectorInfoFor(root).selector
    };
    textAnchor.index = match?.index;
    const signature = `${textAnchor.selector}:${text.slice(0, 120)}:${rect.x}:${rect.y}:${rect.width}:${rect.height}`;
    return { rect, text, element, textAnchor, signature };
  };
  const elementAtCenter = (state2, rect) => {
    const x = rect.x + rect.width / 2;
    const y = rect.y + rect.height / 2;
    const element = elementAtViewportPoint(state2, x, y);
    const meaningfulElement = element ? nearestMeaningfulElement(state2, element) : null;
    return meaningfulElement ? metadataForElement(meaningfulElement) : void 0;
  };
  const rectForElement = (element) => {
    const rect = element.getBoundingClientRect();
    if (rect.width < 1 || rect.height < 1) {
      throw new Error("selector matched an element without a visible box");
    }
    return {
      x: Math.round(rect.left),
      y: Math.round(rect.top),
      width: Math.round(rect.width),
      height: Math.round(rect.height)
    };
  };
  const rectArea = (rect) => rect.width * rect.height;
  const overlapArea = (a, b) => {
    const left = Math.max(a.x, b.x);
    const top = Math.max(a.y, b.y);
    const right = Math.min(a.x + a.width, b.x + b.width);
    const bottom = Math.min(a.y + a.height, b.y + b.height);
    return Math.max(0, right - left) * Math.max(0, bottom - top);
  };
  const inferDomTarget = (state2, viewportRect) => {
    const pointMode = viewportRect.width < 8 || viewportRect.height < 8;
    const centerX = viewportRect.x + viewportRect.width / 2;
    const centerY = viewportRect.y + viewportRect.height / 2;
    const element = elementAtViewportPoint(state2, centerX, centerY);
    if (!element) return null;
    const meaningfulElement = nearestMeaningfulElement(state2, element);
    if (!meaningfulElement || isAlwaysScreenshotElement(meaningfulElement)) return null;
    const candidateRect = rectForElement(meaningfulElement);
    const viewportArea = Math.max(1, innerWidth * innerHeight);
    if (rectArea(candidateRect) / viewportArea > 0.7 && !pointMode) return null;
    if (isLikelyLayoutWrapper(meaningfulElement)) {
      const selectedArea = Math.max(1, rectArea(viewportRect));
      const candidateArea = Math.max(1, rectArea(candidateRect));
      if (pointMode && candidateArea / viewportArea > 0.35) return null;
      if (!pointMode && (candidateArea / selectedArea > 1.6 || candidateArea / viewportArea > 0.55)) {
        return null;
      }
    }
    if (!pointMode) {
      const selectedArea = Math.max(1, rectArea(viewportRect));
      const covered = overlapArea(viewportRect, candidateRect) / selectedArea;
      const sizeRatio = Math.min(rectArea(viewportRect), rectArea(candidateRect)) / Math.max(rectArea(viewportRect), rectArea(candidateRect), 1);
      if (covered < 0.8 || sizeRatio < 0.35) return null;
    }
    const elementMetadata = metadataForElement(meaningfulElement);
    if (isMediaElement(meaningfulElement) && elementMetadata.selectorQuality !== "stable") {
      return null;
    }
    if (elementMetadata.selectorQuality !== "stable" && !meaningfulElement.matches(meaningfulSelector)) {
      return null;
    }
    return {
      rect: candidateRect,
      selector: elementMetadata.selector,
      element: elementMetadata
    };
  };
  const snapshotAnnotations = (state2) => state2.annotations.map((annotation, index) => ({
    ...annotation,
    displayNumber: index + 1,
    viewportRect: anchoredToViewportRect(annotation),
    scroll: scrollForAnchor(annotation.anchor),
    url: location.href,
    title: document.title
  }));
  const makeResult = (state2, action) => {
    const annotations = snapshotAnnotations(state2);
    return {
      ok: true,
      enabled: state2.enabled,
      count: annotations.length,
      annotations,
      userMessage: action === "start" ? "Annotation mode is active. Use Area to drag regions or Text to mark selected page text; click Done or press Escape to stop capturing." : void 0,
      nextCommand: "abg annotate <tab>"
    };
  };
  const setRectStyle = (el, rect) => {
    el.style.left = `${Math.round(rect.x)}px`;
    el.style.top = `${Math.round(rect.y)}px`;
    el.style.width = `${Math.round(rect.width)}px`;
    el.style.height = `${Math.round(rect.height)}px`;
  };
  const replaceAnnotationRect = (state2, annotation, viewportRect) => {
    const anchored = viewportToAnchoredRect(state2, viewportRect);
    annotation.kind = "screenshot";
    annotation.selector = void 0;
    annotation.element = void 0;
    annotation.rect = anchored.rect;
    annotation.viewportRect = anchored.viewportRect;
    annotation.scroll = anchored.scroll;
    annotation.anchor = anchored.anchor;
  };
  const closeEditor = (state2) => {
    state2.editor.hidden = true;
    state2.editor.replaceChildren();
  };
  const isTextEditingTarget = (target) => {
    if (!(target instanceof Element)) return false;
    return Boolean(target.closest("input, textarea, select, [contenteditable='true']"));
  };
  const updateToolbar = (state2) => {
    state2.toolbar.hidden = !state2.enabled;
    const countEl = state2.toolbar.querySelector("[data-count]");
    if (countEl) {
      countEl.textContent = `${state2.annotations.length} annotation${state2.annotations.length === 1 ? "" : "s"}`;
    }
    for (const modeButton of state2.toolbar.querySelectorAll(
      "button[data-mode]"
    )) {
      const active = modeButton.dataset.mode === state2.mode;
      modeButton.classList.toggle("abg-active", active);
      modeButton.setAttribute("aria-pressed", String(active));
    }
  };
  const editAnnotation = (state2, annotation) => {
    closeEditor(state2);
    const viewportRect = anchoredToViewportRect(annotation);
    const form = document.createElement("form");
    const input = document.createElement("input");
    const save = document.createElement("button");
    const remove = document.createElement("button");
    input.type = "text";
    input.placeholder = "Add a comment...";
    input.value = annotation.comment;
    save.type = "submit";
    save.textContent = "Save";
    remove.type = "button";
    remove.textContent = "Delete";
    form.append(input, save, remove);
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      annotation.comment = input.value.trim();
      closeEditor(state2);
      renderAnnotations(state2);
    });
    remove.addEventListener("click", () => {
      state2.annotations = state2.annotations.filter((item) => item.id !== annotation.id);
      closeEditor(state2);
      renderAnnotations(state2);
    });
    state2.editor.append(form);
    state2.editor.hidden = false;
    const width = Math.min(360, Math.max(240, innerWidth - 24));
    const left = Math.min(Math.max(12, viewportRect.x), innerWidth - width - 12);
    const top = viewportRect.y + viewportRect.height + 12 < innerHeight - 56 ? viewportRect.y + viewportRect.height + 12 : Math.max(12, viewportRect.y - 56);
    state2.editor.style.left = `${Math.round(left)}px`;
    state2.editor.style.top = `${Math.round(top)}px`;
    state2.editor.style.width = `${Math.round(width)}px`;
    input.focus();
    input.select();
  };
  const renderAnnotations = (state2) => {
    state2.layer.replaceChildren();
    for (const [index, annotation] of state2.annotations.entries()) {
      const rect = anchoredToViewportRect(annotation);
      const isSelected = state2.enabled && state2.selectedId === annotation.id;
      const canEditRect = annotation.kind === "screenshot";
      const openAnnotationEditor = (event) => {
        if (!state2.enabled) return;
        if (state2.suppressClickId === annotation.id) {
          state2.suppressClickId = null;
          event.preventDefault();
          event.stopPropagation();
          return;
        }
        state2.selectedId = annotation.id;
        event.stopPropagation();
        editAnnotation(state2, annotation);
        renderAnnotations(state2);
      };
      if (annotation.kind === "text") {
        const group = document.createElement("div");
        const textRects = highlightRectsForTextAnnotation(annotation, rect) ?? [];
        const anchorRect = textRects[textRects.length - 1] ?? rect;
        const badge2 = document.createElement("span");
        const comment2 = document.createElement("span");
        group.className = [
          "abg-text-selection-group",
          isSelected ? "abg-text-selection-selected" : ""
        ].filter(Boolean).join(" ");
        group.dataset.id = String(annotation.id);
        group.addEventListener("click", openAnnotationEditor);
        for (const textRect of textRects) {
          const piece = document.createElement("span");
          piece.className = "abg-text-selection-piece";
          piece.dataset.id = String(annotation.id);
          piece.role = "button";
          piece.setAttribute("aria-label", `Annotation ${index + 1}`);
          setRectStyle(piece, textRect);
          group.append(piece);
        }
        badge2.className = "abg-text-selection-badge";
        badge2.textContent = String(index + 1);
        badge2.style.left = `${Math.round(anchorRect.x + anchorRect.width - 10)}px`;
        badge2.style.top = `${Math.round(anchorRect.y + anchorRect.height - 10)}px`;
        comment2.className = "abg-text-selection-comment";
        comment2.textContent = annotation.comment;
        comment2.hidden = annotation.comment.length === 0;
        comment2.style.left = `${Math.round(Math.max(8, rect.x))}px`;
        comment2.style.top = `${Math.round(Math.min(innerHeight - 34, rect.y + rect.height + 6))}px`;
        comment2.style.maxWidth = `${Math.round(Math.min(360, Math.max(120, innerWidth - rect.x - 16)))}px`;
        group.append(badge2, comment2);
        state2.layer.append(group);
        continue;
      }
      const box = document.createElement("button");
      const badge = document.createElement("span");
      const comment = document.createElement("span");
      const handles = isSelected && canEditRect ? ["n", "ne", "e", "se", "s", "sw", "w", "nw"].map((handle) => {
        const el = document.createElement("span");
        el.className = `abg-resize-handle abg-resize-${handle}`;
        el.dataset.handle = handle;
        return el;
      }) : [];
      box.type = "button";
      box.className = [
        "abg-annotation-box",
        annotation.kind === "screenshot" ? "abg-annotation-screenshot" : "abg-annotation-dom",
        isSelected ? "abg-annotation-selected" : ""
      ].filter(Boolean).join(" ");
      box.dataset.id = String(annotation.id);
      setRectStyle(box, rect);
      badge.className = "abg-annotation-badge";
      badge.textContent = String(index + 1);
      comment.className = "abg-annotation-comment";
      comment.textContent = annotation.comment;
      comment.hidden = annotation.comment.length === 0;
      box.append(badge, comment, ...handles);
      box.addEventListener("mousedown", (event) => {
        if (!state2.enabled || event.button !== 0) return;
        if (!canEditRect) return;
        const target = event.target instanceof HTMLElement ? event.target : null;
        const handle = target?.dataset.handle;
        state2.selectedId = annotation.id;
        state2.editGesture = {
          annotationId: annotation.id,
          mode: handle ? "resize" : "move",
          handle,
          startX: event.clientX,
          startY: event.clientY,
          startRect: rect,
          didMove: false
        };
        closeEditor(state2);
        box.classList.add("abg-annotation-selected");
        event.preventDefault();
        event.stopPropagation();
      });
      box.addEventListener("click", (event) => {
        openAnnotationEditor(event);
      });
      state2.layer.append(box);
    }
    updateToolbar(state2);
  };
  const ensureRenderTimer = (state2) => {
    if (state2.renderTimer !== null) return;
    state2.renderTimer = window.setInterval(() => {
      if (state2.annotations.length > 0) renderAnnotations(state2);
    }, 150);
  };
  const addAnnotation = (state2, viewportRect, options) => {
    const anchored = viewportToAnchoredRect(state2, viewportRect);
    const annotation = {
      id: state2.nextId++,
      kind: options.kind,
      source: options.source,
      comment: options.comment?.trim() ?? "",
      selector: options.selector,
      text: options.text,
      textAnchor: options.textAnchor,
      rect: anchored.rect,
      viewportRect: anchored.viewportRect,
      scroll: anchored.scroll,
      anchor: anchored.anchor,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      url: location.href,
      title: document.title,
      element: options.element ?? elementAtCenter(state2, viewportRect)
    };
    state2.annotations.push(annotation);
    renderAnnotations(state2);
    if (options.openEditor ?? annotation.comment.length === 0) editAnnotation(state2, annotation);
    return annotation;
  };
  const addAutoAnnotation = (state2, viewportRect, options) => {
    const domTarget = inferDomTarget(state2, viewportRect);
    if (domTarget) {
      return addAnnotation(state2, domTarget.rect, {
        kind: "dom",
        source: options.source,
        selector: domTarget.selector,
        comment: options.comment,
        element: domTarget.element,
        openEditor: options.openEditor
      });
    }
    return addAnnotation(state2, viewportRect, {
      kind: "screenshot",
      source: options.source,
      comment: options.comment,
      openEditor: options.openEditor
    });
  };
  const addTextSelectionAnnotation = (state2) => {
    if (!state2.enabled || state2.mode !== "text") return;
    const target = selectionAnnotationTarget(state2);
    if (!target || target.signature === state2.lastSelectionSignature) return;
    state2.lastSelectionSignature = target.signature;
    addAnnotation(state2, target.rect, {
      kind: "text",
      source: "selection",
      text: target.text,
      textAnchor: target.textAnchor,
      element: target.element,
      openEditor: true
    });
    getSelection()?.removeAllRanges();
  };
  const applyInteractionMode = (state2) => {
    const areaEnabled = state2.enabled && state2.mode === "area";
    state2.capture.hidden = !areaEnabled;
    state2.capture.style.pointerEvents = areaEnabled ? "auto" : "none";
    state2.host.style.pointerEvents = state2.enabled ? "auto" : "none";
    state2.layer.style.pointerEvents = "none";
    updateToolbar(state2);
  };
  const setMode = (state2, mode) => {
    state2.mode = mode;
    state2.dragStart = null;
    state2.activeDraft = null;
    state2.draft.hidden = true;
    state2.lastSelectionSignature = null;
    if (mode === "area") getSelection()?.removeAllRanges();
    applyInteractionMode(state2);
  };
  const setEnabled = (state2, enabled) => {
    state2.enabled = enabled;
    if (!enabled) {
      state2.dragStart = null;
      state2.activeDraft = null;
      state2.selectedId = null;
      state2.editGesture = null;
      state2.suppressClickId = null;
      state2.lastSelectionSignature = null;
      state2.draft.hidden = true;
      closeEditor(state2);
      renderAnnotations(state2);
      applyInteractionMode(state2);
      return;
    }
    applyInteractionMode(state2);
  };
  const createState = () => {
    document.getElementById("__abg_annotation_mode")?.remove();
    const host = document.createElement("div");
    host.id = "__abg_annotation_mode";
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = `
          :host {
            all: initial;
            color-scheme: light;
          }
          [hidden] {
            display: none !important;
          }
          .abg-capture,
          .abg-layer {
            position: fixed;
            inset: 0;
            width: 100vw;
            height: 100vh;
          }
          .abg-capture {
            z-index: 2147483644;
            cursor: crosshair;
            background: rgba(0, 0, 0, 0.02);
          }
          .abg-layer {
            z-index: 2147483645;
            pointer-events: auto;
          }
          .abg-toolbar {
            position: fixed;
            top: 12px;
            right: 12px;
            z-index: 2147483647;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 7px 8px;
            border: 1px solid rgba(255, 255, 255, 0.18);
            border-radius: 8px;
            background: rgba(37, 31, 52, 0.92);
            box-shadow: 0 8px 28px rgba(0, 0, 0, 0.28);
            color: #f7eaff;
            font: 12px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            pointer-events: auto;
            user-select: none;
          }
          .abg-chip {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            color: #ffd6f9;
            font-weight: 650;
          }
          .abg-dot {
            width: 7px;
            height: 7px;
            border-radius: 999px;
            background: #ff69d7;
            box-shadow: 0 0 0 3px rgba(255, 105, 215, 0.18);
          }
          .abg-count {
            color: rgba(255, 255, 255, 0.72);
          }
          .abg-toolbar button,
          .abg-editor button {
            appearance: none;
            border: 1px solid rgba(255, 255, 255, 0.18);
            border-radius: 6px;
            padding: 5px 8px;
            background: rgba(255, 255, 255, 0.11);
            color: inherit;
            font: inherit;
            cursor: pointer;
          }
          .abg-toolbar button:hover,
          .abg-editor button:hover {
            background: rgba(255, 255, 255, 0.18);
          }
          .abg-toolbar button.abg-active {
            border-color: rgba(255, 255, 255, 0.42);
            background: rgba(255, 255, 255, 0.24);
            color: #ffffff;
          }
          .abg-draft,
          .abg-annotation-box {
            position: fixed;
            box-sizing: border-box;
            border: 2px solid #1d9bf0;
            background: rgba(29, 155, 240, 0.2);
            box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.25);
          }
          .abg-draft {
            z-index: 2147483646;
            pointer-events: none;
          }
          .abg-annotation-box {
            z-index: 2147483646;
            margin: 0;
            padding: 0;
            pointer-events: auto;
            text-align: left;
          }
          .abg-annotation-screenshot {
            cursor: move;
          }
          .abg-annotation-dom,
          .abg-annotation-text {
            cursor: pointer;
          }
          .abg-annotation-box:hover {
            background: rgba(29, 155, 240, 0.26);
          }
          .abg-text-selection-group {
            position: fixed;
            inset: 0;
            z-index: 2147483646;
            pointer-events: none;
          }
          .abg-text-selection-piece {
            position: fixed;
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            border: 0;
            border-radius: 2px;
            background: rgba(88, 166, 255, 0.52);
            box-shadow: inset 0 -1px 0 rgba(88, 166, 255, 0.68);
            pointer-events: auto;
            cursor: pointer;
          }
          .abg-text-selection-badge {
            position: fixed;
            z-index: 2147483647;
            width: 22px;
            min-width: 22px;
            height: 22px;
            border-radius: 999px;
            border: 2px solid #ffffff;
            background: #1d9bf0;
            color: #ffffff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font: 700 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.28);
            pointer-events: auto;
            cursor: pointer;
          }
          .abg-text-selection-comment {
            position: fixed;
            z-index: 2147483647;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            border-radius: 6px;
            padding: 4px 6px;
            background: rgba(5, 18, 31, 0.82);
            color: #ffffff;
            font: 12px/1.25 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            pointer-events: auto;
            cursor: pointer;
          }
          .abg-text-selection-piece:hover,
          .abg-text-selection-selected .abg-text-selection-piece {
            background: rgba(88, 166, 255, 0.64);
          }
          .abg-text-selection-selected .abg-text-selection-piece {
            box-shadow:
              inset 0 0 0 1px rgba(255, 255, 255, 0.62),
              inset 0 -1px 0 rgba(88, 166, 255, 0.78);
          }
          .abg-annotation-selected {
            outline: 1px solid rgba(255, 255, 255, 0.75);
            outline-offset: 2px;
          }
          .abg-resize-handle {
            position: absolute;
            display: block;
            pointer-events: auto;
            background: transparent;
          }
          .abg-annotation-selected .abg-resize-handle::after {
            content: "";
            position: absolute;
            width: 8px;
            height: 8px;
            border: 2px solid #ffffff;
            border-radius: 999px;
            background: #1d9bf0;
            box-shadow: 0 1px 6px rgba(0, 0, 0, 0.3);
          }
          .abg-resize-n,
          .abg-resize-s {
            left: 12px;
            right: 12px;
            height: 12px;
            cursor: ns-resize;
          }
          .abg-resize-n {
            top: -6px;
          }
          .abg-resize-s {
            bottom: -6px;
          }
          .abg-resize-e,
          .abg-resize-w {
            top: 12px;
            bottom: 12px;
            width: 12px;
            cursor: ew-resize;
          }
          .abg-resize-e {
            right: -6px;
          }
          .abg-resize-w {
            left: -6px;
          }
          .abg-resize-ne,
          .abg-resize-se,
          .abg-resize-sw,
          .abg-resize-nw {
            width: 16px;
            height: 16px;
          }
          .abg-resize-ne {
            top: -8px;
            right: -8px;
            cursor: nesw-resize;
          }
          .abg-resize-se {
            right: -8px;
            bottom: -8px;
            cursor: nwse-resize;
          }
          .abg-resize-sw {
            left: -8px;
            bottom: -8px;
            cursor: nesw-resize;
          }
          .abg-resize-nw {
            top: -8px;
            left: -8px;
            cursor: nwse-resize;
          }
          .abg-resize-n::after {
            top: 0;
            left: calc(50% - 6px);
          }
          .abg-resize-s::after {
            bottom: 0;
            left: calc(50% - 6px);
          }
          .abg-resize-e::after {
            top: calc(50% - 6px);
            right: 0;
          }
          .abg-resize-w::after {
            top: calc(50% - 6px);
            left: 0;
          }
          .abg-resize-ne::after {
            top: 2px;
            right: 2px;
          }
          .abg-resize-se::after {
            right: 2px;
            bottom: 2px;
          }
          .abg-resize-sw::after {
            left: 2px;
            bottom: 2px;
          }
          .abg-resize-nw::after {
            top: 2px;
            left: 2px;
          }
          .abg-annotation-badge {
            position: absolute;
            right: -12px;
            bottom: -12px;
            min-width: 22px;
            height: 22px;
            border-radius: 999px;
            border: 2px solid #ffffff;
            background: #1d9bf0;
            color: #ffffff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font: 700 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.28);
          }
          .abg-annotation-comment {
            position: absolute;
            left: 8px;
            bottom: 8px;
            max-width: calc(100% - 16px);
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            border-radius: 6px;
            padding: 4px 6px;
            background: rgba(5, 18, 31, 0.82);
            color: #ffffff;
            font: 12px/1.25 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          }
          .abg-editor {
            position: fixed;
            z-index: 2147483647;
            pointer-events: auto;
          }
          .abg-editor form {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 8px;
            border-radius: 8px;
            background: rgba(43, 43, 54, 0.96);
            box-shadow: 0 8px 28px rgba(0, 0, 0, 0.32);
          }
          .abg-editor input {
            min-width: 0;
            flex: 1;
            border: 0;
            border-radius: 6px;
            padding: 7px 9px;
            background: rgba(255, 255, 255, 0.12);
            color: #ffffff;
            outline: none;
            font: 13px/1.2 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          }
          .abg-editor input::placeholder {
            color: rgba(255, 255, 255, 0.5);
          }
          .abg-editor button {
            color: #ffffff;
            white-space: nowrap;
          }
        `;
    const capture = document.createElement("div");
    const layer = document.createElement("div");
    const toolbar = document.createElement("div");
    const draft = document.createElement("div");
    const editor = document.createElement("div");
    capture.className = "abg-capture";
    layer.className = "abg-layer";
    toolbar.className = "abg-toolbar";
    draft.className = "abg-draft";
    editor.className = "abg-editor";
    capture.hidden = true;
    draft.hidden = true;
    editor.hidden = true;
    toolbar.hidden = true;
    capture.style.pointerEvents = "none";
    layer.style.pointerEvents = "none";
    host.style.pointerEvents = "none";
    toolbar.innerHTML = `
          <span class="abg-chip"><span class="abg-dot"></span>Annotating</span>
          <button type="button" data-action="mode-area" data-mode="area" aria-pressed="true">Area</button>
          <button type="button" data-action="mode-text" data-mode="text" aria-pressed="false">Text</button>
          <span class="abg-count" data-count>0 annotations</span>
          <button type="button" data-action="clear">Clear</button>
          <button type="button" data-action="done">Done</button>
        `;
    shadow.append(style, capture, layer, draft, editor, toolbar);
    document.documentElement.append(host);
    const state2 = {
      enabled: false,
      mode: "area",
      nextId: 1,
      selectedId: null,
      annotations: [],
      host,
      shadow,
      capture,
      layer,
      toolbar,
      draft,
      editor,
      dragStart: null,
      activeDraft: null,
      renderTimer: null,
      editGesture: null,
      suppressClickId: null,
      lastSelectionSignature: null
    };
    capture.addEventListener("mousedown", (event) => {
      if (!state2.enabled || event.button !== 0) return;
      closeEditor(state2);
      state2.dragStart = { x: event.clientX, y: event.clientY };
      state2.activeDraft = { x: event.clientX, y: event.clientY, width: 0, height: 0 };
      setRectStyle(draft, state2.activeDraft);
      draft.hidden = false;
      event.preventDefault();
      event.stopPropagation();
    });
    capture.addEventListener("mousemove", (event) => {
      if (!state2.dragStart) return;
      state2.activeDraft = normalizeRect(state2.dragStart, {
        x: event.clientX,
        y: event.clientY
      });
      setRectStyle(draft, state2.activeDraft);
      event.preventDefault();
      event.stopPropagation();
    });
    capture.addEventListener("mouseup", (event) => {
      if (!state2.dragStart || !state2.activeDraft) return;
      const rect = normalizeRect(state2.dragStart, { x: event.clientX, y: event.clientY });
      state2.dragStart = null;
      state2.activeDraft = null;
      draft.hidden = true;
      if (rect.width >= 8 && rect.height >= 8) {
        addAutoAnnotation(state2, rect, {
          source: "drag",
          openEditor: true
        });
      } else {
        const domTarget = inferDomTarget(state2, {
          x: event.clientX,
          y: event.clientY,
          width: 1,
          height: 1
        });
        if (domTarget) {
          addAnnotation(state2, domTarget.rect, {
            kind: "dom",
            source: "drag",
            selector: domTarget.selector,
            element: domTarget.element,
            openEditor: true
          });
        }
      }
      event.preventDefault();
      event.stopPropagation();
    });
    toolbar.addEventListener("click", (event) => {
      const target = event.target instanceof Element ? event.target : null;
      const button = target?.closest("button[data-action]");
      const action = button?.dataset.action;
      if (action === "done") setEnabled(state2, false);
      if (action === "mode-area") setMode(state2, "area");
      if (action === "mode-text") setMode(state2, "text");
      if (action === "clear") {
        state2.annotations = [];
        state2.nextId = 1;
        state2.selectedId = null;
        state2.editGesture = null;
        state2.lastSelectionSignature = null;
        closeEditor(state2);
        renderAnnotations(state2);
      }
      if (action) {
        event.preventDefault();
        event.stopPropagation();
      }
    });
    addEventListener(
      "mousemove",
      (event) => {
        const gesture = state2.editGesture;
        if (!gesture) return;
        const annotation = state2.annotations.find((item) => item.id === gesture.annotationId);
        if (!annotation) {
          state2.editGesture = null;
          return;
        }
        if (annotation.kind !== "screenshot") {
          state2.editGesture = null;
          return;
        }
        const dx = event.clientX - gesture.startX;
        const dy = event.clientY - gesture.startY;
        const moved = Math.abs(dx) > 1 || Math.abs(dy) > 1;
        if (moved) gesture.didMove = true;
        const nextRect = gesture.mode === "move" ? clampRect({
          x: gesture.startRect.x + dx,
          y: gesture.startRect.y + dy,
          width: gesture.startRect.width,
          height: gesture.startRect.height
        }) : resizedRect(gesture.startRect, gesture.handle ?? "se", dx, dy);
        replaceAnnotationRect(state2, annotation, nextRect);
        state2.selectedId = annotation.id;
        state2.suppressClickId = annotation.id;
        renderAnnotations(state2);
        event.preventDefault();
        event.stopPropagation();
      },
      true
    );
    addEventListener(
      "mouseup",
      (event) => {
        if (state2.enabled && state2.mode === "text" && !state2.editGesture) {
          window.setTimeout(() => addTextSelectionAnnotation(state2), 0);
          return;
        }
        if (!state2.editGesture) return;
        const didMove = state2.editGesture.didMove;
        if (didMove) state2.suppressClickId = state2.editGesture.annotationId;
        state2.editGesture = null;
        if (didMove) renderAnnotations(state2);
        event.preventDefault();
        event.stopPropagation();
      },
      true
    );
    addEventListener(
      "keydown",
      (event) => {
        if (event.key === "Escape" && state2.enabled) setEnabled(state2, false);
        if ((event.key === "Delete" || event.key === "Backspace") && state2.selectedId !== null && !isTextEditingTarget(event.target)) {
          state2.annotations = state2.annotations.filter((item) => item.id !== state2.selectedId);
          state2.selectedId = null;
          state2.editGesture = null;
          closeEditor(state2);
          renderAnnotations(state2);
          event.preventDefault();
          event.stopPropagation();
        }
      },
      true
    );
    addEventListener(
      "keyup",
      () => {
        if (state2.enabled && state2.mode === "text") {
          window.setTimeout(() => addTextSelectionAnnotation(state2), 0);
        }
      },
      true
    );
    addEventListener("scroll", () => renderAnnotations(state2), true);
    addEventListener("resize", () => renderAnnotations(state2), true);
    ensureRenderTimer(state2);
    return state2;
  };
  const existingState = stateWindow.__abgAnnotationMode;
  const needsState = requestedAction === "start" || requestedAction === "add_region" || requestedAction === "add_selector";
  if (!existingState && !needsState) {
    return {
      ok: true,
      enabled: false,
      count: 0,
      annotations: [],
      nextCommand: "abg annotate <tab>"
    };
  }
  const state = existingState ?? createState();
  stateWindow.__abgAnnotationMode = state;
  state.selectedId ??= null;
  state.editGesture ??= null;
  state.suppressClickId ??= null;
  state.mode ??= "area";
  state.lastSelectionSignature ??= null;
  state.renderTimer ??= null;
  ensureRenderTimer(state);
  if (requestedAction === "start") setEnabled(state, true);
  if (requestedAction === "stop") setEnabled(state, false);
  if (requestedAction === "clear") {
    state.annotations = [];
    state.nextId = 1;
    state.selectedId = null;
    state.editGesture = null;
    closeEditor(state);
    renderAnnotations(state);
  }
  if (requestedAction === "add_region") {
    const { x, y, width, height } = requestedCommand;
    if (typeof x !== "number" || typeof y !== "number" || typeof width !== "number" || typeof height !== "number" || width < 1 || height < 1) {
      throw new Error("add_region requires x, y, width, and height");
    }
    addAutoAnnotation(
      state,
      {
        x,
        y,
        width,
        height
      },
      {
        source: "cli",
        comment: requestedCommand.comment
      }
    );
  }
  if (requestedAction === "add_selector") {
    const selector = requestedCommand.selector;
    if (!selector) throw new Error("add_selector requires selector");
    const element = document.querySelector(selector);
    if (!element) throw new Error(`selector not found: ${selector}`);
    const rect = rectForElement(element);
    addAnnotation(state, rect, {
      kind: "dom",
      source: "cli",
      selector,
      comment: requestedCommand.comment,
      element: metadataForElement(element)
    });
  }
  if (requestedAction === "list") renderAnnotations(state);
  return makeResult(state, requestedAction);
}
async function manageAnnotationMode(tabId, command) {
  try {
    const [res] = await browser.scripting.executeScript({
      target: { tabId },
      func: runAnnotationCommand,
      args: [command]
    });
    return normalizeAnnotationResult(res?.result);
  } catch (error) {
    if (!shouldFallbackToDebuggerRuntime(error)) throw error;
    return evaluateAnnotationModeWithDebugger(tabId, command);
  }
}
function normalizeAnnotationResult(result) {
  if (typeof result === "object" && result !== null && result.ok === true && typeof result.enabled === "boolean" && typeof result.count === "number" && Array.isArray(result.annotations)) {
    return result;
  }
  return {
    ok: true,
    enabled: false,
    count: 0,
    annotations: [],
    nextCommand: "abg annotate <tab>"
  };
}
function shouldFallbackToDebuggerRuntime(error) {
  const message = error instanceof Error ? error.message : String(error);
  return message.includes("Cannot access contents of url") || message.includes("Extension manifest must request permission to access this host");
}
async function evaluateAnnotationModeWithDebugger(tabId, command) {
  const commandSource = JSON.stringify(command).replace(/[<>&\u2028\u2029]/g, (char) => {
    const code = char.charCodeAt(0).toString(16).padStart(4, "0");
    return `\\u${code}`;
  });
  const expression = `
    (() => {
      const runAnnotationCommand = ${runAnnotationCommand.toString()};
      return runAnnotationCommand(${commandSource});
    })()
  `;
  const evaluated = await browser.debugger.sendCommand({ tabId }, "Runtime.evaluate", {
    expression,
    returnByValue: true,
    awaitPromise: false,
    userGesture: true
  });
  if (evaluated.exceptionDetails) {
    const details = evaluated.exceptionDetails.exception?.description ?? String(evaluated.exceptionDetails.exception?.value ?? evaluated.exceptionDetails.text);
    throw new Error(details || "annotation runtime evaluation failed");
  }
  return normalizeAnnotationResult(evaluated.result?.value);
}

// src/backgroundLogic.ts
function detectBrowserKind(userAgent) {
  if (/Edg\//.test(userAgent)) return "edge";
  if (/OPR\//.test(userAgent)) return "opera";
  if (/Brave/.test(userAgent)) return "brave";
  if (/Firefox\//.test(userAgent)) return "firefox";
  if (/Chrome\//.test(userAgent)) return "chrome";
  return "browser";
}
function isShareableTabUrl(url) {
  if (!url) return false;
  try {
    const protocol = new URL(url).protocol;
    return protocol === "http:" || protocol === "https:" || protocol === "file:";
  } catch {
    return false;
  }
}
function originForUrl(url) {
  try {
    return new URL(url).origin;
  } catch {
    return "";
  }
}
async function raiseBrowserTab(browser3, tabId) {
  const tab = await browser3.tabs.get(tabId);
  if (!Number.isInteger(tab.windowId) || (tab.windowId ?? -1) < 0) {
    throw new Error("tab window unavailable");
  }
  const windowId = tab.windowId;
  await browser3.tabs.update(tabId, { active: true });
  await browser3.windows.update(windowId, { focused: true });
  return {
    ok: true,
    tabId,
    windowId,
    active: true,
    windowFocused: true
  };
}
async function raisePermittedBrowserTab(browser3, permittedTabs2, tabId) {
  if (!permittedTabs2.has(tabId)) {
    throw new Error("tab not permitted");
  }
  return raiseBrowserTab(browser3, tabId);
}
function richClipboardPayloadLabel(mime, contentBytes) {
  if (!mime) return " current clipboard payload";
  const byteSuffix = contentBytes === void 0 ? "" : ` (${contentBytes} bytes)`;
  return ` ${quoteForIntentLabel(mime)} clipboard payload${byteSuffix}`;
}
function quoteForIntentLabel(value) {
  return JSON.stringify(value.length > 120 ? `${value.slice(0, 117)}...` : value);
}
function normalizeUploadFiles(params) {
  const raw = params.files ?? params.file;
  const list = Array.isArray(raw) ? raw : raw === void 0 ? [] : [raw];
  if (list.length === 0) {
    throw new Error("file required: provide at least one file path");
  }
  const files = list.filter((f) => typeof f === "string" && f.length > 0);
  if (files.length !== list.length) {
    throw new Error("file required: every file path must be a non-empty string");
  }
  return files;
}
function describeFileAttachFailure(detail) {
  if (/\bNot allowed\b/i.test(detail)) {
    return {
      code: "file_access_required",
      message: 'Chrome blocked access to the local file path. Open chrome://extensions, open Agent Browser Gateway details, enable "Allow access to file URLs", then retry. Chrome applies this explicit local-file grant to debugger attachment on HTTP and HTTPS pages too.'
    };
  }
  return {
    code: "file_attach_failed",
    message: `Chrome rejected the file attachment (${detail}). This usually means the input is inside a cross-origin iframe, is hidden behind a custom upload widget, or the path is not readable by the browser. Verify the selector points to a real top-document input[type=file] and that the file paths are absolute and accessible.`
  };
}
var DEFAULT_AUDIT_DIFF_EXCERPT_CHARS = 160;
function createAuditDiff(before, after, options = {}) {
  const excerptChars = clampExcerptChars(options.excerptChars);
  const text = createAuditDiffField(before.text, after.text, excerptChars);
  const includeHTML = before.html !== void 0 || after.html !== void 0;
  const html = includeHTML ? createAuditDiffField(before.html ?? "", after.html ?? "", excerptChars) : void 0;
  const changed = text.changed || (html?.changed ?? false);
  const preview = [
    `text ${text.changed ? "changed" : "unchanged"} (${text.beforeLength} -> ${text.afterLength} chars)`,
    `- ${text.beforeExcerpt}`,
    `+ ${text.afterExcerpt}`
  ];
  if (html) {
    preview.push(
      `html ${html.changed ? "changed" : "unchanged"} (${html.beforeLength} -> ${html.afterLength} chars)`
    );
  }
  return {
    version: 1,
    changed,
    policy: {
      mode: "hash_and_redacted_excerpts",
      hash: "fnv1a32",
      excerptChars,
      redaction: "email, credential assignment, long digit group, and token-like string masks"
    },
    text,
    ...html ? { html } : {},
    preview
  };
}
function createAuditDiffField(before, after, excerptChars = DEFAULT_AUDIT_DIFF_EXCERPT_CHARS) {
  const changed = before !== after;
  const prefix = commonPrefixLength(before, after);
  const suffix = changed ? commonSuffixLength(before, after, prefix) : 0;
  const beforeChangedLength = changed ? before.length - prefix - suffix : 0;
  const afterChangedLength = changed ? after.length - prefix - suffix : 0;
  return {
    changed,
    beforeHash: stableTextHash(before),
    afterHash: stableTextHash(after),
    beforeLength: before.length,
    afterLength: after.length,
    beforeExcerpt: changed ? changedExcerpt(before, prefix, suffix, excerptChars) : boundedRedactedExcerpt(before, excerptChars),
    afterExcerpt: changed ? changedExcerpt(after, prefix, suffix, excerptChars) : boundedRedactedExcerpt(after, excerptChars),
    beforeTruncated: before.length > excerptChars,
    afterTruncated: after.length > excerptChars,
    diffStart: prefix,
    beforeChangedLength,
    afterChangedLength
  };
}
function stableTextHash(value) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return `fnv1a32:${(hash >>> 0).toString(16).padStart(8, "0")}`;
}
function redactAuditExcerpt(value) {
  return value.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[redacted:email]").replace(
    /\b(api[_-]?key|token|secret|password|passwd|pwd)\s*[:=]\s*["']?[^"'\s<>&]+/gi,
    "$1=[redacted]"
  ).replace(/\b(?:\d[\s-]?){13,19}\b/g, "[redacted:number]").replace(/\b[A-Za-z0-9_-]{32,}\b/g, "[redacted:token]");
}
function clampExcerptChars(value) {
  if (typeof value !== "number" || !Number.isFinite(value)) return DEFAULT_AUDIT_DIFF_EXCERPT_CHARS;
  return Math.max(40, Math.min(512, Math.floor(value)));
}
function boundedRedactedExcerpt(value, limit) {
  const prefix = value.length > limit ? value.slice(0, limit) : value;
  return redactAuditExcerpt(`${prefix}${value.length > limit ? "..." : ""}`);
}
function changedExcerpt(value, prefix, suffix, limit) {
  const context = Math.max(12, Math.floor(limit / 4));
  const changedEnd = value.length - suffix;
  const start = Math.max(0, prefix - context);
  let end = Math.min(value.length, changedEnd + context);
  if (end - start > limit) {
    end = Math.min(value.length, start + limit);
  }
  const excerpt = `${start > 0 ? "..." : ""}${value.slice(start, end)}${end < value.length ? "..." : ""}`;
  return redactAuditExcerpt(excerpt);
}
function commonPrefixLength(a, b) {
  const limit = Math.min(a.length, b.length);
  let index = 0;
  while (index < limit && a[index] === b[index]) index += 1;
  return index;
}
function commonSuffixLength(a, b, prefix) {
  const max = Math.min(a.length, b.length) - prefix;
  let length = 0;
  while (length < max && a[a.length - 1 - length] === b[b.length - 1 - length]) {
    length += 1;
  }
  return length;
}

// src/gatewayEndpoint.ts
function normalizeGatewayWebSocketUrl(value) {
  const configuredUrl = value.trim();
  if (!configuredUrl) {
    throw new Error("Enter a Gateway WebSocket URL.");
  }
  let url;
  try {
    url = new URL(configuredUrl);
  } catch {
    throw new Error("Enter a valid Gateway WebSocket URL.");
  }
  if (url.protocol !== "ws:" && url.protocol !== "wss:") {
    throw new Error("Gateway WebSocket URL must use ws:// or wss://.");
  }
  if (!url.hostname) {
    throw new Error("Gateway WebSocket URL must include a hostname.");
  }
  if (url.username || url.password) {
    throw new Error("Gateway WebSocket URL must not include credentials.");
  }
  if (url.pathname !== "/ws") {
    throw new Error("Gateway WebSocket URL must use the exact /ws path.");
  }
  if (url.search || url.hash) {
    throw new Error("Gateway WebSocket URL must not include a query or fragment.");
  }
  return url.toString();
}
function resolveStoredGatewayWebSocketUrl(storedValue, defaultUrl) {
  const normalizedDefault = normalizeGatewayWebSocketUrl(defaultUrl);
  if (typeof storedValue !== "string") {
    return { url: normalizedDefault, shouldPersist: true };
  }
  try {
    const normalizedStored = normalizeGatewayWebSocketUrl(storedValue);
    return {
      url: normalizedStored,
      shouldPersist: storedValue !== normalizedStored
    };
  } catch {
    return { url: normalizedDefault, shouldPersist: true };
  }
}

// src/gatewayWebSocketConnection.ts
var CONNECTING = 0;
var OPEN = 1;
var GatewayWebSocketConnection = class {
  constructor(options) {
    this.options = options;
    this.endpoint = options.endpoint;
    this.reconnectDelayMs = options.reconnectDelayMs ?? 3e3;
    this.schedule = options.schedule ?? ((callback, delayMs) => setTimeout(callback, delayMs));
    this.cancelScheduled = options.cancelScheduled ?? ((timer) => clearTimeout(timer));
  }
  options;
  endpoint;
  socket = null;
  reconnectTimer = null;
  reconnectDelayMs;
  schedule;
  cancelScheduled;
  setEndpoint(endpoint) {
    this.endpoint = endpoint;
  }
  ensureConnected() {
    if (this.socket && (this.socket.readyState === OPEN || this.socket.readyState === CONNECTING)) {
      return;
    }
    let socket;
    try {
      socket = this.options.createSocket(this.endpoint);
      this.socket = socket;
    } catch (error) {
      this.options.onWarning("[ABG] WS construct failed", error);
      this.scheduleReconnect();
      return;
    }
    socket.addEventListener("open", () => {
      if (this.socket !== socket) {
        socket.close();
        return;
      }
      this.options.onConnectionChange(true);
      Promise.resolve(this.options.onOpen()).catch((error) => {
        this.options.onWarning("[ABG] WS open handler failed", error);
      });
    });
    socket.addEventListener("message", (event) => {
      if (this.socket !== socket) return;
      this.options.onMessage(event);
    });
    socket.addEventListener("close", () => {
      if (this.socket !== socket) return;
      this.socket = null;
      this.options.onConnectionChange(false);
      this.scheduleReconnect();
    });
    socket.addEventListener("error", () => {
      if (this.socket !== socket) return;
      this.socket = null;
      this.options.onConnectionChange(false);
      try {
        socket.close();
      } catch {
      }
      this.scheduleReconnect();
    });
  }
  reconnect(endpoint) {
    this.endpoint = endpoint;
    this.cancelReconnect();
    const previousSocket = this.socket;
    this.socket = null;
    this.options.onConnectionChange(false);
    if (previousSocket && (previousSocket.readyState === OPEN || previousSocket.readyState === CONNECTING)) {
      previousSocket.close();
    }
    this.ensureConnected();
  }
  send(data) {
    if (!this.socket || this.socket.readyState !== OPEN) return false;
    this.socket.send(data);
    return true;
  }
  scheduleReconnect() {
    if (this.reconnectTimer !== null) return;
    this.reconnectTimer = this.schedule(() => {
      this.reconnectTimer = null;
      this.ensureConnected();
    }, this.reconnectDelayMs);
  }
  cancelReconnect() {
    if (this.reconnectTimer === null) return;
    this.cancelScheduled(this.reconnectTimer);
    this.reconnectTimer = null;
  }
};

// src/background.ts
var browser2 = browserAdapter;
var DEFAULT_GATEWAY_WEBSOCKET_URL = normalizeGatewayWebSocketUrl("ws://127.0.0.1:8765/ws");
var VERSION = "0.4.4";
var ALL_URLS_ORIGINS = ["<all_urls>"];
var BOOKMARKS_PERMISSION = "bookmarks";
var READING_LIST_PERMISSION = "readingList";
var HEARTBEAT_PERIOD_MIN = 0.5;
var APPROVAL_TIMEOUT_MS = 6e4;
var APPROVAL_WINDOW_FALLBACK_TIMEOUT_MS = APPROVAL_TIMEOUT_MS + 2e3;
var EVAL_DEFAULT_MAX_BYTES = 64 * 1024;
var EVAL_HARD_MAX_BYTES = 256 * 1024;
var DEFAULT_SETTINGS = {
  operationsRequireApproval: true,
  evalEnabled: false,
  trustedAutomationEnabled: false,
  profileLabel: "",
  gatewayWebSocketUrl: DEFAULT_GATEWAY_WEBSOCKET_URL,
  allTabsAccessEnabled: false,
  bookmarksAccessEnabled: false,
  readingListAccessEnabled: false
};
var OPERATION_METHODS = /* @__PURE__ */ new Set([
  "click_selector",
  "click_described",
  "click_at",
  "click_ref",
  "dblclick_selector",
  "focus_selector",
  "hover_selector",
  "select_option",
  "set_checked",
  "fill",
  "paste",
  "paste_rich",
  "clear",
  "replace_dom",
  "upload_file",
  "type_text",
  "key_press",
  "key_down",
  "key_up",
  "keyboard_insert_text",
  "exec_command",
  "navigate",
  "sandbox_action",
  "scroll",
  "scroll_into_view",
  "dialog_action",
  "drag"
]);
var GatewayError = class extends Error {
  code;
  constructor(code, message) {
    super(message);
    this.name = "GatewayError";
    this.code = code;
  }
};
var permittedTabs = /* @__PURE__ */ new Map();
var consoleBuffers = /* @__PURE__ */ new Map();
var networkBuffers = /* @__PURE__ */ new Map();
var activeNetworkRequests = /* @__PURE__ */ new Map();
var pendingDialogs = /* @__PURE__ */ new Map();
var downloadsByTab = /* @__PURE__ */ new Map();
var downloadIdToTab = /* @__PURE__ */ new Map();
var downloadGuidToTab = /* @__PURE__ */ new Map();
var snapshotRefCache = /* @__PURE__ */ new Map();
var attachedTabs = /* @__PURE__ */ new Set();
var streamingTabs = /* @__PURE__ */ new Set();
var pendingApprovals = /* @__PURE__ */ new Map();
var recordingSession = null;
var extensionId = null;
var wsConnected = false;
var gatewayWebSocketConnection = new GatewayWebSocketConnection({
  endpoint: DEFAULT_GATEWAY_WEBSOCKET_URL,
  createSocket: (endpoint) => new WebSocket(endpoint),
  onConnectionChange: (connected) => {
    wsConnected = connected;
  },
  onOpen: async () => {
    const { profileLabel } = await getSettings();
    sendWS({
      type: "hello",
      extensionId: extensionId ?? "?",
      version: VERSION,
      profileLabel: profileLabel || void 0,
      browserKind: await detectCurrentBrowserKind()
    });
    await reconcileAllTabsAccess({ emit: false });
    for (const [tabId, permittedTab] of permittedTabs) {
      sendTabPermitted(tabId, permittedTab);
    }
  },
  onMessage: (event) => {
    try {
      const command = JSON.parse(event.data);
      handleGatewayCommand(command);
    } catch (error) {
      console.warn("[ABG] WS message parse error", error);
    }
  },
  onWarning: (message, error) => {
    console.warn(message, error);
  }
});
(async () => {
  extensionId = await getOrCreateExtensionId();
  const settings = await ensureSettingsStored();
  gatewayWebSocketConnection.setEndpoint(settings.gatewayWebSocketUrl);
  await restoreState();
  await reconcileAllTabsAccess();
  ensureWS();
})();
browser2.runtime.onInstalled.addListener(async () => {
  extensionId = await getOrCreateExtensionId();
  await ensureSettingsStored();
});
browser2.runtime.onStartup.addListener(async () => {
  extensionId = await getOrCreateExtensionId();
  const settings = await ensureSettingsStored();
  gatewayWebSocketConnection.setEndpoint(settings.gatewayWebSocketUrl);
  await restoreState();
  await reconcileAllTabsAccess();
  ensureWS();
});
browser2.alarms.create("heartbeat", { periodInMinutes: HEARTBEAT_PERIOD_MIN });
browser2.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "heartbeat") {
    ensureWS();
  }
});
async function getOrCreateExtensionId() {
  const stored = await browser2.storage.local.get("extensionId");
  if (typeof stored.extensionId === "string") return stored.extensionId;
  const id = crypto.randomUUID();
  await browser2.storage.local.set({ extensionId: id });
  return id;
}
async function getSettings() {
  const stored = await browser2.storage.local.get([
    "operationsRequireApproval",
    "evalEnabled",
    "trustedAutomationEnabled",
    "profileLabel",
    "gatewayWebSocketUrl",
    "allTabsAccessEnabled",
    "bookmarksAccessEnabled",
    "readingListAccessEnabled"
  ]);
  const operationsRequireApproval = typeof stored.operationsRequireApproval === "boolean" ? stored.operationsRequireApproval : DEFAULT_SETTINGS.operationsRequireApproval;
  const evalEnabled = typeof stored.evalEnabled === "boolean" ? stored.evalEnabled : DEFAULT_SETTINGS.evalEnabled;
  const trustedAutomationEnabled = typeof stored.trustedAutomationEnabled === "boolean" ? stored.trustedAutomationEnabled : DEFAULT_SETTINGS.trustedAutomationEnabled;
  const profileLabel = typeof stored.profileLabel === "string" ? stored.profileLabel : DEFAULT_SETTINGS.profileLabel;
  const gatewayWebSocketUrl = resolveStoredGatewayWebSocketUrl(
    stored.gatewayWebSocketUrl,
    DEFAULT_SETTINGS.gatewayWebSocketUrl
  );
  const allTabsAccessEnabled = typeof stored.allTabsAccessEnabled === "boolean" ? stored.allTabsAccessEnabled : DEFAULT_SETTINGS.allTabsAccessEnabled;
  const bookmarksAccessEnabled = typeof stored.bookmarksAccessEnabled === "boolean" ? stored.bookmarksAccessEnabled : DEFAULT_SETTINGS.bookmarksAccessEnabled;
  const readingListAccessEnabled = typeof stored.readingListAccessEnabled === "boolean" ? stored.readingListAccessEnabled : DEFAULT_SETTINGS.readingListAccessEnabled;
  if (typeof stored.operationsRequireApproval !== "boolean" || typeof stored.evalEnabled !== "boolean" || typeof stored.trustedAutomationEnabled !== "boolean" || typeof stored.profileLabel !== "string" || gatewayWebSocketUrl.shouldPersist || typeof stored.allTabsAccessEnabled !== "boolean" || typeof stored.bookmarksAccessEnabled !== "boolean" || typeof stored.readingListAccessEnabled !== "boolean") {
    await browser2.storage.local.set({
      operationsRequireApproval,
      evalEnabled,
      trustedAutomationEnabled,
      profileLabel,
      gatewayWebSocketUrl: gatewayWebSocketUrl.url,
      allTabsAccessEnabled,
      bookmarksAccessEnabled,
      readingListAccessEnabled
    });
  }
  return {
    operationsRequireApproval,
    evalEnabled,
    trustedAutomationEnabled,
    profileLabel,
    gatewayWebSocketUrl: gatewayWebSocketUrl.url,
    allTabsAccessEnabled,
    bookmarksAccessEnabled,
    readingListAccessEnabled
  };
}
async function ensureSettingsStored() {
  return await getSettings();
}
async function setOperationsRequireApproval(value) {
  const current = await getSettings();
  const settings = { ...current, operationsRequireApproval: value };
  await browser2.storage.local.set(settings);
  return settings;
}
async function setEvalEnabled(value) {
  const current = await getSettings();
  const settings = { ...current, evalEnabled: value };
  await browser2.storage.local.set(settings);
  return settings;
}
async function setTrustedAutomationEnabled(value) {
  const current = await getSettings();
  const settings = { ...current, trustedAutomationEnabled: value };
  await browser2.storage.local.set(settings);
  return settings;
}
async function setProfileLabel(value) {
  const current = await getSettings();
  const trimmed = value.trim();
  const settings = { ...current, profileLabel: trimmed };
  await browser2.storage.local.set(settings);
  if (extensionId) {
    sendWS({
      type: "hello",
      extensionId,
      version: VERSION,
      profileLabel: trimmed || void 0,
      browserKind: await detectCurrentBrowserKind()
    });
  }
  return settings;
}
async function setGatewayWebSocketUrl(value) {
  const normalizedUrl = normalizeGatewayWebSocketUrl(value);
  const current = await getSettings();
  const settings = { ...current, gatewayWebSocketUrl: normalizedUrl };
  await browser2.storage.local.set(settings);
  gatewayWebSocketConnection.reconnect(normalizedUrl);
  return settings;
}
async function setAllTabsAccessEnabled(value) {
  const current = await getSettings();
  if (value && !await hasAllUrlsPermission()) {
    throw new GatewayError(
      "all_tabs_permission_required",
      "Chrome has not granted ABG optional access to all sites in this profile."
    );
  }
  const settings = { ...current, allTabsAccessEnabled: value };
  await browser2.storage.local.set(settings);
  if (value) {
    await syncAllTabsAccess({ emit: true });
  } else {
    await revokeAllTabsEntries("all_tabs_disabled");
  }
  return settings;
}
async function setBookmarksAccessEnabled(value) {
  const current = await getSettings();
  if (value) {
    ensureBookmarksSupported();
    if (!await hasBookmarksPermission()) {
      throw new GatewayError(
        "bookmarks_permission_required",
        "Chrome has not granted ABG optional access to bookmarks in this profile."
      );
    }
  }
  const settings = { ...current, bookmarksAccessEnabled: value };
  await browser2.storage.local.set(settings);
  return settings;
}
async function setReadingListAccessEnabled(value) {
  const current = await getSettings();
  if (value) {
    ensureReadingListSupported();
    if (!await hasReadingListPermission()) {
      throw new GatewayError(
        "reading_list_permission_required",
        "Chrome has not granted ABG optional access to Reading List in this profile."
      );
    }
  }
  const settings = { ...current, readingListAccessEnabled: value };
  await browser2.storage.local.set(settings);
  return settings;
}
async function hasAllUrlsPermission() {
  try {
    return await browser2.permissions.contains({ origins: ALL_URLS_ORIGINS });
  } catch {
    return false;
  }
}
async function hasBookmarksPermission() {
  try {
    return await browser2.permissions.contains({ permissions: [BOOKMARKS_PERMISSION] });
  } catch {
    return false;
  }
}
async function hasReadingListPermission() {
  try {
    return await browser2.permissions.contains({ permissions: [READING_LIST_PERMISSION] });
  } catch {
    return false;
  }
}
async function isAllTabsAccessActive() {
  const settings = await getSettings();
  return settings.allTabsAccessEnabled && await hasAllUrlsPermission();
}
async function isBookmarksAccessActive() {
  const settings = await getSettings();
  return settings.bookmarksAccessEnabled && await hasBookmarksPermission();
}
async function isReadingListAccessActive() {
  const settings = await getSettings();
  return settings.readingListAccessEnabled && await hasReadingListPermission();
}
async function isIncognitoAccessAllowed() {
  try {
    return await browser2.extension.isAllowedIncognitoAccess();
  } catch {
    return false;
  }
}
async function detectCurrentBrowserKind() {
  if (browser2.kind === "firefox") return "firefox";
  const brave = navigator.brave;
  if (typeof brave?.isBrave === "function") {
    try {
      if (await brave.isBrave()) return "brave";
    } catch {
    }
  }
  return detectBrowserKind(navigator.userAgent);
}
async function saveState() {
  const obj = {};
  for (const [k, v] of permittedTabs) obj[String(k)] = v;
  await browser2.storage.session.set({ permittedTabs: obj });
}
async function restoreState() {
  const stored = await browser2.storage.session.get("permittedTabs");
  const obj = stored.permittedTabs;
  if (!obj) return;
  for (const [k, v] of Object.entries(obj)) {
    permittedTabs.set(Number(k), { ...v, accessMode: v.accessMode ?? "manual" });
  }
}
function ensureWS() {
  gatewayWebSocketConnection.ensureConnected();
}
function sendWS(msg) {
  gatewayWebSocketConnection.send(JSON.stringify(msg));
}
function emitStreamEvent(tabId, event) {
  if (!streamingTabs.has(tabId)) return;
  sendWS({
    type: "runtime_event",
    tabId,
    event: {
      ...event,
      ts: (/* @__PURE__ */ new Date()).toISOString()
    }
  });
}
function sendTabPermitted(tabId, tab) {
  sendWS({
    type: "tab_permitted",
    tabId,
    url: tab.url,
    title: tab.title,
    origin: tab.origin,
    expiresAt: tab.expiresAt ? new Date(tab.expiresAt).toISOString() : void 0,
    accessMode: tab.accessMode
  });
}
function sendTabUpdated(tabId, tab) {
  sendWS({
    type: "tab_updated",
    tabId,
    url: tab.url,
    title: tab.title,
    origin: tab.origin,
    accessMode: tab.accessMode
  });
}
async function reconcileAllTabsAccess(options = {}) {
  const settings = await getSettings();
  if (!settings.allTabsAccessEnabled) {
    await revokeAllTabsEntries("all_tabs_disabled");
    return;
  }
  if (!await hasAllUrlsPermission()) {
    await revokeAllTabsEntries("all_tabs_permission_missing");
    return;
  }
  await syncAllTabsAccess(options);
}
async function syncAllTabsAccess(options = {}) {
  const emit = options.emit ?? true;
  const tabs = await browser2.tabs.query({});
  const shareableTabIds = /* @__PURE__ */ new Set();
  let skippedTabCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number" || !isShareableTabUrl(tab.url)) {
      skippedTabCount += 1;
      continue;
    }
    shareableTabIds.add(tab.id);
    await upsertAllTabsEntry(tab, emit);
  }
  const staleAllTabs = Array.from(permittedTabs.entries()).filter(([tabId, tab]) => tab.accessMode === "all_tabs" && !shareableTabIds.has(tabId)).map(([tabId]) => tabId);
  for (const tabId of staleAllTabs) {
    await revokeTab(tabId, "all_tabs_not_shareable");
  }
  await saveState();
  return { shareableTabCount: shareableTabIds.size, skippedTabCount };
}
async function allTabsAccessState() {
  const [settings, permissionGranted, tabs] = await Promise.all([
    getSettings(),
    hasAllUrlsPermission(),
    browser2.tabs.query({}).catch(() => [])
  ]);
  let shareableTabCount = 0;
  let skippedTabCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id === "number" && isShareableTabUrl(tab.url)) shareableTabCount += 1;
    else skippedTabCount += 1;
  }
  return {
    permissionGranted,
    active: settings.allTabsAccessEnabled && permissionGranted,
    shareableTabCount,
    skippedTabCount
  };
}
async function personalDataAccessState() {
  const [settings, bookmarksPermissionGranted, readingListPermissionGranted] = await Promise.all([
    getSettings(),
    hasBookmarksPermission(),
    hasReadingListPermission()
  ]);
  return {
    bookmarks: {
      permissionGranted: bookmarksPermissionGranted,
      active: settings.bookmarksAccessEnabled && bookmarksPermissionGranted,
      supported: !!browser2.bookmarks
    },
    readingList: {
      permissionGranted: readingListPermissionGranted,
      active: settings.readingListAccessEnabled && readingListPermissionGranted,
      supported: !!browser2.readingList
    }
  };
}
async function upsertAllTabsEntry(tab, emit) {
  if (typeof tab.id !== "number" || !isShareableTabUrl(tab.url)) return;
  const tabId = tab.id;
  const url = tab.url;
  const origin = originForUrl(url);
  const title = tab.title ?? "";
  const existing = permittedTabs.get(tabId);
  if (existing?.accessMode === "manual" && existing.origin === origin) {
    existing.url = url;
    existing.title = title;
    permittedTabs.set(tabId, existing);
    if (emit) sendTabUpdated(tabId, existing);
    await updateBadge(tabId);
    return;
  }
  if (existing?.accessMode === "manual") {
    sendWS({ type: "tab_revoked", tabId, reason: "manual_origin_changed_during_all_tabs" });
  }
  const entry = {
    url,
    title,
    origin,
    permittedAt: existing?.permittedAt ?? Date.now(),
    accessMode: "all_tabs"
  };
  permittedTabs.set(tabId, entry);
  if (emit) {
    if (existing?.accessMode === "all_tabs") sendTabUpdated(tabId, entry);
    else sendTabPermitted(tabId, entry);
  }
  await updateBadge(tabId);
}
async function revokeAllTabsEntries(reason) {
  const tabIds = Array.from(permittedTabs.entries()).filter(([, tab]) => tab.accessMode === "all_tabs").map(([tabId]) => tabId);
  for (const tabId of tabIds) {
    await revokeTab(tabId, reason);
  }
}
async function permitTab(tabId) {
  const tab = await browser2.tabs.get(tabId);
  if (!tab.url) throw new Error("tab has no URL");
  if (tab.incognito && !await isIncognitoAccessAllowed()) {
    throw new GatewayError(
      "incognito_access_disabled",
      `Chrome has not allowed Agent Browser Gateway to run in incognito windows. Open chrome://extensions/?id=${browser2.runtime.id} and enable "Allow in incognito".`
    );
  }
  const url = tab.url;
  const origin = originForUrl(url);
  const title = tab.title ?? "";
  const entry = {
    url,
    title,
    origin,
    permittedAt: Date.now(),
    accessMode: "manual"
  };
  permittedTabs.set(tabId, entry);
  await saveState();
  sendTabPermitted(tabId, entry);
  await attachDebugger(tabId);
  await updateBadge(tabId);
}
async function revokeTab(tabId, reason) {
  if (!permittedTabs.has(tabId)) return;
  permittedTabs.delete(tabId);
  consoleBuffers.delete(tabId);
  networkBuffers.delete(tabId);
  pendingDialogs.delete(tabId);
  downloadsByTab.delete(tabId);
  for (const [downloadId, mappedTabId] of downloadIdToTab) {
    if (mappedTabId === tabId) downloadIdToTab.delete(downloadId);
  }
  for (const [guid, mappedTabId] of downloadGuidToTab) {
    if (mappedTabId === tabId) downloadGuidToTab.delete(guid);
  }
  streamingTabs.delete(tabId);
  stopRecordingForTab(tabId);
  await saveState();
  sendWS({ type: "tab_revoked", tabId, reason });
  await detachDebugger(tabId);
  await updateBadge(tabId);
}
async function updateBadge(tabId) {
  const tab = permittedTabs.get(tabId);
  const isRecording = recordingSession?.tabId === tabId;
  try {
    await browser2.action.setBadgeText({
      tabId,
      text: isRecording ? "REC" : tab ? tab.accessMode === "all_tabs" ? "ALL" : "ON" : ""
    });
    if (isRecording) {
      await browser2.action.setBadgeBackgroundColor({ tabId, color: "#ff3b30" });
    } else if (tab) {
      await browser2.action.setBadgeBackgroundColor({
        tabId,
        color: tab.accessMode === "all_tabs" ? "#0a84ff" : "#34c759"
      });
    }
  } catch {
  }
}
browser2.tabs.onCreated.addListener(async (tab) => {
  if (await isAllTabsAccessActive() && isShareableTabUrl(tab.url)) {
    await upsertAllTabsEntry(tab, true);
    await saveState();
  }
});
browser2.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  const currentUrl = tab.url ?? changeInfo.url;
  if (await isAllTabsAccessActive() && isShareableTabUrl(currentUrl)) {
    await upsertAllTabsEntry({ ...tab, id: tabId, url: currentUrl }, true);
    await saveState();
    return;
  }
  if (!permittedTabs.has(tabId)) return;
  const old = permittedTabs.get(tabId);
  if (!old) return;
  if (old.accessMode === "all_tabs") {
    await revokeTab(tabId, "all_tabs_not_shareable");
    return;
  }
  if (changeInfo.url) {
    let newOrigin = "";
    try {
      newOrigin = new URL(changeInfo.url).origin;
    } catch {
    }
    if (newOrigin && newOrigin !== old.origin) {
      await revokeTab(tabId, "origin_changed");
      return;
    }
    old.url = changeInfo.url;
    if (tab.title) old.title = tab.title;
    permittedTabs.set(tabId, old);
    await saveState();
    sendTabUpdated(tabId, old);
  } else if (changeInfo.title) {
    old.title = changeInfo.title;
    permittedTabs.set(tabId, old);
    await saveState();
    sendTabUpdated(tabId, old);
  }
});
browser2.tabs.onRemoved.addListener(async (tabId) => {
  if (permittedTabs.has(tabId)) {
    permittedTabs.delete(tabId);
    consoleBuffers.delete(tabId);
    networkBuffers.delete(tabId);
    pendingDialogs.delete(tabId);
    downloadsByTab.delete(tabId);
    for (const [downloadId, mappedTabId] of downloadIdToTab) {
      if (mappedTabId === tabId) downloadIdToTab.delete(downloadId);
    }
    for (const [guid, mappedTabId] of downloadGuidToTab) {
      if (mappedTabId === tabId) downloadGuidToTab.delete(guid);
    }
    streamingTabs.delete(tabId);
    stopRecordingForTab(tabId);
    await saveState();
    sendWS({ type: "tab_closed", tabId });
    await detachDebugger(tabId);
  }
});
browser2.tabs.onActivated.addListener(async ({ tabId }) => {
  await updateBadge(tabId);
});
browser2.windows.onRemoved.addListener((windowId) => {
  for (const [approvalId, pending] of pendingApprovals) {
    if (pending.windowId === windowId) {
      finalizeApproval(approvalId, {
        decision: "deny",
        message: "Operation denied because the approval window was closed."
      });
      break;
    }
  }
});
async function attachDebugger(tabId) {
  if (attachedTabs.has(tabId)) return;
  try {
    await browser2.debugger.attach({ tabId }, "1.3");
    await browser2.debugger.sendCommand({ tabId }, "Runtime.enable");
    await browser2.debugger.sendCommand({ tabId }, "Network.enable");
    await browser2.debugger.sendCommand({ tabId }, "Page.enable");
    attachedTabs.add(tabId);
  } catch (e) {
    console.warn("[ABG] debugger.attach failed", e);
  }
}
async function detachDebugger(tabId) {
  if (!attachedTabs.has(tabId)) return;
  try {
    await browser2.debugger.detach({ tabId });
  } catch {
  }
  attachedTabs.delete(tabId);
}
browser2.debugger.onEvent.addListener((source, method, params) => {
  if (!source.tabId) return;
  if (method === "Runtime.consoleAPICalled") {
    const p = params;
    const text = p.args.map(
      (a) => a.value !== void 0 ? typeof a.value === "string" ? a.value : JSON.stringify(a.value) : a.description ?? a.type
    ).join(" ");
    const buf = consoleBuffers.get(source.tabId) ?? [];
    buf.push({ ts: Date.now(), level: p.type, text });
    while (buf.length > 200) buf.shift();
    consoleBuffers.set(source.tabId, buf);
    emitStreamEvent(source.tabId, { kind: "console", level: p.type, text });
  } else if (method === "Runtime.exceptionThrown") {
    const ex = params.exceptionDetails;
    if (!ex) return;
    const text = ex.exception?.description ?? ex.text ?? "(unknown exception)";
    const buf = consoleBuffers.get(source.tabId) ?? [];
    buf.push({ ts: Date.now(), level: "error", text });
    while (buf.length > 200) buf.shift();
    consoleBuffers.set(source.tabId, buf);
    emitStreamEvent(source.tabId, { kind: "console", level: "error", text });
  } else if (method === "Page.javascriptDialogOpening") {
    const p = params;
    const dialog = {
      type: p.type ?? "unknown",
      message: p.message ?? "",
      defaultPrompt: p.defaultPrompt,
      url: p.url,
      openedAt: Date.now()
    };
    pendingDialogs.set(source.tabId, dialog);
    emitStreamEvent(source.tabId, {
      kind: "dialog",
      phase: "opening",
      dialog: publicDialogState(source.tabId).dialog
    });
  } else if (method === "Page.javascriptDialogClosed") {
    const dialog = pendingDialogs.get(source.tabId);
    pendingDialogs.delete(source.tabId);
    emitStreamEvent(source.tabId, {
      kind: "dialog",
      phase: "closed",
      dialog: dialog ? publicDialog(dialog) : void 0
    });
  } else if (method === "Page.downloadWillBegin") {
    const p = params;
    if (p.guid && p.url) {
      const record = upsertTabDownload(source.tabId, {
        id: p.guid,
        guid: p.guid,
        tabId: source.tabId,
        url: p.url,
        suggestedFilename: p.suggestedFilename,
        status: "in_progress",
        startedAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: Date.now()
      });
      downloadGuidToTab.set(p.guid, source.tabId);
      emitStreamEvent(source.tabId, {
        kind: "download",
        phase: "started",
        download: publicDownload(record)
      });
    }
  } else if (method === "Page.downloadProgress") {
    const p = params;
    const tabId = p.guid ? downloadGuidToTab.get(p.guid) : void 0;
    if (p.guid && tabId) {
      const status = p.state === "completed" ? "complete" : p.state === "canceled" ? "interrupted" : "in_progress";
      const record = upsertTabDownload(tabId, {
        id: p.guid,
        guid: p.guid,
        tabId,
        url: "",
        status,
        bytesReceived: p.receivedBytes,
        totalBytes: p.totalBytes,
        startedAt: (/* @__PURE__ */ new Date()).toISOString(),
        endedAt: status === "in_progress" ? void 0 : (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: Date.now(),
        error: p.state === "canceled" ? "CANCELED" : void 0
      });
      emitStreamEvent(tabId, {
        kind: "download",
        phase: status === "in_progress" ? "progress" : status,
        download: publicDownload(record)
      });
    }
  } else if (method === "Network.requestWillBeSent") {
    const p = params;
    const buf = networkBuffers.get(source.tabId) ?? [];
    const active = activeNetworkRequests.get(source.tabId) ?? /* @__PURE__ */ new Set();
    active.add(p.requestId);
    activeNetworkRequests.set(source.tabId, active);
    buf.push({
      requestId: p.requestId,
      method: p.request.method,
      url: p.request.url,
      type: p.type?.toLowerCase(),
      ts: new Date((p.wallTime ?? Date.now() / 1e3) * 1e3).toISOString(),
      startTime: p.timestamp
    });
    emitStreamEvent(source.tabId, {
      kind: "network",
      phase: "request",
      requestId: p.requestId,
      method: p.request.method,
      url: p.request.url,
      resourceType: p.type?.toLowerCase()
    });
    while (buf.length > 200) buf.shift();
    networkBuffers.set(source.tabId, buf);
  } else if (method === "Network.responseReceived") {
    const p = params;
    const entry = findNetworkEntry(source.tabId, p.requestId);
    if (entry) {
      entry.type = p.type?.toLowerCase() ?? entry.type;
      entry.status = p.response.status;
      entry.statusText = p.response.statusText;
      entry.mimeType = p.response.mimeType;
      if (p.response.url) entry.url = p.response.url;
    }
    emitStreamEvent(source.tabId, {
      kind: "network",
      phase: "response",
      requestId: p.requestId,
      status: p.response.status,
      url: p.response.url,
      resourceType: p.type?.toLowerCase()
    });
  } else if (method === "Network.loadingFinished") {
    const p = params;
    activeNetworkRequests.get(source.tabId)?.delete(p.requestId);
    const entry = findNetworkEntry(source.tabId, p.requestId);
    if (entry) {
      entry.durationMs = Math.max(0, Math.round((p.timestamp - entry.startTime) * 1e3));
      entry.encodedDataLength = p.encodedDataLength;
    }
    emitStreamEvent(source.tabId, {
      kind: "network",
      phase: "finished",
      requestId: p.requestId,
      encodedDataLength: p.encodedDataLength
    });
  } else if (method === "Network.loadingFailed") {
    const p = params;
    activeNetworkRequests.get(source.tabId)?.delete(p.requestId);
    const entry = findNetworkEntry(source.tabId, p.requestId);
    if (entry) {
      entry.durationMs = Math.max(0, Math.round((p.timestamp - entry.startTime) * 1e3));
      entry.errorText = p.errorText;
    }
    emitStreamEvent(source.tabId, {
      kind: "network",
      phase: "failed",
      requestId: p.requestId,
      errorText: p.errorText
    });
  }
});
browser2.debugger.onDetach.addListener((source) => {
  if (source.tabId) attachedTabs.delete(source.tabId);
});
browser2.downloads.onCreated.addListener((item) => {
  void handleDownloadCreated(item);
});
browser2.downloads.onChanged.addListener((delta) => {
  void handleDownloadChanged(delta);
});
function upsertTabDownload(tabId, patch) {
  const records = downloadsByTab.get(tabId) ?? [];
  const existing = records.find(
    (record) => patch.guid && record.guid === patch.guid || patch.browserDownloadId !== void 0 && record.browserDownloadId === patch.browserDownloadId || record.id === patch.id
  );
  const merged = existing ? {
    ...existing,
    ...patch,
    url: patch.url || existing.url,
    startedAt: existing.startedAt || patch.startedAt,
    updatedAt: Date.now()
  } : { ...patch, updatedAt: Date.now() };
  if (!existing) records.push(merged);
  else records[records.indexOf(existing)] = merged;
  records.sort((left, right) => Date.parse(left.startedAt) - Date.parse(right.startedAt));
  while (records.length > 50) records.shift();
  downloadsByTab.set(tabId, records);
  if (merged.browserDownloadId !== void 0) downloadIdToTab.set(merged.browserDownloadId, tabId);
  if (merged.guid) downloadGuidToTab.set(merged.guid, tabId);
  return merged;
}
function resolveDownloadTab(item) {
  const mapped = downloadIdToTab.get(item.id);
  if (mapped !== void 0) return mapped;
  for (const [tabId, records] of downloadsByTab) {
    const match = records.slice().reverse().find(
      (record) => !record.browserDownloadId && (record.url === item.url || record.url === item.finalUrl)
    );
    if (match) return tabId;
  }
  if (item.referrer) {
    for (const [tabId, tab] of permittedTabs) {
      if (tab.url === item.referrer || originForUrl(tab.url) === originForUrl(item.referrer)) {
        return tabId;
      }
    }
  }
  return void 0;
}
function recordFromDownloadItem(item, tabId, existingId) {
  return {
    id: existingId ?? `download-${item.id}`,
    tabId,
    browserDownloadId: item.id,
    url: item.url,
    finalUrl: item.finalUrl,
    referrer: item.referrer,
    suggestedFilename: item.filename ? item.filename.split(/[\\/]/).pop() : void 0,
    filename: item.filename,
    mime: item.mime,
    status: item.state,
    error: item.error,
    bytesReceived: item.bytesReceived,
    totalBytes: item.totalBytes,
    fileSize: item.fileSize,
    exists: item.exists,
    startedAt: item.startTime,
    endedAt: item.endTime,
    updatedAt: Date.now()
  };
}
async function handleDownloadCreated(item) {
  const tabId = resolveDownloadTab(item);
  if (tabId === void 0 || !permittedTabs.has(tabId)) return;
  const existing = (downloadsByTab.get(tabId) ?? []).slice().reverse().find(
    (record2) => !record2.browserDownloadId && (record2.url === item.url || record2.url === item.finalUrl)
  );
  const record = upsertTabDownload(tabId, recordFromDownloadItem(item, tabId, existing?.id));
  emitStreamEvent(tabId, {
    kind: "download",
    phase: "created",
    download: publicDownload(record)
  });
}
async function handleDownloadChanged(delta) {
  let tabId = downloadIdToTab.get(delta.id);
  let item;
  if (tabId === void 0) {
    const found = await browser2.downloads.search({ id: delta.id });
    item = found[0];
    if (!item) return;
    tabId = resolveDownloadTab(item);
  }
  if (tabId === void 0 || !permittedTabs.has(tabId)) return;
  item = item ?? (await browser2.downloads.search({ id: delta.id }))[0];
  if (!item) return;
  const existing = (downloadsByTab.get(tabId) ?? []).find(
    (record2) => record2.browserDownloadId === delta.id
  );
  const record = upsertTabDownload(tabId, recordFromDownloadItem(item, tabId, existing?.id));
  emitStreamEvent(tabId, {
    kind: "download",
    phase: record.status === "in_progress" ? "progress" : record.status,
    download: publicDownload(record)
  });
}
function findNetworkEntry(tabId, requestId) {
  const buf = networkBuffers.get(tabId);
  if (!buf) return void 0;
  for (let i = buf.length - 1; i >= 0; i--) {
    const entry = buf[i];
    if (entry?.requestId === requestId) return entry;
  }
  return void 0;
}
async function handleGatewayCommand(cmd) {
  const tabId = cmd.params?.tabId;
  try {
    if (cmd.method === "bookmarks_list") {
      reply(cmd.id, await listBookmarks(cmd.params ?? {}));
    } else if (cmd.method === "bookmarks_search") {
      reply(cmd.id, await searchBookmarks(cmd.params ?? {}));
    } else if (cmd.method === "bookmarks_get") {
      reply(cmd.id, await getBookmark(cmd.params ?? {}));
    } else if (cmd.method === "bookmarks_open") {
      reply(cmd.id, await openBookmark(cmd.params ?? {}));
    } else if (cmd.method === "reading_list_list") {
      reply(cmd.id, await listReadingList(cmd.params ?? {}));
    } else if (cmd.method === "reading_list_search") {
      reply(cmd.id, await searchReadingList(cmd.params ?? {}));
    } else if (cmd.method === "raise_tab") {
      if (!tabId) throw new Error("tab not permitted");
      reply(cmd.id, await raisePermittedBrowserTab(browser2, permittedTabs, tabId));
    } else if (cmd.method === "frames") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await listFrames(tabId));
    } else if (cmd.method === "read_dom") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      const result = await readDom(tabId, cmd.params?.selector, readFrameParam(cmd.params));
      reply(cmd.id, result);
    } else if (cmd.method === "get_dom") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await getDomValue(tabId, cmd.params ?? {}));
    } else if (cmd.method === "predicate") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await getPredicate(tabId, cmd.params ?? {}));
    } else if (cmd.method === "find") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await runFindCommand(tabId, cmd.params ?? {}));
    } else if (cmd.method === "snapshot") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await snapshotTab(tabId, cmd.params ?? {}));
    } else if (cmd.method === "screenshot") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      const result = await screenshot(tabId, cmd.params?.clip);
      reply(cmd.id, result);
    } else if (cmd.method === "pdf") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await printPagePDF(tabId));
    } else if (cmd.method === "console") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      await attachDebugger(tabId);
      const logs = consoleBuffers.get(tabId) ?? [];
      reply(cmd.id, { logs });
    } else if (cmd.method === "table") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await extractTables(tabId, cmd.params?.selector, readFrameParam(cmd.params)));
    } else if (cmd.method === "describe") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await describeElements(tabId, cmd.params ?? {}));
    } else if (cmd.method === "network_log") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await getNetworkLog(tabId, cmd.params ?? {}));
    } else if (cmd.method === "har_export") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await exportHAR(tabId, cmd.params ?? {}));
    } else if (cmd.method === "state_inspect") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await inspectState(tabId, cmd.params ?? {}));
    } else if (cmd.method === "framework_inspect") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await inspectFramework(tabId, cmd.params ?? {}));
    } else if (cmd.method === "download_state") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      await attachDebugger(tabId);
      reply(cmd.id, await getDownloadState(tabId, cmd.params ?? {}));
    } else if (cmd.method === "wait_for") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await waitFor(tabId, cmd.params ?? {}));
    } else if (cmd.method === "eval_script") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await runApprovedEval(tabId, cmd.params ?? {}));
    } else if (cmd.method === "annotation_mode") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      await attachDebugger(tabId);
      reply(cmd.id, await manageAnnotationMode(tabId, readAnnotationCommand(cmd.params)));
    } else if (cmd.method === "validate_editable") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await validateEditable(tabId, cmd.params ?? {}));
    } else if (cmd.method === "stream_control") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await setRuntimeStream(tabId, cmd.params?.enabled === true));
    } else if (cmd.method === "dialog_state") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      await attachDebugger(tabId);
      reply(cmd.id, publicDialogState(tabId));
    } else if (cmd.method === "revoke") {
      if (!tabId) throw new Error("tabId required");
      await revokeTab(tabId, "gateway_revoke");
      reply(cmd.id, { ok: true });
    } else if (cmd.method === "record_start") {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await recordStart(tabId, cmd.params ?? {}));
    } else if (cmd.method === "record_stop") {
      reply(cmd.id, await recordStop(cmd.params ?? {}));
    } else if (cmd.method === "record_status") {
      reply(cmd.id, recordStatus());
    } else if (isOperationCommand(cmd)) {
      if (!tabId || !permittedTabs.has(tabId)) throw new Error("tab not permitted");
      reply(cmd.id, await runApprovedOperation(cmd, tabId));
    } else {
      replyError(cmd.id, "unknown_method", String(cmd.method));
    }
  } catch (e) {
    if (e instanceof GatewayError) {
      replyError(cmd.id, e.code, e.message);
    } else {
      replyError(cmd.id, "command_failed", e instanceof Error ? e.message : String(e));
    }
  }
}
function ensureBookmarksSupported() {
  if (!browser2.bookmarks) {
    throw new GatewayError(
      "bookmarks_unsupported",
      "This browser extension target does not expose the chrome.bookmarks API."
    );
  }
}
function ensureReadingListSupported() {
  if (!browser2.readingList) {
    throw new GatewayError(
      "reading_list_unsupported",
      "This browser extension target does not expose the chrome.readingList API. Chrome documents the API for Chrome 120+; other Chromium browsers may omit it."
    );
  }
}
async function requireBookmarksAccess() {
  const api = browser2.bookmarks;
  if (!api) {
    throw new GatewayError(
      "bookmarks_unsupported",
      "This browser extension target does not expose the chrome.bookmarks API."
    );
  }
  if (!await isBookmarksAccessActive()) {
    throw new GatewayError(
      "bookmarks_permission_required",
      "Bookmark inspection requires the separate bookmarks permission. Enable Bookmarks access in the ABG extension popup."
    );
  }
  return api;
}
async function requireReadingListAccess() {
  const api = browser2.readingList;
  if (!api) {
    throw new GatewayError(
      "reading_list_unsupported",
      "This browser extension target does not expose the chrome.readingList API. Chrome documents the API for Chrome 120+; other Chromium browsers may omit it."
    );
  }
  if (!await isReadingListAccessActive()) {
    throw new GatewayError(
      "reading_list_permission_required",
      "Reading List inspection requires the separate Reading List permission. Enable Reading List access in the ABG extension popup."
    );
  }
  return api;
}
function isBookmarkNode(value) {
  return isRecord(value) && typeof value.id === "string" && typeof value.title === "string";
}
function bookmarkPath(parents, title) {
  return [...parents, title].filter(Boolean).join(" / ");
}
function publicBookmarkNode(node, parents = []) {
  const isFolder = !node.url;
  const output = {
    id: node.id,
    title: node.title,
    type: isFolder ? "folder" : "bookmark",
    path: bookmarkPath(parents, node.title)
  };
  if (node.url) output.url = node.url;
  if (node.parentId) output.parentId = node.parentId;
  if (typeof node.index === "number") output.index = node.index;
  if (typeof node.dateAdded === "number") output.dateAdded = node.dateAdded;
  if (typeof node.dateGroupModified === "number") {
    output.dateGroupModified = node.dateGroupModified;
  }
  const dateLastUsed = node.dateLastUsed;
  if (typeof dateLastUsed === "number") output.dateLastUsed = dateLastUsed;
  const children = node.children ?? [];
  if (children.length > 0) {
    output.children = children.map((child) => publicBookmarkNode(child, [...parents, node.title]));
  }
  return output;
}
function flattenBookmarkNodes(nodes, parents = [], includeFolders = false) {
  const rows = [];
  for (const node of nodes) {
    if (includeFolders || node.url) rows.push(publicBookmarkNode(node, parents));
    if (node.children) {
      rows.push(...flattenBookmarkNodes(node.children, [...parents, node.title], includeFolders));
    }
  }
  return rows;
}
function findBookmarkNode(nodes, id, parents = []) {
  for (const node of nodes) {
    if (node.id === id) return { node, parents };
    if (node.children) {
      const found = findBookmarkNode(node.children, id, [...parents, node.title]);
      if (found) return found;
    }
  }
  return null;
}
function readLimit(params, fallback, maximum) {
  const limit = params?.limit;
  if (typeof limit !== "number" || !Number.isFinite(limit)) return fallback;
  return Math.max(1, Math.min(maximum, Math.floor(limit)));
}
async function listBookmarks(params) {
  const api = await requireBookmarksAccess();
  const includeFolders = params?.includeFolders === true;
  const tree = await api.getTree();
  const rows = flattenBookmarkNodes(tree, [], includeFolders).slice(
    0,
    readLimit(params, 100, 1e3)
  );
  return {
    ok: true,
    boundary: "browser_owned_personal_data",
    permission: "bookmarks",
    count: rows.length,
    bookmarks: rows
  };
}
async function searchBookmarks(params) {
  const api = await requireBookmarksAccess();
  const query = typeof params?.query === "string" ? params.query.trim() : "";
  if (!query) throw new GatewayError("bad_params", "query is required");
  const needle = query.toLowerCase();
  const tree = await api.getTree();
  const rows = flattenBookmarkNodes(tree, [], params?.includeFolders === true).filter((node) => {
    const title = typeof node.title === "string" ? node.title : "";
    const url = typeof node.url === "string" ? node.url : "";
    return title.toLowerCase().includes(needle) || url.toLowerCase().includes(needle);
  }).slice(0, readLimit(params, 50, 500));
  return {
    ok: true,
    boundary: "browser_owned_personal_data",
    permission: "bookmarks",
    queryBytes: query.length,
    count: rows.length,
    bookmarks: rows
  };
}
async function getBookmark(params) {
  const api = await requireBookmarksAccess();
  const id = typeof params?.bookmarkId === "string" ? params.bookmarkId : "";
  if (!id) throw new GatewayError("bad_params", "bookmarkId is required");
  const found = findBookmarkNode(await api.getTree(), id);
  if (!found) throw new GatewayError("bookmark_not_found", `Bookmark not found: ${id}`);
  return {
    ok: true,
    boundary: "browser_owned_personal_data",
    permission: "bookmarks",
    bookmark: publicBookmarkNode(found.node, found.parents)
  };
}
async function openBookmark(params) {
  const api = await requireBookmarksAccess();
  const id = typeof params?.bookmarkId === "string" ? params.bookmarkId : "";
  if (!id) throw new GatewayError("bad_params", "bookmarkId is required");
  const node = (await api.get(id)).find(isBookmarkNode);
  if (!node) throw new GatewayError("bookmark_not_found", `Bookmark not found: ${id}`);
  if (!node.url) throw new GatewayError("bookmark_is_folder", "Cannot open a bookmark folder.");
  const tab = await browser2.tabs.create({ url: node.url, active: true });
  return {
    ok: true,
    boundary: "browser_owned_personal_data",
    permission: "bookmarks",
    opened: true,
    bookmarkId: id,
    tabId: tab.id,
    title: node.title
  };
}
function publicReadingListEntry(entry) {
  return {
    title: entry.title,
    url: entry.url,
    hasBeenRead: entry.hasBeenRead,
    creationTime: entry.creationTime,
    lastUpdateTime: entry.lastUpdateTime
  };
}
async function listReadingList(params) {
  const api = await requireReadingListAccess();
  const query = {};
  if (typeof params?.hasBeenRead === "boolean") query.hasBeenRead = params.hasBeenRead;
  const entries = (await api.query(query)).map(publicReadingListEntry).slice(0, readLimit(params, 100, 1e3));
  return {
    ok: true,
    boundary: "browser_owned_personal_data",
    permission: "readingList",
    count: entries.length,
    entries
  };
}
async function searchReadingList(params) {
  const api = await requireReadingListAccess();
  const queryText = typeof params?.query === "string" ? params.query.trim() : "";
  if (!queryText) throw new GatewayError("bad_params", "query is required");
  const all = await api.query({});
  const needle = queryText.toLowerCase();
  const entries = all.filter(
    (entry) => entry.title.toLowerCase().includes(needle) || entry.url.toLowerCase().includes(needle)
  ).map(publicReadingListEntry).slice(0, readLimit(params, 50, 500));
  return {
    ok: true,
    boundary: "browser_owned_personal_data",
    permission: "readingList",
    queryBytes: queryText.length,
    count: entries.length,
    entries
  };
}
function isOperationCommand(cmd) {
  return OPERATION_METHODS.has(cmd.method);
}
async function runApprovedOperation(cmd, tabId) {
  const operation = buildOperation(cmd, tabId);
  await requireOperationApproval(cmd.method, tabId, operation.intent);
  return operation.run();
}
function buildOperation(cmd, tabId) {
  const frame = readFrameParam(cmd.params);
  if (cmd.method === "click_selector") {
    const selector2 = cmd.params?.selector;
    if (typeof selector2 !== "string" || selector2.length === 0) throw new Error("selector required");
    return {
      intent: `Click the element matching selector ${quoteForIntent(selector2)}${frameIntentSuffix(frame)}.`,
      run: () => clickSelector(tabId, selector2, frame)
    };
  }
  if (cmd.method === "click_at") {
    const x = cmd.params?.x;
    const y = cmd.params?.y;
    if (typeof x !== "number" || typeof y !== "number") throw new Error("x and y required");
    return {
      intent: `Click at page coordinates (${x}, ${y}).`,
      run: () => clickAt(tabId, x, y)
    };
  }
  if (cmd.method === "click_ref") {
    const ref = cmd.params?.ref;
    if (typeof ref !== "string" || ref.length === 0) throw new Error("ref required");
    return {
      intent: `Click snapshot ref ${quoteForIntent(ref)}.`,
      run: () => clickSnapshotRef(tabId, ref)
    };
  }
  if (cmd.method === "click_described") {
    const id = cmd.params?.id;
    if (typeof id !== "number") throw new Error("id required");
    return {
      intent: `Click the element with describe id ${id}.`,
      run: () => clickDescribedElement(tabId, id, cmd.params ?? {})
    };
  }
  if (cmd.method === "dblclick_selector") {
    const selector2 = cmd.params?.selector;
    if (typeof selector2 !== "string" || selector2.length === 0) throw new Error("selector required");
    return {
      intent: `Double-click the element matching selector ${quoteForIntent(selector2)}${frameIntentSuffix(frame)}.`,
      run: () => doubleClickSelector(tabId, selector2, frame)
    };
  }
  if (cmd.method === "focus_selector") {
    const selector2 = cmd.params?.selector;
    if (typeof selector2 !== "string" || selector2.length === 0) throw new Error("selector required");
    return {
      intent: `Focus the element matching selector ${quoteForIntent(selector2)}${frameIntentSuffix(frame)} without clicking it.`,
      run: () => focusElement(tabId, selector2, frame)
    };
  }
  if (cmd.method === "hover_selector") {
    const selector2 = cmd.params?.selector;
    if (typeof selector2 !== "string" || selector2.length === 0) throw new Error("selector required");
    return {
      intent: `Move the mouse over the element matching selector ${quoteForIntent(selector2)}${frameIntentSuffix(frame)}.`,
      run: () => hoverSelector(tabId, selector2, frame)
    };
  }
  if (cmd.method === "select_option") {
    const selector2 = cmd.params?.selector;
    if (typeof selector2 !== "string" || selector2.length === 0) throw new Error("selector required");
    const value = typeof cmd.params?.value === "string" ? cmd.params.value : void 0;
    const label = typeof cmd.params?.label === "string" ? cmd.params.label : void 0;
    if (value === void 0 === (label === void 0)) {
      throw new Error("exactly one of value or label required");
    }
    return {
      intent: `Select an option in ${quoteForIntent(selector2)}${frameIntentSuffix(frame)}.`,
      run: () => selectOption(tabId, selector2, { value, label }, frame)
    };
  }
  if (cmd.method === "set_checked") {
    const selector2 = cmd.params?.selector;
    if (typeof selector2 !== "string" || selector2.length === 0) throw new Error("selector required");
    const checked = cmd.params?.checked;
    if (typeof checked !== "boolean") throw new Error("checked boolean required");
    return {
      intent: `${checked ? "Check" : "Uncheck"} the input matching selector ${quoteForIntent(selector2)}${frameIntentSuffix(frame)} if needed.`,
      run: () => setChecked(tabId, selector2, checked, frame)
    };
  }
  if (cmd.method === "fill") {
    const selector2 = cmd.params?.selector;
    const rawValue = cmd.params?.value;
    if (typeof selector2 !== "string" || selector2.length === 0) throw new Error("selector required");
    if (rawValue !== void 0 && typeof rawValue !== "string") {
      throw new Error("value must be a string");
    }
    const value = rawValue ?? "";
    const dryRun = cmd.params?.dryRun === true;
    const auditDiff = cmd.params?.auditDiff === true;
    const auditDiffExcerptChars = cmd.params?.auditDiffExcerptChars;
    return {
      intent: dryRun ? `Preview editable replacement for selector ${quoteForIntent(selector2)}${frameIntentSuffix(frame)}.` : auditDiff ? `Fill ${new TextEncoder().encode(value).byteLength} bytes into the editable target matching selector ${quoteForIntent(selector2)}${frameIntentSuffix(frame)} and capture a redacted audit diff.` : `Fill ${quoteForIntent(value)} into the editable target matching selector ${quoteForIntent(selector2)}${frameIntentSuffix(frame)}.`,
      run: () => fillField(tabId, selector2, value, dryRun, frame, {
        auditDiff,
        auditDiffExcerptChars
      })
    };
  }
  if (cmd.method === "paste") {
    const selector2 = cmd.params?.selector;
    const rawValue = cmd.params?.value;
    if (typeof selector2 !== "string" || selector2.length === 0) throw new Error("selector required");
    if (rawValue !== void 0 && typeof rawValue !== "string") {
      throw new Error("value must be a string");
    }
    const value = rawValue ?? "";
    return {
      intent: `Paste ${new TextEncoder().encode(value).byteLength} bytes into the editable element matching selector ${quoteForIntent(selector2)}${frameIntentSuffix(frame)}.`,
      run: () => pasteText(tabId, selector2, value, frame)
    };
  }
  if (cmd.method === "paste_rich") {
    const selector2 = typeof cmd.params?.selector === "string" ? cmd.params.selector : void 0;
    if (cmd.params?.selector !== void 0 && (!selector2 || selector2.length === 0)) {
      throw new Error("selector must be a non-empty string");
    }
    const mime = typeof cmd.params?.mime === "string" ? cmd.params.mime : void 0;
    const contentBytes = typeof cmd.params?.contentBytes === "number" ? cmd.params.contentBytes : void 0;
    const target = selector2 ? `the element matching selector ${quoteForIntent(selector2)}${frameIntentSuffix(frame)}` : "the currently focused target";
    return {
      intent: `Paste${richClipboardPayloadLabel(mime, contentBytes)} into ${target}.`,
      run: () => pasteRichClipboard(tabId, selector2, frame)
    };
  }
  if (cmd.method === "clear") {
    const selector2 = cmd.params?.selector;
    if (typeof selector2 !== "string" || selector2.length === 0) throw new Error("selector required");
    return {
      intent: `Clear the editable element matching selector ${quoteForIntent(selector2)}${frameIntentSuffix(frame)}.`,
      run: () => clearEditable(tabId, selector2, frame)
    };
  }
  if (cmd.method === "replace_dom") {
    const selector2 = cmd.params?.selector;
    const html = cmd.params?.html;
    if (typeof selector2 !== "string" || selector2.length === 0) throw new Error("selector required");
    if (typeof html !== "string" || html.length === 0) throw new Error("html required");
    return {
      intent: `Replace the element matching selector ${quoteForIntent(selector2)}${frameIntentSuffix(frame)} with provided HTML.`,
      run: () => replaceDom(tabId, selector2, html, frame)
    };
  }
  if (cmd.method === "upload_file") {
    const selector2 = cmd.params?.selector;
    if (typeof selector2 !== "string" || selector2.length === 0) throw new Error("selector required");
    const files = normalizeUploadFiles(cmd.params ?? {});
    const firstFile = files[0] ?? "";
    const fileIntent = files.length === 1 ? `local file ${quoteForIntent(firstFile)}` : `${files.length} local files (${quoteForIntent(firstFile)}, ...)`;
    return {
      intent: `Attach ${fileIntent} to file input ${quoteForIntent(selector2)}${frameIntentSuffix(frame)}.`,
      run: () => uploadFile(tabId, selector2, files, frame)
    };
  }
  if (cmd.method === "type_text") {
    const text = cmd.params?.text;
    if (typeof text !== "string") throw new Error("text required");
    return {
      intent: `Type ${quoteForIntent(text)} into the focused element.`,
      run: () => typeText(tabId, text)
    };
  }
  if (cmd.method === "keyboard_insert_text") {
    const text = cmd.params?.text;
    if (typeof text !== "string") throw new Error("text required");
    return {
      intent: `Insert ${new TextEncoder().encode(text).byteLength} bytes into the focused element without key events.`,
      run: () => keyboardInsertText(tabId, text)
    };
  }
  if (cmd.method === "exec_command") {
    const command = cmd.params?.command;
    if (!isAllowedExecCommand(command)) {
      throw new GatewayError(
        "unsupported_exec_command",
        `unsupported execCommand: ${String(command ?? "")}`
      );
    }
    const rawValue = cmd.params?.value;
    if (rawValue !== void 0 && typeof rawValue !== "string") {
      throw new Error("value must be a string");
    }
    const value = rawValue;
    const valueBytes = value === void 0 ? 0 : new TextEncoder().encode(value).byteLength;
    return {
      intent: `Run document.execCommand(${command}) against the focused element with ${valueBytes} value bytes.`,
      run: () => execCommand(tabId, command, value)
    };
  }
  if (cmd.method === "key_press") {
    const key = cmd.params?.key;
    if (typeof key !== "string" || key.length === 0) throw new Error("key required");
    const code = typeof cmd.params?.code === "string" ? cmd.params.code : void 0;
    const modifiers = Array.isArray(cmd.params?.modifiers) ? cmd.params.modifiers.filter((modifier) => typeof modifier === "string") : [];
    const chord = [...modifiers, key].join("+");
    return {
      intent: `Press ${quoteForIntent(chord)}.`,
      run: () => keyPress(tabId, key, code, modifiers)
    };
  }
  if (cmd.method === "key_down" || cmd.method === "key_up") {
    const key = cmd.params?.key;
    if (typeof key !== "string" || key.length === 0) throw new Error("key required");
    const code = typeof cmd.params?.code === "string" ? cmd.params.code : void 0;
    const modifiers = Array.isArray(cmd.params?.modifiers) ? cmd.params.modifiers.filter((modifier) => typeof modifier === "string") : [];
    const chord = [...modifiers, key].join("+");
    const phase = cmd.method === "key_down" ? "down" : "up";
    return {
      intent: `Dispatch key ${phase} for ${quoteForIntent(chord)}.`,
      run: () => keyEdge(tabId, cmd.method === "key_down" ? "keyDown" : "keyUp", key, code, modifiers)
    };
  }
  if (cmd.method === "navigate") {
    const url = cmd.params?.url;
    if (typeof url !== "string" || url.length === 0) throw new Error("url required");
    return {
      intent: `Navigate this tab to ${quoteForIntent(url)}.`,
      run: async () => {
        await browser2.tabs.update(tabId, { url });
        return { ok: true, note: "navigation may revoke permission if origin changes" };
      }
    };
  }
  if (cmd.method === "sandbox_action") {
    const action = typeof cmd.params?.action === "string" ? cmd.params.action : "";
    if (action === "viewport") {
      const width = cmd.params?.width;
      const height = cmd.params?.height;
      if (typeof width !== "number" || typeof height !== "number") {
        throw new Error("width and height required");
      }
      const mobile = cmd.params?.mobile === true;
      return {
        intent: `Set sandbox viewport to ${width}x${height}${mobile ? " mobile" : ""}.`,
        run: () => sandboxSetViewport(tabId, cmd.params ?? {})
      };
    }
    if (action === "viewport-clear") {
      return {
        intent: "Clear sandbox viewport emulation.",
        run: () => sandboxClearViewport(tabId)
      };
    }
    if (action === "storage-set" || action === "storage-delete") {
      const storageKind = normalizeSandboxStorageKind(cmd.params?.storageKind);
      const key = cmd.params?.storageKey;
      if (typeof key !== "string" || key.length === 0) throw new Error("storage key required");
      const value = typeof cmd.params?.value === "string" ? cmd.params.value : "";
      if (action === "storage-set" && typeof cmd.params?.value !== "string") {
        throw new Error("value required");
      }
      return {
        intent: action === "storage-set" ? `Set ${storageKind} key ${quoteForIntent(key)} to ${new TextEncoder().encode(value).byteLength} bytes in the sandbox profile.` : `Delete ${storageKind} key ${quoteForIntent(key)} from the sandbox profile.`,
        run: () => sandboxStorage(tabId, storageKind, key, action === "storage-set" ? value : void 0)
      };
    }
    if (action === "tab-create") {
      const url = cmd.params?.url;
      if (typeof url !== "string" || url.length === 0) throw new Error("url required");
      return {
        intent: `Create a new sandbox tab for ${quoteForIntent(url)}.`,
        run: () => sandboxCreateTab(tabId, url)
      };
    }
    if (action === "tab-close") {
      const targetTabId = cmd.params?.targetTabId ?? tabId;
      if (typeof targetTabId !== "number") throw new Error("targetTabId must be a number");
      return {
        intent: `Close sandbox tab ${targetTabId}.`,
        run: () => sandboxCloseTab(targetTabId)
      };
    }
    throw new GatewayError(
      "bad_sandbox_action",
      "sandbox action must be viewport, viewport-clear, storage-set, storage-delete, tab-create, or tab-close"
    );
  }
  if (cmd.method === "drag") {
    const from = readDragPoint(cmd.params, "from");
    const to = readDragPoint(cmd.params, "to");
    const steps2 = typeof cmd.params?.steps === "number" ? Math.max(1, Math.min(100, cmd.params.steps)) : 12;
    return {
      intent: `Drag from ${describeDragPoint(from)} to ${describeDragPoint(to)}${frameIntentSuffix(frame)}.`,
      run: () => drag(tabId, from, to, steps2)
    };
  }
  if (cmd.method === "scroll_into_view") {
    const selector2 = cmd.params?.selector;
    if (typeof selector2 !== "string" || selector2.length === 0) throw new Error("selector required");
    return {
      intent: `Scroll the element matching selector ${quoteForIntent(selector2)}${frameIntentSuffix(frame)} into view.`,
      run: () => scrollElementIntoView(tabId, selector2, frame)
    };
  }
  if (cmd.method === "dialog_action") {
    const action = typeof cmd.params?.action === "string" ? cmd.params.action : "";
    if (action !== "accept" && action !== "dismiss") {
      throw new Error("dialog action must be accept or dismiss");
    }
    const dialog = pendingDialogs.get(tabId);
    if (!dialog) {
      throw new GatewayError("no_dialog_pending", "no JavaScript dialog is pending for this tab");
    }
    const promptText = typeof cmd.params?.promptText === "string" ? cmd.params.promptText : void 0;
    const promptSuffix = promptText === void 0 ? "" : ` with ${new TextEncoder().encode(promptText).byteLength} prompt bytes`;
    return {
      intent: `${action === "accept" ? "Accept" : "Dismiss"} ${dialog.type} dialog${promptSuffix}: ${quoteForIntent(dialog.message)}`,
      run: () => runDialogAction(tabId, cmd.params ?? {})
    };
  }
  const deltaX = cmd.params?.deltaX ?? 0;
  const deltaY = cmd.params?.deltaY ?? 0;
  if (typeof deltaX !== "number" || typeof deltaY !== "number") {
    throw new Error("deltaX and deltaY must be numbers");
  }
  const atX = typeof cmd.params?.atX === "number" ? cmd.params.atX : void 0;
  const atY = typeof cmd.params?.atY === "number" ? cmd.params.atY : void 0;
  const selector = typeof cmd.params?.selector === "string" ? cmd.params.selector : void 0;
  const steps = typeof cmd.params?.steps === "number" ? Math.max(1, Math.min(100, cmd.params.steps)) : 1;
  if (selector !== void 0) {
    return {
      intent: `Scroll the element matching selector ${quoteForIntent(selector)} by (\u0394x=${deltaX}, \u0394y=${deltaY})${frameIntentSuffix(frame)}.`,
      run: () => scrollElement(tabId, selector, deltaX, deltaY, steps, frame)
    };
  }
  const where = atX !== void 0 && atY !== void 0 ? `at (${atX}, ${atY})` : "at viewport center";
  return {
    intent: `Scroll this tab by (\u0394x=${deltaX}, \u0394y=${deltaY}) ${where}.`,
    run: () => scrollTab(tabId, deltaX, deltaY, atX, atY)
  };
}
function quoteForIntent(value) {
  const normalized = value.replace(/\s+/g, " ").trim();
  const shortValue = normalized.length > 160 ? `${normalized.slice(0, 157)}...` : normalized;
  return `"${shortValue}"`;
}
function truncateText(value, limit = 500) {
  if (value === void 0) return void 0;
  const normalized = value.replace(/\s+/g, " ").trim();
  return normalized.length > limit ? `${normalized.slice(0, limit - 3)}...` : normalized;
}
function publicDialog(dialog) {
  const encoder = new TextEncoder();
  return {
    type: dialog.type,
    message: truncateText(dialog.message),
    messageBytes: encoder.encode(dialog.message).byteLength,
    defaultPrompt: truncateText(dialog.defaultPrompt),
    defaultPromptBytes: dialog.defaultPrompt === void 0 ? void 0 : encoder.encode(dialog.defaultPrompt).byteLength,
    url: dialog.url,
    openedAt: new Date(dialog.openedAt).toISOString()
  };
}
function publicDialogState(tabId) {
  const dialog = pendingDialogs.get(tabId);
  return dialog ? { pending: true, dialog: publicDialog(dialog) } : { pending: false };
}
function publicDownload(record) {
  const pathAvailable = record.status === "complete" && !!record.filename;
  return {
    id: record.id,
    browserDownloadId: record.browserDownloadId,
    guid: record.guid,
    tabId: record.tabId,
    url: record.url,
    finalUrl: record.finalUrl,
    referrer: record.referrer,
    suggestedFilename: record.suggestedFilename,
    filename: record.filename,
    pathAvailable,
    unavailableReason: pathAvailable ? void 0 : record.status === "complete" ? "chrome_download_path_unavailable" : "download_not_complete",
    mime: record.mime,
    status: record.status,
    error: record.error,
    bytesReceived: record.bytesReceived,
    totalBytes: record.totalBytes,
    fileSize: record.fileSize,
    exists: record.exists,
    startedAt: record.startedAt,
    endedAt: record.endedAt
  };
}
function downloadState(tabId) {
  const downloads = (downloadsByTab.get(tabId) ?? []).map(publicDownload);
  return {
    ok: true,
    count: downloads.length,
    latest: downloads.at(-1),
    downloads
  };
}
async function getDownloadState(tabId, params) {
  if (params.wait !== true) return downloadState(tabId);
  const timeoutMs = typeof params.timeoutMs === "number" ? Math.max(1, Math.min(3e5, params.timeoutMs)) : 3e4;
  const started = Date.now();
  while (Date.now() - started <= timeoutMs) {
    const latest = (downloadsByTab.get(tabId) ?? []).at(-1);
    if (latest && latest.status !== "in_progress") {
      return {
        ok: latest.status === "complete",
        mode: "wait",
        elapsedMs: Date.now() - started,
        latest: publicDownload(latest)
      };
    }
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  return {
    ok: false,
    error: "timeout",
    mode: "wait",
    timeoutMs,
    latest: (downloadsByTab.get(tabId) ?? []).at(-1) ? publicDownload((downloadsByTab.get(tabId) ?? []).at(-1)) : void 0
  };
}
async function runDialogAction(tabId, params) {
  const action = typeof params.action === "string" ? params.action : "";
  if (action !== "accept" && action !== "dismiss") {
    throw new GatewayError("bad_dialog_action", "dialog action must be accept or dismiss");
  }
  const dialog = pendingDialogs.get(tabId);
  if (!dialog) {
    throw new GatewayError("no_dialog_pending", "no JavaScript dialog is pending for this tab");
  }
  await attachDebugger(tabId);
  const promptText = typeof params.promptText === "string" ? params.promptText : void 0;
  const commandParams = { accept: action === "accept" };
  if (action === "accept" && promptText !== void 0) commandParams.promptText = promptText;
  await browser2.debugger.sendCommand({ tabId }, "Page.handleJavaScriptDialog", commandParams);
  pendingDialogs.delete(tabId);
  return {
    ok: true,
    action,
    accepted: action === "accept",
    promptTextBytes: promptText === void 0 ? void 0 : new TextEncoder().encode(promptText).byteLength,
    dialog: publicDialog(dialog)
  };
}
function globMatch(pattern, text) {
  const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".");
  return new RegExp(`^${escaped}$`, "i").test(text);
}
async function requireOperationApproval(method, tabId, intent) {
  const settings = await getSettings();
  if (!settings.operationsRequireApproval) return;
  const resolution = await requestOperationApproval(method, tabId, intent);
  if (resolution.decision !== "allow") {
    throw new GatewayError("user_denied", resolution.message);
  }
}
async function requestOperationApproval(method, tabId, intent, script) {
  const request = {
    id: crypto.randomUUID(),
    method,
    intent,
    script,
    tab: await getApprovalTab(tabId),
    createdAt: Date.now(),
    timeoutMs: APPROVAL_TIMEOUT_MS
  };
  let resolveApproval = () => {
  };
  const approvalPromise = new Promise((resolve) => {
    resolveApproval = resolve;
  });
  const timeoutId = setTimeout(() => {
    finalizeApproval(
      request.id,
      {
        decision: "timeout",
        message: "Operation denied because approval timed out."
      },
      true
    );
  }, APPROVAL_WINDOW_FALLBACK_TIMEOUT_MS);
  const pending = {
    request,
    resolve: resolveApproval,
    timeoutId
  };
  pendingApprovals.set(request.id, pending);
  try {
    const approvalUrl = new URL(browser2.runtime.getURL("approval.html"));
    approvalUrl.searchParams.set("id", request.id);
    const approvalWindow = await browser2.windows.create({
      type: "popup",
      url: approvalUrl.href,
      width: script === void 0 ? 380 : 520,
      height: script === void 0 ? 240 : 420
    });
    if (typeof approvalWindow.id === "number") {
      pending.windowId = approvalWindow.id;
    }
  } catch (e) {
    finalizeApproval(request.id, {
      decision: "deny",
      message: `Operation denied because the approval window could not open: ${e instanceof Error ? e.message : String(e)}`
    });
  }
  return approvalPromise;
}
async function getApprovalTab(tabId) {
  const permitted = permittedTabs.get(tabId);
  try {
    const tab = await browser2.tabs.get(tabId);
    return {
      tabId,
      title: tab.title ?? permitted?.title ?? "",
      url: tab.url ?? permitted?.url ?? ""
    };
  } catch {
    return {
      tabId,
      title: permitted?.title ?? "",
      url: permitted?.url ?? ""
    };
  }
}
function finalizeApproval(approvalId, resolution, closeWindow = false) {
  const pending = pendingApprovals.get(approvalId);
  if (!pending) return false;
  pendingApprovals.delete(approvalId);
  clearTimeout(pending.timeoutId);
  if (closeWindow && pending.windowId !== void 0) {
    browser2.windows.remove(pending.windowId).catch(() => {
    });
  }
  pending.resolve(resolution);
  return true;
}
function resolutionForDecision(decision, streamId) {
  if (decision === "allow") {
    return {
      decision,
      message: "Operation approved.",
      streamId
    };
  }
  if (decision === "timeout") {
    return {
      decision,
      message: "Operation denied because approval timed out."
    };
  }
  return {
    decision,
    message: "Operation denied by user."
  };
}
var OFFSCREEN_URL = "offscreen.html";
var creatingOffscreen = null;
async function recordStart(tabId, params) {
  if (recordingSession) {
    throw new GatewayError(
      "already_recording",
      `A recording is already active on tab ${recordingSession.tabId}. Stop it first.`
    );
  }
  const recordingId = params.recordingId ?? crypto.randomUUID();
  const withMic = params.mic === true;
  const intent = withMic ? "Record this tab to a video file, capturing tab audio and the microphone (physical room)." : "Record this tab to a video file, capturing tab audio.";
  const approval = await requestOperationApproval("record_start", tabId, intent);
  if (approval.decision !== "allow") {
    throw new GatewayError("user_denied", approval.message);
  }
  if (!approval.streamId) {
    throw new GatewayError(
      "no_capture_stream",
      "Approval did not yield a tab capture stream (the Allow click must mint it)."
    );
  }
  await ensureOffscreenDocument();
  const start = await sendToOffscreen({
    target: "abg-offscreen",
    cmd: "start",
    recordingId,
    streamId: approval.streamId,
    withMic,
    timesliceMs: typeof params.timesliceMs === "number" ? params.timesliceMs : void 0
  });
  if (!start?.ok) {
    throw new GatewayError("record_start_failed", start?.error ?? "offscreen recorder failed");
  }
  recordingSession = {
    recordingId,
    tabId,
    mic: start.micUsed === true,
    mime: start.mime ?? "video/webm",
    startedAt: Date.now()
  };
  await updateBadge(tabId);
  return {
    recordingId,
    tabId,
    mic: recordingSession.mic,
    mime: recordingSession.mime
  };
}
async function recordStop(params) {
  const session = recordingSession;
  if (!session) {
    throw new GatewayError("not_recording", "No recording is active.");
  }
  if (params.recordingId && params.recordingId !== session.recordingId) {
    throw new GatewayError(
      "recording_mismatch",
      "recordingId does not match the active recording."
    );
  }
  const stop = await sendToOffscreen({
    target: "abg-offscreen",
    cmd: "stop",
    recordingId: session.recordingId
  });
  if (!stop?.ok) {
    throw new GatewayError(
      "record_stop_failed",
      stop?.error ?? "offscreen recorder failed to stop"
    );
  }
  return { ok: true, recordingId: session.recordingId, tabId: session.tabId };
}
function recordStatus() {
  if (!recordingSession) return { recording: false };
  return {
    recording: true,
    recordingId: recordingSession.recordingId,
    tabId: recordingSession.tabId,
    mic: recordingSession.mic,
    mime: recordingSession.mime,
    startedAt: recordingSession.startedAt
  };
}
async function ensureOffscreenDocument() {
  const offscreen = chrome.offscreen;
  if (!offscreen) throw new GatewayError("offscreen_unavailable", "offscreen API unavailable");
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_URL)]
  });
  if (contexts.length > 0) return;
  if (!creatingOffscreen) {
    creatingOffscreen = offscreen.createDocument({
      url: OFFSCREEN_URL,
      reasons: ["USER_MEDIA"],
      justification: "Record a shared tab (video + audio) to a local file."
    }).finally(() => {
      creatingOffscreen = null;
    });
  }
  await creatingOffscreen;
}
async function sendToOffscreen(msg) {
  return chrome.runtime.sendMessage(msg);
}
function handleOffscreenEvent(rawMsg) {
  const type = rawMsg.type;
  const recordingId = typeof rawMsg.recordingId === "string" ? rawMsg.recordingId : "";
  if (!recordingId) return;
  if (type === "abg_offscreen_chunk") {
    sendWS({
      type: "record_chunk",
      recordingId,
      seq: typeof rawMsg.seq === "number" ? rawMsg.seq : 0,
      dataBase64: typeof rawMsg.dataBase64 === "string" ? rawMsg.dataBase64 : ""
    });
    return;
  }
  if (type === "abg_offscreen_stopped") {
    sendWS({
      type: "record_stopped",
      recordingId,
      durationMs: typeof rawMsg.durationMs === "number" ? rawMsg.durationMs : 0,
      mime: typeof rawMsg.mime === "string" ? rawMsg.mime : "video/webm",
      micUsed: rawMsg.micUsed === true,
      chunkCount: typeof rawMsg.chunkCount === "number" ? rawMsg.chunkCount : 0
    });
    void finishRecordingSession(recordingId);
    return;
  }
  if (type === "abg_offscreen_error") {
    sendWS({
      type: "record_failed",
      recordingId,
      error: typeof rawMsg.error === "string" ? rawMsg.error : "recording failed"
    });
    void finishRecordingSession(recordingId);
  }
}
async function finishRecordingSession(recordingId) {
  if (recordingSession?.recordingId !== recordingId) return;
  const tabId = recordingSession.tabId;
  recordingSession = null;
  await updateBadge(tabId);
}
function stopRecordingForTab(tabId) {
  if (recordingSession?.tabId !== tabId) return;
  void sendToOffscreen({
    target: "abg-offscreen",
    cmd: "stop",
    recordingId: recordingSession.recordingId
  }).catch(() => {
  });
}
function reply(id, result) {
  sendWS({ type: "response", id, result });
}
function replyError(id, code, message) {
  sendWS({ type: "response", id, error: { code, message } });
}
function readFrameParam(params) {
  return typeof params?.frame === "string" && params.frame.length > 0 ? params.frame : void 0;
}
function frameIntentSuffix(frame) {
  return frame ? ` inside frame ${quoteForIntent(frame)}` : "";
}
function createFrameApiSource() {
  return `() => {
    const fail = (code, message) => {
      const err = new Error(message);
      err.code = code;
      throw err;
    };
    const cssEscape = (value) => {
      const escaper = globalThis.CSS && globalThis.CSS.escape;
      return escaper ? escaper(value) : String(value).replace(/["\\\\]/g, "\\\\$&");
    };
    const normalize = (value) => String(value || "").replace(/\\s+/g, " ").trim();
    const selectorFor = (el, rootDocument) => {
      if (el.id) {
        const idSelector = "#" + cssEscape(el.id);
        if (rootDocument.querySelectorAll(idSelector).length === 1) return idSelector;
      }
      for (const attr of ["data-testid", "data-test", "name", "aria-label", "title", "src"]) {
        const value = el.getAttribute(attr);
        if (!value) continue;
        const selector = el.tagName.toLowerCase() + "[" + attr + "=\\"" + cssEscape(value) + "\\"]";
        if (rootDocument.querySelectorAll(selector).length === 1) return selector;
      }
      const parts = [];
      let current = el;
      while (current && parts.length < 5) {
        const parent = current.parentElement;
        const tag = current.tagName.toLowerCase();
        if (!parent) {
          parts.unshift(tag);
          break;
        }
        const siblings = Array.from(parent.children).filter((child) => child.tagName === current.tagName);
        const nth = siblings.indexOf(current) + 1;
        parts.unshift(siblings.length > 1 ? tag + ":nth-of-type(" + nth + ")" : tag);
        current = parent;
      }
      return parts.join(" > ");
    };
    const publicFrame = (item) => ({
      ref: item.ref,
      parentRef: item.parentRef || undefined,
      selector: item.selector,
      name: item.name,
      title: item.title,
      url: item.url,
      src: item.src,
      origin: item.origin,
      sameOrigin: item.sameOrigin,
      accessible: item.accessible,
      childCount: item.childCount,
      depth: item.depth,
      lineage: item.lineage,
    });
    const collectFrames = () => {
      const items = [];
      const collect = (doc, parentRef, offsetX, offsetY, lineage) => {
        const frames = Array.from(doc.querySelectorAll("iframe, frame"));
        for (const element of frames) {
          const rect = element.getBoundingClientRect();
          const ref = "@f" + (items.length + 1);
          const src = element.getAttribute("src") || "";
          let childDoc = null;
          let childWin = null;
          let accessible = false;
          let sameOrigin = false;
          let childCount = 0;
          let url = element.src || src || "about:blank";
          let title = element.getAttribute("title") || "";
          let origin = "";
          try {
            childWin = element.contentWindow;
            childDoc = element.contentDocument || (childWin && childWin.document);
            if (childDoc && childWin) {
              accessible = true;
              sameOrigin = true;
              url = childWin.location.href;
              title = childDoc.title || title;
              origin = childWin.location.origin;
              childCount = childDoc.querySelectorAll("iframe, frame").length;
            }
          } catch (_error) {
            childDoc = null;
            childWin = null;
          }
          const nextLineage = lineage.concat(ref);
          const item = {
            ref,
            parentRef,
            selector: selectorFor(element, doc),
            name: element.getAttribute("name") || "",
            title,
            url,
            src,
            origin,
            sameOrigin,
            accessible,
            childCount,
            depth: lineage.length,
            lineage: nextLineage,
            element,
            doc: childDoc,
            win: childWin,
            offsetX: offsetX + rect.left,
            offsetY: offsetY + rect.top,
          };
          items.push(item);
          if (accessible && childDoc) collect(childDoc, ref, item.offsetX, item.offsetY, nextLineage);
        }
      };
      collect(document, undefined, 0, 0, []);
      return items;
    };
    return {
      listFrames: () => collectFrames().map(publicFrame),
      resolve: (target) => {
        if (!target) {
          return { doc: document, win: window, frame: undefined, offsetX: 0, offsetY: 0 };
        }
        const frames = collectFrames();
        let found = null;
        if (/^@f\\d+$/.test(target)) {
          found = frames[Number(target.slice(2)) - 1] || null;
        } else {
          const topElement = document.querySelector(target);
          if (topElement) found = frames.find((item) => item.element === topElement) || null;
        }
        if (!found) {
          fail("frame_not_found", "frame not found: " + target);
        }
        if (!found.accessible || !found.doc || !found.win) {
          fail(
            "frame_not_accessible",
            "frame is not same-origin or is not accessible for selector targeting: " + target,
          );
        }
        return {
          doc: found.doc,
          win: found.win,
          frame: publicFrame(found),
          offsetX: found.offsetX,
          offsetY: found.offsetY,
        };
      },
      normalize,
    };
  }`;
}
async function evaluatePageExpression(tabId, expression) {
  if (!browser2.supportsDebugger) {
    return evaluatePageExpressionWithScripting(tabId, expression);
  }
  await attachDebugger(tabId);
  const res = await browser2.debugger.sendCommand({ tabId }, "Runtime.evaluate", {
    expression,
    returnByValue: true
  });
  if (res.exceptionDetails) {
    throw new Error(
      `frame script failed: ${res.exceptionDetails.exception?.description ?? res.exceptionDetails.text}`
    );
  }
  const value = res.result?.value;
  if (value && typeof value === "object" && "__abgFrameError" in value && value.__abgFrameError) {
    const err = value;
    throw new GatewayError(err.code, err.message);
  }
  return value;
}
async function evaluatePageExpressionWithScripting(tabId, expression) {
  const [res] = await browser2.scripting.executeScript({
    target: { tabId },
    func: (source) => {
      try {
        return { ok: true, value: globalThis.eval(source) };
      } catch (error) {
        return {
          ok: false,
          message: error instanceof Error ? error.message : String(error)
        };
      }
    },
    args: [expression]
  });
  const payload = res?.result;
  if (!payload) {
    throw new Error("script injection returned no result");
  }
  if (!payload.ok) {
    throw new Error(`frame script failed: ${payload.message ?? "unknown error"}`);
  }
  const value = payload.value;
  if (value && typeof value === "object" && "__abgFrameError" in value && value.__abgFrameError) {
    const err = value;
    throw new GatewayError(err.code, err.message);
  }
  return value;
}
async function runFrameScript(tabId, frame, args, pageFn) {
  const expression = `(() => {
    const __abgFrameTarget = ${JSON.stringify(frame ?? null)};
    const __abgArgs = ${JSON.stringify(args ?? null)};
    const __abgCreateFrameApi = ${createFrameApiSource()};
    const __abgPageFn = ${pageFn.toString()};
    try {
      const __abgApi = __abgCreateFrameApi();
      return __abgPageFn(__abgApi.resolve(__abgFrameTarget), __abgArgs);
    } catch (error) {
      return {
        __abgFrameError: true,
        code: error && error.code ? error.code : "frame_script_failed",
        message: error && error.message ? error.message : String(error),
      };
    }
  })()`;
  return evaluatePageExpression(tabId, expression);
}
async function listFrames(tabId) {
  const expression = `(() => {
    const __abgCreateFrameApi = ${createFrameApiSource()};
    const __abgApi = __abgCreateFrameApi();
    const frames = __abgApi.listFrames();
    return { url: location.href, title: document.title, count: frames.length, frames };
  })()`;
  return evaluatePageExpression(tabId, expression);
}
async function readDom(tabId, selector, frame) {
  return runFrameScript(tabId, frame, { selector }, (ctx, opts) => {
    const sel = opts.selector;
    const root = sel ? ctx.doc.querySelector(sel) : ctx.doc.documentElement;
    if (sel && !root) {
      return {
        url: ctx.win.location.href,
        title: ctx.doc.title,
        origin: ctx.win.location.origin,
        selector: sel,
        frame: ctx.frame,
        found: false,
        text: ""
      };
    }
    const target = root ?? document.documentElement;
    const isElementWithInnerText = (el) => typeof el.innerText === "string";
    const text = isElementWithInnerText(target) ? target.innerText : target.textContent ?? "";
    return {
      url: ctx.win.location.href,
      title: ctx.doc.title,
      origin: ctx.win.location.origin,
      selector: sel ?? void 0,
      frame: ctx.frame,
      found: sel ? true : void 0,
      text,
      html: target.outerHTML
    };
  });
}
async function getDomValue(tabId, params) {
  const kind = typeof params.kind === "string" ? params.kind : "";
  const selector = typeof params.selector === "string" ? params.selector : void 0;
  const name = typeof params.name === "string" ? params.name : void 0;
  const props = Array.isArray(params.props) ? params.props.filter((prop) => typeof prop === "string") : void 0;
  const frame = readFrameParam(params);
  return runFrameScript(tabId, frame, { kind, selector, name, props }, (ctx, opts) => {
    const getter = opts.kind;
    const sel = opts.selector;
    const attrName = opts.name;
    const styleProps = opts.props;
    const selected = sel ? Array.from(ctx.doc.querySelectorAll(sel)) : [];
    const first = selected[0];
    const textOf = (el) => (el.innerText ?? el.textContent ?? "").replace(/\s+/g, " ").trim();
    const boxOf = (el) => {
      const rect = el.getBoundingClientRect();
      return {
        x: Math.round(ctx.offsetX + rect.left),
        y: Math.round(ctx.offsetY + rect.top),
        width: Math.round(rect.width),
        height: Math.round(rect.height)
      };
    };
    const base = {
      kind: getter,
      selector: sel,
      frame: ctx.frame,
      url: ctx.win.location.href,
      title: ctx.doc.title
    };
    if (getter === "title") return { ...base, value: ctx.doc.title };
    if (getter === "url") return { ...base, value: ctx.win.location.href };
    if (!sel) return { ...base, found: false, error: "selector_required" };
    if (getter === "count") return { ...base, value: selected.length };
    if (!first) return { ...base, found: false };
    if (getter === "text") return { ...base, found: true, value: textOf(first) };
    if (getter === "html") return { ...base, found: true, value: first.outerHTML };
    if (getter === "value") {
      let value = null;
      if (first instanceof HTMLInputElement) {
        value = first.type === "checkbox" || first.type === "radio" ? first.checked : first.value;
      } else if (first instanceof HTMLTextAreaElement) {
        value = first.value;
      } else if (first instanceof HTMLSelectElement) {
        value = Array.from(first.selectedOptions).map((option) => option.value);
      }
      return { ...base, found: true, value };
    }
    if (getter === "editable-value") {
      let editableText = "";
      let kind2 = "unsupported";
      let source = "none";
      if (first instanceof HTMLInputElement) {
        editableText = first.value;
        kind2 = "input";
        source = "value";
      } else if (first instanceof HTMLTextAreaElement) {
        editableText = first.value;
        kind2 = "textarea";
        source = "value";
      } else if (first.isContentEditable) {
        editableText = first.innerText || first.textContent || "";
        kind2 = "contenteditable";
        source = "innerText";
      } else if (first.getAttribute("role") === "textbox") {
        editableText = first.innerText || first.textContent || "";
        kind2 = "role-textbox";
        source = "innerText";
      } else {
        return { ...base, found: true, editable: false, kind: kind2, error: "not_editable" };
      }
      const normalizedHtmlText = textOf(first);
      return {
        ...base,
        found: true,
        editable: true,
        kind: kind2,
        source,
        editableText,
        html: first.outerHTML,
        differsFromHtmlText: editableText.replace(/\s+/g, " ").trim() !== normalizedHtmlText
      };
    }
    if (getter === "attr") {
      if (!attrName) return { ...base, found: true, error: "attr_name_required" };
      return { ...base, found: true, name: attrName, value: first.getAttribute(attrName) };
    }
    if (getter === "box") return { ...base, found: true, value: boxOf(first) };
    if (getter === "styles") {
      const computed = getComputedStyle(first);
      const keys = styleProps && styleProps.length > 0 ? styleProps : Array.from(computed).sort();
      const values = {};
      for (const key of keys) values[key] = computed.getPropertyValue(key);
      return { ...base, found: true, value: values };
    }
    return { ...base, found: false, error: "unknown_getter" };
  });
}
async function getPredicate(tabId, params) {
  const kind = typeof params.kind === "string" ? params.kind : "";
  const selector = typeof params.selector === "string" ? params.selector : void 0;
  const frame = readFrameParam(params);
  return runFrameScript(tabId, frame, { kind, selector }, (ctx, opts) => {
    const predicate = opts.kind;
    const sel = opts.selector;
    const el = sel ? ctx.doc.querySelector(sel) : null;
    const base = { kind: predicate, selector: sel, frame: ctx.frame, found: !!el };
    if (!el) return { ...base, value: false };
    const visible = (target) => {
      const rect = target.getBoundingClientRect();
      const style = getComputedStyle(target);
      return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none" && Number(style.opacity || "1") !== 0;
    };
    if (predicate === "visible") return { ...base, value: visible(el) };
    if (predicate === "enabled") {
      const disabled = "disabled" in el && Boolean(el.disabled);
      const ariaDisabled = el.getAttribute("aria-disabled") === "true";
      return { ...base, value: !disabled && !ariaDisabled };
    }
    if (predicate === "checked") {
      const value = el instanceof HTMLInputElement ? el.checked : el.getAttribute("aria-checked") === "true";
      return { ...base, value };
    }
    return { ...base, value: false };
  });
}
async function validateEditable(tabId, params) {
  const selector = typeof params.selector === "string" ? params.selector : void 0;
  const selection = params.selection === true;
  const rules = typeof params.rules === "string" ? params.rules : "html-attrs,shortcodes";
  const [res] = await browser2.scripting.executeScript({
    target: { tabId },
    func: (sel, useSelection, ruleText) => {
      const readText = () => {
        if (useSelection) {
          return {
            found: true,
            source: "selection",
            text: String(window.getSelection()?.toString() ?? "")
          };
        }
        if (!sel) return { found: false, source: "selector", text: "" };
        const el = document.querySelector(sel);
        if (!el) return { found: false, source: "selector", text: "" };
        if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
          return { found: true, source: "value", text: el.value, html: el.outerHTML };
        }
        return {
          found: true,
          source: el.isContentEditable || el.getAttribute("role") === "textbox" ? "editableText" : "textContent",
          text: el.innerText || el.textContent || "",
          html: el.outerHTML
        };
      };
      const locationOf = (text, offset) => {
        const prefix = text.slice(0, offset);
        const lines = prefix.split(/\n/);
        return { line: lines.length, column: (lines.at(-1) ?? "").length + 1 };
      };
      const contextOf = (text, offset) => text.slice(Math.max(0, offset - 40), Math.min(text.length, offset + 80));
      const scanQuotedAssignments = (text, ruleId) => {
        const issues2 = [];
        const re = /([A-Za-z_:][-A-Za-z0-9_:.]*)\s*=\s*(['"])/g;
        let match = re.exec(text);
        while (match) {
          const quote = match[2] ?? "";
          const valueStart = re.lastIndex;
          let i = valueStart;
          let closed = false;
          while (i < text.length) {
            const ch = text[i];
            if (ch === "\\" && i + 1 < text.length) {
              i += 2;
              continue;
            }
            if (ch === quote) {
              closed = true;
              break;
            }
            if (ch === "\n" || ch === "]" || ch === ">") break;
            i += 1;
          }
          if (!closed) {
            const loc = locationOf(text, match.index);
            issues2.push({
              ruleId,
              severity: "error",
              offset: match.index,
              line: loc.line,
              column: loc.column,
              context: contextOf(text, match.index),
              message: `Attribute ${match[1] ?? ""} starts with ${quote} but no matching quote was found before a boundary.`
            });
          }
          match = re.exec(text);
        }
        return issues2;
      };
      const source = readText();
      const enabledRules = new Set(
        ruleText.split(",").map((part) => part.trim()).filter(Boolean)
      );
      const issues = [];
      if (enabledRules.has("html-attrs"))
        issues.push(
          ...scanQuotedAssignments(source.html ?? source.text, "html-attrs/unbalanced-quote")
        );
      if (enabledRules.has("shortcodes"))
        issues.push(...scanQuotedAssignments(source.text, "shortcodes/unbalanced-quote"));
      return {
        ok: source.found && issues.every((issue) => issue.severity !== "error"),
        found: source.found,
        selector: sel,
        source: source.source,
        rules: Array.from(enabledRules),
        issueCount: issues.length,
        errorCount: issues.filter((issue) => issue.severity === "error").length,
        textLength: source.text.length,
        issues
      };
    },
    args: [selector, selection, rules]
  });
  return res?.result ?? { ok: false, found: false, issues: [] };
}
async function runFindCommand(tabId, params) {
  const locator = typeof params.locator === "string" ? params.locator : "";
  const query = typeof params.query === "string" ? params.query : "";
  const role = typeof params.role === "string" ? params.role : void 0;
  const indexModifier = typeof params.indexModifier === "string" ? params.indexModifier : void 0;
  const index = typeof params.index === "number" ? params.index : void 0;
  const action = typeof params.action === "string" ? params.action : "inspect";
  const exact = params.exact === true;
  const limit = typeof params.limit === "number" ? Math.max(1, Math.min(100, params.limit)) : 20;
  const frame = readFrameParam(params);
  const allMatches = await findSemanticMatches(tabId, {
    locator,
    query,
    role,
    exact,
    limit,
    frame
  });
  const matches = applyFindIndexModifier(allMatches, indexModifier, index);
  if (action === "inspect") {
    return {
      locator,
      query,
      role,
      exact,
      frame,
      indexModifier,
      index,
      totalCount: allMatches.length,
      count: matches.length,
      matches
    };
  }
  const first = matches[0];
  if (!first) return { ok: false, locator, query, role, action, count: 0, matches: [] };
  if (action === "text") {
    return { ok: true, locator, query, role, action, match: first, value: first.text };
  }
  await requireOperationApproval(
    "find",
    tabId,
    `Run find action ${quoteForIntent(action)} on ${quoteForIntent(first.selector)}${frameIntentSuffix(frame)}.`
  );
  if (action === "click")
    return { action, match: first, result: await clickSelector(tabId, first.selector, frame) };
  if (action === "fill") {
    const value = typeof params.value === "string" ? params.value : "";
    return {
      action,
      match: first,
      result: await fillField(tabId, first.selector, value, false, frame)
    };
  }
  if (action === "type") {
    const value = typeof params.value === "string" ? params.value : "";
    await focusElement(tabId, first.selector, frame);
    return { action, match: first, result: await typeText(tabId, value) };
  }
  if (action === "hover")
    return { action, match: first, result: await hoverSelector(tabId, first.selector, frame) };
  if (action === "focus")
    return { action, match: first, result: await focusElement(tabId, first.selector, frame) };
  if (action === "check")
    return { action, match: first, result: await setChecked(tabId, first.selector, true, frame) };
  if (action === "uncheck")
    return { action, match: first, result: await setChecked(tabId, first.selector, false, frame) };
  return {
    ok: false,
    error: "unsupported_find_action",
    action,
    supportedActions: [
      "inspect",
      "text",
      "click",
      "fill",
      "type",
      "hover",
      "focus",
      "check",
      "uncheck"
    ]
  };
}
async function findSemanticMatches(tabId, params) {
  return runFrameScript(
    tabId,
    params.frame,
    params,
    (ctx, opts) => {
      const cssEscape = (value) => {
        const escaper = globalThis.CSS?.escape;
        return escaper ? escaper(value) : value.replace(/["\\]/g, "\\$&");
      };
      const normalize = (value) => (value ?? "").replace(/\s+/g, " ").trim();
      const matchesText = (value) => {
        const left = normalize(value);
        const right = normalize(opts.query);
        return opts.exact ? left === right : left.toLowerCase().includes(right.toLowerCase());
      };
      const roleOf = (el) => {
        const explicit = el.getAttribute("role");
        if (explicit) return explicit.toLowerCase();
        const tag = el.tagName.toLowerCase();
        if (tag === "a" && el.href) return "link";
        if (tag === "button") return "button";
        if (tag === "select") return "combobox";
        if (tag === "textarea") return "textbox";
        if (tag === "img") return "img";
        if (tag === "input") {
          const type = (el.type || "text").toLowerCase();
          if (type === "checkbox") return "checkbox";
          if (type === "radio") return "radio";
          if (type === "submit" || type === "button") return "button";
          return "textbox";
        }
        return "generic";
      };
      const textOf = (el) => {
        const input = el;
        return normalize(
          el.getAttribute("aria-label") || el.getAttribute("alt") || el.getAttribute("title") || input.placeholder || input.value || el.innerText || el.textContent
        );
      };
      const selectorFor = (el) => {
        if (el.id && ctx.doc.querySelectorAll(`#${cssEscape(el.id)}`).length === 1) {
          return `#${cssEscape(el.id)}`;
        }
        for (const attr of [
          "data-testid",
          "data-test",
          "name",
          "aria-label",
          "placeholder",
          "title",
          "alt"
        ]) {
          const value = el.getAttribute(attr);
          if (value) {
            const selector = `${el.tagName.toLowerCase()}[${attr}="${cssEscape(value)}"]`;
            if (ctx.doc.querySelectorAll(selector).length === 1) return selector;
          }
        }
        const parts = [];
        let current = el;
        while (current && parts.length < 5) {
          const parent = current.parentElement;
          const tag = current.tagName.toLowerCase();
          if (!parent) {
            parts.unshift(tag);
            break;
          }
          const siblings = Array.from(parent.children).filter(
            (child) => child.tagName === current?.tagName
          );
          const nth = siblings.indexOf(current) + 1;
          parts.unshift(siblings.length > 1 ? `${tag}:nth-of-type(${nth})` : tag);
          current = parent;
        }
        return parts.join(" > ");
      };
      const boxOf = (el) => {
        const rect = el.getBoundingClientRect();
        return {
          x: Math.round(ctx.offsetX + rect.left),
          y: Math.round(ctx.offsetY + rect.top),
          width: Math.round(rect.width),
          height: Math.round(rect.height)
        };
      };
      const pushMatch = (matches2, el) => {
        if (matches2.some((match) => ctx.doc.querySelector(match.selector) === el)) return;
        matches2.push({
          index: matches2.length,
          selector: selectorFor(el),
          frame: ctx.frame,
          tag: el.tagName.toLowerCase(),
          role: roleOf(el),
          text: textOf(el),
          value: el.value,
          box: boxOf(el)
        });
      };
      const matches = [];
      if (opts.locator === "css") {
        for (const el of Array.from(ctx.doc.querySelectorAll(opts.query))) {
          pushMatch(matches, el);
          if (matches.length >= opts.limit) break;
        }
        return matches;
      }
      if (opts.locator === "label") {
        for (const label of Array.from(ctx.doc.querySelectorAll("label"))) {
          if (!matchesText(label.textContent ?? "")) continue;
          const control = label.control ?? label.querySelector("input, textarea, select, [contenteditable='true']");
          if (control) pushMatch(matches, control);
          if (matches.length >= opts.limit) break;
        }
        return matches;
      }
      const candidates = Array.from(
        ctx.doc.querySelectorAll(
          [
            "a[href]",
            "button",
            "input",
            "textarea",
            "select",
            "img",
            "[role]",
            "[aria-label]",
            "[placeholder]",
            "[title]",
            "[data-testid]",
            "[data-test]",
            "[contenteditable='true']"
          ].join(",")
        )
      );
      for (const el of candidates) {
        if (opts.locator === "role") {
          if (opts.role && roleOf(el) !== opts.role.toLowerCase()) continue;
          if (opts.query && !matchesText(textOf(el))) continue;
        } else if (opts.locator === "text") {
          if (!matchesText(textOf(el))) continue;
        } else if (opts.locator === "placeholder") {
          if (!matchesText(el.getAttribute("placeholder") ?? "")) continue;
        } else if (opts.locator === "alt") {
          if (!matchesText(el.getAttribute("alt") ?? "")) continue;
        } else if (opts.locator === "title") {
          if (!matchesText(el.getAttribute("title") ?? "")) continue;
        } else if (opts.locator === "testid") {
          if (!matchesText(el.getAttribute("data-testid") ?? el.getAttribute("data-test") ?? ""))
            continue;
        } else {
          continue;
        }
        pushMatch(matches, el);
        if (matches.length >= opts.limit) break;
      }
      return matches;
    }
  );
}
function applyFindIndexModifier(matches, modifier, index) {
  if (modifier === "first") return matches.slice(0, 1);
  if (modifier === "last")
    return matches.length > 0 ? [matches[matches.length - 1]] : [];
  if (modifier === "nth") {
    const resolvedIndex = index ?? 0;
    return matches[resolvedIndex] ? [matches[resolvedIndex]] : [];
  }
  return matches;
}
async function snapshotTab(tabId, params) {
  const selector = typeof params.selector === "string" ? params.selector : void 0;
  const frame = readFrameParam(params);
  const depth = typeof params.depth === "number" ? Math.max(1, Math.min(12, params.depth)) : 5;
  const interactiveOnly = params.interactiveOnly === true;
  const compact = params.compact === true;
  const result = await runFrameScript(
    tabId,
    frame,
    { selector, depth, interactiveOnly, compact },
    (ctx, opts) => {
      const cssEscape = (value) => {
        const escaper = globalThis.CSS?.escape;
        return escaper ? escaper(value) : value.replace(/["\\]/g, "\\$&");
      };
      const normalize = (value) => (value ?? "").replace(/\s+/g, " ").trim().slice(0, 200);
      const roleOf = (el) => {
        const explicit = el.getAttribute("role");
        if (explicit) return explicit.toLowerCase();
        const tag = el.tagName.toLowerCase();
        if (tag === "a" && el.href) return "link";
        if (tag === "button") return "button";
        if (tag === "select") return "combobox";
        if (tag === "textarea") return "textbox";
        if (tag === "img") return "img";
        if (tag === "input") {
          const type = (el.type || "text").toLowerCase();
          if (type === "checkbox") return "checkbox";
          if (type === "radio") return "radio";
          if (type === "submit" || type === "button") return "button";
          return "textbox";
        }
        return "generic";
      };
      const selectorFor = (el) => {
        if (el.id && ctx.doc.querySelectorAll(`#${cssEscape(el.id)}`).length === 1) {
          return `#${cssEscape(el.id)}`;
        }
        for (const attr of [
          "data-testid",
          "data-test",
          "name",
          "aria-label",
          "placeholder",
          "title",
          "alt"
        ]) {
          const value = el.getAttribute(attr);
          if (value) {
            const selector2 = `${el.tagName.toLowerCase()}[${attr}="${cssEscape(value)}"]`;
            if (ctx.doc.querySelectorAll(selector2).length === 1) return selector2;
          }
        }
        const parts = [];
        let current = el;
        while (current && parts.length < opts.depth) {
          const parent = current.parentElement;
          const tag = current.tagName.toLowerCase();
          if (!parent) {
            parts.unshift(tag);
            break;
          }
          const siblings = Array.from(parent.children).filter(
            (child) => child.tagName === current?.tagName
          );
          const nth = siblings.indexOf(current) + 1;
          parts.unshift(siblings.length > 1 ? `${tag}:nth-of-type(${nth})` : tag);
          current = parent;
        }
        return parts.join(" > ");
      };
      const nameOf = (el) => {
        const input = el;
        return normalize(
          el.getAttribute("aria-label") || el.getAttribute("alt") || el.getAttribute("title") || input.placeholder || input.value || el.innerText || el.textContent
        );
      };
      const isInteractive = (el) => {
        const role = roleOf(el);
        return ["button", "link", "textbox", "checkbox", "radio", "combobox"].includes(role) || el.hasAttribute("onclick") || el.hasAttribute("tabindex") || el.isContentEditable;
      };
      const boxOf = (el) => {
        const rect = el.getBoundingClientRect();
        return {
          x: Math.round(ctx.offsetX + rect.left),
          y: Math.round(ctx.offsetY + rect.top),
          width: Math.round(rect.width),
          height: Math.round(rect.height)
        };
      };
      const root = opts.selector ? ctx.doc.querySelector(opts.selector) : ctx.doc.body;
      if (!root) {
        return {
          url: ctx.win.location.href,
          title: ctx.doc.title,
          selector: opts.selector,
          frame: ctx.frame,
          found: false,
          elements: []
        };
      }
      const query = [
        "a[href]",
        "button",
        "input",
        "textarea",
        "select",
        "img",
        "[role]",
        "[aria-label]",
        "[title]",
        "[data-testid]",
        "[data-test]",
        "[contenteditable='true']"
      ].join(",");
      const elements = [];
      const candidates = Array.from(root.querySelectorAll(query));
      if (root instanceof Element && root.matches(query)) candidates.unshift(root);
      for (const el of candidates) {
        const interactive = isInteractive(el);
        if (opts.interactiveOnly && !interactive) continue;
        const rect = el.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) continue;
        elements.push({
          ref: `@e${elements.length + 1}`,
          role: roleOf(el),
          name: nameOf(el),
          text: normalize(el.innerText || el.textContent),
          selector: selectorFor(el),
          frame: ctx.frame,
          box: boxOf(el),
          interactive
        });
        if (elements.length >= 250) break;
      }
      return {
        url: ctx.win.location.href,
        title: ctx.doc.title,
        selector: opts.selector,
        frame: ctx.frame,
        found: true,
        generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        elements: opts.compact ? elements.map(
          ({ selector: _selector, interactive: _interactive, ...element }) => element
        ) : elements,
        refMap: Object.fromEntries(elements.map((element) => [element.ref, element.selector]))
      };
    }
  );
  const typedResult = result;
  const refMap = /* @__PURE__ */ new Map();
  for (const [ref, resolvedSelector] of Object.entries(typedResult?.refMap ?? {})) {
    refMap.set(ref, { selector: resolvedSelector, frame });
  }
  snapshotRefCache.set(tabId, refMap);
  if (typedResult && "refMap" in typedResult) {
    delete typedResult.refMap;
  }
  return typedResult ?? { found: false, elements: [] };
}
async function clickSnapshotRef(tabId, ref) {
  const target = snapshotRefCache.get(tabId)?.get(ref);
  if (!target) {
    throw new GatewayError("snapshot_ref_not_found", `snapshot ref not found or stale: ${ref}`);
  }
  return clickSelector(tabId, target.selector, target.frame);
}
async function screenshot(tabId, clip) {
  if (!browser2.supportsDebugger) {
    return screenshotWithVisibleTabCapture(tabId, clip);
  }
  await attachDebugger(tabId);
  const params = { format: "png" };
  if (clip) {
    params.clip = { ...clip, scale: 1 };
  }
  const result = await browser2.debugger.sendCommand(
    { tabId },
    "Page.captureScreenshot",
    params
  );
  return { dataUrl: `data:image/png;base64,${result.data}` };
}
async function screenshotWithVisibleTabCapture(tabId, clip) {
  if (clip) {
    throw new GatewayError(
      "unsupported_on_firefox_mvp",
      "Firefox screenshot MVP does not support clip."
    );
  }
  if (!browser2.supportsVisibleTabCapture) {
    throw new GatewayError(
      "unsupported_on_firefox_mvp",
      "This browser target does not support screenshot capture."
    );
  }
  const tab = await browser2.tabs.get(tabId);
  const windowId = tab.windowId;
  const activeTabs = typeof windowId === "number" ? await browser2.tabs.query({ active: true, windowId }) : [];
  const previousActive = activeTabs.find((item) => typeof item.id === "number");
  const shouldRestore = previousActive?.id !== void 0 && previousActive.id !== tabId && typeof windowId === "number";
  if (typeof windowId === "number" && tab.active !== true) {
    await browser2.tabs.update(tabId, { active: true });
  }
  try {
    const dataUrl = await browser2.tabs.captureVisibleTab(windowId, { format: "png" });
    return { dataUrl };
  } finally {
    if (shouldRestore && previousActive.id !== void 0) {
      await browser2.tabs.update(previousActive.id, { active: true }).catch(() => void 0);
    }
  }
}
async function printPagePDF(tabId) {
  await attachDebugger(tabId);
  const tab = await browser2.tabs.get(tabId);
  const result = await browser2.debugger.sendCommand({ tabId }, "Page.printToPDF", {
    printBackground: true
  });
  return {
    dataUrl: `data:application/pdf;base64,${result.data}`,
    url: tab.url ?? "",
    title: tab.title ?? ""
  };
}
async function setRuntimeStream(tabId, enabled) {
  if (enabled) {
    streamingTabs.add(tabId);
    await attachDebugger(tabId);
    await installDomMutationStream(tabId);
  } else {
    streamingTabs.delete(tabId);
  }
  return { ok: true, enabled, tabId };
}
async function installDomMutationStream(tabId) {
  await browser2.scripting.executeScript({
    target: { tabId },
    func: () => {
      const key = "__abgRuntimeStreamInstalled";
      const win = window;
      if (win[key]) return;
      win[key] = true;
      let pending = 0;
      const observer = new MutationObserver((mutations) => {
        pending += mutations.length;
        if (pending === mutations.length) {
          setTimeout(() => {
            const count = pending;
            pending = 0;
            browser2.runtime.sendMessage({
              type: "stream_dom_mutation",
              count,
              url: location.href,
              title: document.title
            });
          }, 100);
        }
      });
      observer.observe(document.documentElement, {
        childList: true,
        attributes: true,
        characterData: true,
        subtree: true
      });
    }
  });
}
async function extractTables(tabId, selector, frame) {
  return runFrameScript(tabId, frame, { selector }, (ctx, opts) => {
    const sel = opts.selector;
    const textOf = (el) => (el?.textContent ?? "").replace(/\s+/g, " ").trim();
    const cssEscape = (value) => {
      const escaper = globalThis.CSS?.escape;
      return escaper ? escaper(value) : value.replace(/["\\]/g, "\\$&");
    };
    const selectorFor = (el) => {
      if (el.id) return `#${cssEscape(el.id)}`;
      const parts = [];
      let current = el;
      while (current && current.nodeType === Node.ELEMENT_NODE && parts.length < 5) {
        const parent = current.parentElement;
        const currentTag = current.tagName;
        const tag = currentTag.toLowerCase();
        if (!parent) {
          parts.unshift(tag);
          break;
        }
        const siblings = Array.from(parent.children).filter(
          (child) => child instanceof Element && child.tagName === currentTag
        );
        const nth = siblings.indexOf(current) + 1;
        parts.unshift(siblings.length > 1 ? `${tag}:nth-of-type(${nth})` : tag);
        current = parent;
      }
      return parts.join(" > ");
    };
    const root = sel ? ctx.doc.querySelector(sel) : ctx.doc;
    const tableElements = root instanceof HTMLTableElement ? [root] : Array.from((root ?? ctx.doc).querySelectorAll("table"));
    const chosen = tableElements.map((table, index) => ({ table, index, score: table.querySelectorAll("tr").length })).sort((a, b) => b.score - a.score).slice(0, sel ? 20 : 5);
    const tables = chosen.map(({ table, index }) => {
      const rows = Array.from(table.querySelectorAll("tr")).map(
        (tr) => Array.from(tr.children).filter((cell) => cell instanceof HTMLTableCellElement).map((cell) => textOf(cell))
      );
      const explicitHeaders = Array.from(table.querySelectorAll("thead th")).map(
        (th) => textOf(th)
      );
      const firstHeaderRow = Array.from(table.querySelectorAll("tr")).find(
        (tr) => tr.querySelector("th")
      );
      const headers = explicitHeaders.length > 0 ? explicitHeaders : firstHeaderRow ? Array.from(firstHeaderRow.children).filter((cell) => cell instanceof HTMLTableCellElement).map((cell) => textOf(cell)) : [];
      const dataRows = headers.length > 0 && rows.length > 0 && rows[0]?.join("\0") === headers.join("\0") ? rows.slice(1) : rows;
      return {
        index,
        selector: selectorFor(table),
        caption: textOf(table.querySelector("caption")) || void 0,
        headers,
        rows: dataRows,
        rowCount: dataRows.length,
        columnCount: Math.max(headers.length, ...dataRows.map((row) => row.length), 0)
      };
    });
    return {
      url: ctx.win.location.href,
      title: ctx.doc.title,
      frame: ctx.frame,
      selector: sel,
      tables,
      userMessage: tables.length === 0 ? "table \u304C\u898B\u3064\u304B\u308A\u307E\u305B\u3093\u3067\u3057\u305F\u3002`abg read --selector` \u307E\u305F\u306F `abg screenshot` \u3067\u753B\u9762\u69CB\u9020\u3092\u78BA\u8A8D\u3057\u3066\u304F\u3060\u3055\u3044\u3002" : void 0,
      nextCommand: tables.length === 0 ? 'abg read <tab> --selector "main" --format markdown' : void 0
    };
  });
}
async function describeElements(tabId, params) {
  const all = params.all === true;
  const limit = typeof params.limit === "number" ? Math.max(1, Math.min(500, params.limit)) : 80;
  const kindFilter = typeof params.kind === "string" ? params.kind.toLowerCase() : void 0;
  const grid = typeof params.grid === "string" ? params.grid : void 0;
  const frame = readFrameParam(params);
  return runFrameScript(
    tabId,
    frame,
    { all, limit, kindFilter, grid },
    (ctx, opts) => {
      const cssEscape = (value) => {
        const escaper = globalThis.CSS?.escape;
        return escaper ? escaper(value) : value.replace(/["\\]/g, "\\$&");
      };
      const trimText = (value) => value.replace(/\s+/g, " ").trim().slice(0, 160);
      const selectorFor = (el) => {
        if (el.id && ctx.doc.querySelectorAll(`#${cssEscape(el.id)}`).length === 1) {
          return `#${cssEscape(el.id)}`;
        }
        for (const attr of ["data-testid", "data-test", "name", "aria-label"]) {
          const value = el.getAttribute(attr);
          if (value) {
            const selector = `${el.tagName.toLowerCase()}[${attr}="${cssEscape(value)}"]`;
            if (ctx.doc.querySelectorAll(selector).length === 1) return selector;
          }
        }
        const parts = [];
        let current = el;
        while (current && current.nodeType === Node.ELEMENT_NODE && parts.length < 5) {
          const parent = current.parentElement;
          const currentTag = current.tagName;
          const tag = currentTag.toLowerCase();
          if (!parent) {
            parts.unshift(tag);
            break;
          }
          const siblings = Array.from(parent.children).filter(
            (child) => child instanceof Element && child.tagName === currentTag
          );
          const nth = siblings.indexOf(current) + 1;
          parts.unshift(siblings.length > 1 ? `${tag}:nth-of-type(${nth})` : tag);
          current = parent;
        }
        return parts.join(" > ");
      };
      const kindOf = (el) => {
        const role = el.getAttribute("role")?.toLowerCase();
        const tag = el.tagName.toLowerCase();
        if (tag === "a") return "link";
        if (tag === "button" || role === "button") return "button";
        if (tag === "input") return el.type || "input";
        if (tag === "textarea" || tag === "select") return tag;
        if (role === "link") return "link";
        return "clickable";
      };
      const isVisible = (el, rect) => {
        const style = getComputedStyle(el);
        return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none" && Number(style.opacity || "1") !== 0;
      };
      const inViewport = (rect) => rect.bottom >= 0 && rect.right >= 0 && rect.top <= ctx.win.innerHeight && rect.left <= ctx.win.innerWidth;
      const candidates = Array.from(
        ctx.doc.querySelectorAll(
          [
            "a[href]",
            "button",
            "input",
            "textarea",
            "select",
            "summary",
            "[role='button']",
            "[role='link']",
            "[onclick]",
            "[tabindex]:not([tabindex='-1'])",
            "[contenteditable='true']"
          ].join(",")
        )
      );
      const elements = [];
      for (const el of candidates) {
        const rect = el.getBoundingClientRect();
        const kind = kindOf(el);
        if (opts.kindFilter && kind !== opts.kindFilter) continue;
        if (!isVisible(el, rect) || !opts.all && !inViewport(rect)) continue;
        const html = el;
        const text = trimText(
          el.getAttribute("aria-label") || el.getAttribute("title") || (html.innerText ?? "") || el.value || el.placeholder || ""
        );
        elements.push({
          id: elements.length,
          kind,
          text,
          bbox: {
            x: Math.round(ctx.offsetX + rect.left),
            y: Math.round(ctx.offsetY + rect.top),
            w: Math.round(rect.width),
            h: Math.round(rect.height)
          },
          selector: selectorFor(el),
          frame: ctx.frame
        });
        if (elements.length >= opts.limit) break;
      }
      const match = opts.grid?.match(/^(\d+)x(\d+)$/i);
      if (match) {
        const cols = Math.max(1, Math.min(50, Number(match[1])));
        const rows = Math.max(1, Math.min(50, Number(match[2])));
        const cellW = ctx.win.innerWidth / cols;
        const cellH = ctx.win.innerHeight / rows;
        for (let row = 0; row < rows; row++) {
          for (let col = 0; col < cols; col++) {
            elements.push({
              id: elements.length,
              kind: "grid-cell",
              text: `r${row + 1}c${col + 1}`,
              bbox: {
                x: Math.round(ctx.offsetX + col * cellW),
                y: Math.round(ctx.offsetY + row * cellH),
                w: Math.round(cellW),
                h: Math.round(cellH)
              },
              frame: ctx.frame
            });
          }
        }
      }
      return {
        url: ctx.win.location.href,
        title: ctx.doc.title,
        frame: ctx.frame,
        viewport: { width: ctx.win.innerWidth, height: ctx.win.innerHeight },
        elements
      };
    }
  );
}
async function getNetworkLog(tabId, params) {
  await attachDebugger(tabId);
  if (params.wait === true) {
    return waitForNetworkResponse(tabId, params);
  }
  if (params.body === true && typeof params.requestId === "string") {
    return {
      requestId: params.requestId,
      body: await getResponseBodyPreview(tabId, params.requestId, readNetworkBodyMaxBytes(params))
    };
  }
  const filters = readNetworkFilters(params);
  const limit = typeof params.limit === "number" ? Math.max(1, Math.min(200, params.limit)) : 100;
  const items = (networkBuffers.get(tabId) ?? []).filter((entry) => networkEntryMatches(entry, filters)).slice(-limit).map(publicNetworkEntry);
  return { requests: items };
}
async function exportHAR(tabId, params) {
  await attachDebugger(tabId);
  const filters = readNetworkFilters(params);
  const limit = readHARLimit(params);
  const buffered = networkBuffers.get(tabId) ?? [];
  const entries = buffered.filter((entry) => networkEntryMatches(entry, filters)).slice(-limit);
  const tab = permittedTabs.get(tabId);
  const generatedAt = (/* @__PURE__ */ new Date()).toISOString();
  const pageId = `abg-tab-${tabId}`;
  const redaction = {
    mode: "metadata_only",
    cookies: "omitted",
    authorizationHeaders: "omitted",
    requestHeaders: "omitted",
    requestBodies: "omitted",
    responseBodies: "omitted",
    responseHeaders: "content-type only when available"
  };
  const har = {
    log: {
      version: "1.2",
      creator: {
        name: "Agent Browser Gateway",
        version: VERSION,
        comment: "ABG exports a metadata-only HAR by default."
      },
      pages: [
        {
          startedDateTime: tab ? new Date(tab.permittedAt).toISOString() : generatedAt,
          id: pageId,
          title: tab?.title ?? "",
          pageTimings: {
            onContentLoad: -1,
            onLoad: -1
          },
          comment: "Shared tab HAR snapshot generated locally by ABG."
        }
      ],
      entries: entries.map((entry) => networkEntryToHAR(entry, pageId)),
      _abg: {
        generatedAt,
        tabId,
        sourceUrl: tab?.url ?? "",
        sourceTitle: tab?.title ?? "",
        exportMode: "one_shot",
        entryLimit: limit,
        totalBuffered: buffered.length,
        includedEntries: entries.length,
        filters: publicNetworkFilters(filters),
        redaction,
        payloadPolicy: "Request and response bodies are never embedded in this export.",
        storage: "Caller-chosen local path or ABG temporary directory; no ABG-operated cloud service."
      }
    }
  };
  return {
    ok: true,
    mode: "one_shot",
    har,
    entryCount: entries.length,
    totalBuffered: buffered.length,
    limit,
    redaction: "metadata_only",
    filters: publicNetworkFilters(filters),
    outputPath: params.outputPath,
    byteSizeEstimate: new TextEncoder().encode(JSON.stringify(har)).byteLength,
    generatedAt
  };
}
async function inspectState(tabId, params) {
  await attachDebugger(tabId);
  const kind = normalizeStateKind(params.kind);
  const includeValues = params.includeValues === true;
  const limit = readStateLimit(params);
  const tab = permittedTabs.get(tabId);
  const result = {
    tabId,
    url: tab?.url ?? "",
    title: tab?.title ?? "",
    origin: tab?.origin ?? "",
    kind,
    includeValues,
    redaction: includeValues ? "explicit_values" : "values_redacted",
    writeOperations: "not_supported"
  };
  if (kind === "cookies" || kind === "all") {
    result.cookies = await inspectCookies(tabId, tab?.url, params, includeValues, limit);
  }
  if (kind === "local-storage" || kind === "session-storage" || kind === "all") {
    const storage = await inspectWebStorage(tabId, params, includeValues, limit);
    if (kind === "local-storage" || kind === "all") {
      result.localStorage = storage.localStorage;
    }
    if (kind === "session-storage" || kind === "all") {
      result.sessionStorage = storage.sessionStorage;
    }
  }
  return result;
}
function normalizeStateKind(value) {
  if (value === "cookie") return "cookies";
  if (value === "localStorage" || value === "local-storage") return "local-storage";
  if (value === "sessionStorage" || value === "session-storage") return "session-storage";
  if (value === "all" || value === void 0 || value === null || value === "") return "all";
  throw new GatewayError(
    "bad_state_kind",
    "state kind must be cookies, local-storage, session-storage, or all"
  );
}
function readStateLimit(params) {
  return typeof params.limit === "number" ? Math.max(1, Math.min(500, params.limit)) : 200;
}
async function inspectCookies(tabId, rawUrl, params, includeValues, limit) {
  if (!rawUrl) return { available: false, error: "tab URL unavailable", count: 0, cookies: [] };
  const namePattern = typeof params.name === "string" ? params.name : void 0;
  try {
    const result = await browser2.debugger.sendCommand({ tabId }, "Network.getCookies", {
      urls: [rawUrl]
    });
    const matched = (result.cookies ?? []).filter(
      (cookie) => !namePattern || globMatch(namePattern, cookie.name)
    );
    const filtered = matched.slice(0, limit);
    return {
      available: true,
      count: filtered.length,
      totalMatches: matched.length,
      limited: matched.length > filtered.length,
      filter: namePattern,
      cookies: filtered.map((cookie) => publicCookie(cookie, includeValues))
    };
  } catch (error) {
    return {
      available: false,
      count: 0,
      cookies: [],
      filter: namePattern,
      error: error instanceof Error ? error.message : String(error)
    };
  }
}
function publicCookie(cookie, includeValues) {
  const item = {
    name: cookie.name,
    domain: cookie.domain,
    path: cookie.path,
    expires: cookie.expires,
    size: cookie.size,
    valueBytes: new TextEncoder().encode(cookie.value).byteLength,
    valueRedacted: !includeValues,
    httpOnly: cookie.httpOnly,
    secure: cookie.secure,
    session: cookie.session,
    sameSite: cookie.sameSite,
    priority: cookie.priority
  };
  if (includeValues) item.value = cookie.value;
  return item;
}
async function inspectWebStorage(tabId, params, includeValues, limit) {
  const keyPattern = typeof params.storageKey === "string" ? params.storageKey : void 0;
  return runFrameScript(
    tabId,
    void 0,
    { includeValues, limit, keyPattern },
    (ctx, opts) => {
      const matches = (pattern, value) => {
        if (!pattern) return true;
        const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\?/g, ".");
        return new RegExp(`^${escaped}$`, "i").test(value);
      };
      const read = (label, storage) => {
        try {
          const entries = [];
          const total = storage.length;
          let totalMatches = 0;
          for (let index = 0; index < total; index++) {
            const key = storage.key(index);
            if (!key || !matches(opts.keyPattern, key)) continue;
            totalMatches += 1;
            if (entries.length >= opts.limit) continue;
            const value = storage.getItem(key) ?? "";
            const item = {
              key,
              valueBytes: new TextEncoder().encode(value).byteLength,
              valueRedacted: !opts.includeValues
            };
            if (opts.includeValues) item.value = value;
            entries.push(item);
          }
          return {
            available: true,
            origin: ctx.win.location.origin,
            count: entries.length,
            totalKeys: total,
            totalMatches,
            limited: totalMatches > entries.length,
            filter: opts.keyPattern,
            entries
          };
        } catch (error) {
          return {
            available: false,
            count: 0,
            entries: [],
            error: error instanceof Error ? error.message : String(error),
            kind: label
          };
        }
      };
      return {
        localStorage: read("localStorage", ctx.win.localStorage),
        sessionStorage: read("sessionStorage", ctx.win.sessionStorage)
      };
    }
  );
}
async function inspectFramework(tabId, params) {
  const kind = normalizeFrameworkKind(params.kind);
  const limit = typeof params.limit === "number" ? Math.max(1, Math.min(500, params.limit)) : 80;
  const depth = typeof params.depth === "number" ? Math.max(1, Math.min(10, params.depth)) : 4;
  return runFrameScript(
    tabId,
    void 0,
    { kind, limit, depth },
    (ctx, opts) => {
      const win = ctx.win;
      const toNumber = (value) => typeof value === "number" && Number.isFinite(value) ? Math.round(value) : void 0;
      const jsonish = (value) => {
        if (!value || typeof value !== "object") return {};
        const dict = value;
        return {
          name: typeof dict.name === "string" ? dict.name : void 0,
          entryType: typeof dict.entryType === "string" ? dict.entryType : void 0,
          startTime: toNumber(dict.startTime),
          duration: toNumber(dict.duration),
          url: typeof dict.url === "string" ? dict.url : void 0,
          key: typeof dict.key === "string" ? dict.key : void 0,
          id: typeof dict.id === "string" ? dict.id : void 0,
          index: toNumber(dict.index),
          sameDocument: typeof dict.sameDocument === "boolean" ? dict.sameDocument : void 0
        };
      };
      const detectReactMarkers = () => {
        let fiberMarkers = 0;
        let propsMarkers = 0;
        const elements = Array.from(ctx.doc.querySelectorAll("*")).slice(0, 5e3);
        for (const element of elements) {
          const names = Object.getOwnPropertyNames(element);
          if (names.some((name) => name.startsWith("__reactFiber$"))) fiberMarkers += 1;
          if (names.some((name) => name.startsWith("__reactProps$"))) propsMarkers += 1;
          if (fiberMarkers + propsMarkers >= opts.limit) break;
        }
        return { inspectedElements: elements.length, fiberMarkers, propsMarkers };
      };
      const typeName = (type) => {
        if (typeof type === "string") return type;
        if (typeof type === "function") {
          const fn = type;
          return fn.displayName || fn.name || "Anonymous";
        }
        if (type && typeof type === "object") {
          const dict = type;
          if (typeof dict.displayName === "string") return dict.displayName;
          const nested = dict.type;
          if (nested?.displayName || nested?.name)
            return nested.displayName || nested.name || "Anonymous";
          const render = dict.render;
          if (render?.displayName || render?.name)
            return render.displayName || render.name || "Anonymous";
        }
        return "Unknown";
      };
      const reactRendererEntries = () => {
        const renderers = win.__REACT_DEVTOOLS_GLOBAL_HOOK__?.renderers;
        if (!renderers) return [];
        if (renderers instanceof Map) return Array.from(renderers.entries());
        return Object.entries(renderers).map(([key, value]) => [Number(key), value]);
      };
      const inspectReact = () => {
        const hook = win.__REACT_DEVTOOLS_GLOBAL_HOOK__;
        const markerSummary = detectReactMarkers();
        if (!hook || typeof hook.getFiberRoots !== "function") {
          return {
            available: false,
            reason: "React DevTools global hook with getFiberRoots is not available",
            markerSummary,
            mutationPolicy: "read-only; no component mutation or framework patching"
          };
        }
        const renderers = reactRendererEntries();
        const roots = [];
        let nodeCount = 0;
        const seen = /* @__PURE__ */ new Set();
        const fiberName = (fiber) => typeName(fiber.elementType ?? fiber.type);
        const fiberKind = (fiber) => typeof fiber.type === "string" ? "host" : "component";
        const propNames = (fiber) => {
          const props = fiber.memoizedProps;
          if (!props || typeof props !== "object") return [];
          return Object.keys(props).filter((name) => name !== "children").slice(0, 20);
        };
        const walk = (fiber, currentDepth, nodes, parentId) => {
          if (!fiber || nodeCount >= opts.limit || currentDepth > opts.depth) return;
          if (seen.has(fiber)) return;
          seen.add(fiber);
          const id = nodes.length;
          nodeCount += 1;
          nodes.push({
            id,
            parentId,
            depth: currentDepth,
            name: fiberName(fiber),
            kind: fiberKind(fiber),
            propNames: propNames(fiber)
          });
          walk(fiber.child, currentDepth + 1, nodes, id);
          walk(fiber.sibling, currentDepth, nodes, parentId);
        };
        for (const [rendererId, renderer] of renderers) {
          if (roots.length >= 10 || nodeCount >= opts.limit) break;
          const fiberRoots = Array.from(hook.getFiberRoots(rendererId) ?? []).slice(0, 10);
          for (const root of fiberRoots) {
            const current = root.current ?? root;
            const nodes = [];
            walk(current, 0, nodes);
            roots.push({
              rendererId,
              rendererPackageName: renderer.rendererPackageName,
              version: renderer.version,
              nodeCount: nodes.length,
              depthLimit: opts.depth,
              nodes
            });
            if (nodeCount >= opts.limit) break;
          }
        }
        return {
          available: true,
          rendererCount: renderers.length,
          rootCount: roots.length,
          nodeLimit: opts.limit,
          markerSummary,
          roots,
          mutationPolicy: "read-only; props are represented by names only"
        };
      };
      const inspectWebVitals = () => {
        const perf = ctx.win.performance;
        const observerCtor = ctx.win.PerformanceObserver;
        const supported = observerCtor?.supportedEntryTypes ?? [];
        const entries = (type) => {
          try {
            return perf.getEntriesByType(type).slice(-opts.limit).map((entry) => jsonish(entry));
          } catch {
            return [];
          }
        };
        const layoutShiftEntries = (() => {
          try {
            return perf.getEntriesByType("layout-shift");
          } catch {
            return [];
          }
        })();
        const cls = layoutShiftEntries.filter((entry) => entry.hadRecentInput !== true).reduce((sum, entry) => sum + (typeof entry.value === "number" ? entry.value : 0), 0);
        const eventEntries = (() => {
          try {
            return perf.getEntriesByType("event");
          } catch {
            return [];
          }
        })();
        const inpCandidate = eventEntries.reduce(
          (best, entry) => !best || (toNumber(entry.duration) ?? 0) > (toNumber(best.duration) ?? 0) ? entry : best,
          void 0
        );
        return {
          available: true,
          supportedEntryTypes: supported,
          navigation: entries("navigation"),
          paint: entries("paint"),
          largestContentfulPaint: entries("largest-contentful-paint").at(-1),
          cumulativeLayoutShift: Number(cls.toFixed(4)),
          interactionToNextPaintCandidate: inpCandidate ? jsonish(inpCandidate) : void 0,
          metricPolicy: "Snapshot only; no third-party analytics or ABG-operated telemetry endpoint."
        };
      };
      const inspectSpa = () => {
        const nav = win.navigation;
        const entries = typeof nav?.entries === "function" ? nav.entries().slice(-opts.limit).map(jsonish) : [];
        return {
          url: ctx.win.location.href,
          referrer: ctx.doc.referrer,
          historyLength: ctx.win.history.length,
          navigationApiAvailable: !!nav,
          currentEntry: nav?.currentEntry ? jsonish(nav.currentEntry) : void 0,
          entries,
          pushStateEvents: entries.length > 0 ? "Reported through the browser Navigation API" : "No Navigation API entries available without pre-page-load instrumentation"
        };
      };
      return {
        url: ctx.win.location.href,
        title: ctx.doc.title,
        kind: opts.kind,
        constraints: [
          "Uses browser-exposed runtime hooks only.",
          "Does not inject framework patches, mutate components, or install telemetry.",
          "Missing hooks return explicit unavailable results."
        ],
        react: opts.kind === "react" || opts.kind === "all" ? inspectReact() : void 0,
        webVitals: opts.kind === "web-vitals" || opts.kind === "all" ? inspectWebVitals() : void 0,
        spa: opts.kind === "spa" || opts.kind === "all" ? inspectSpa() : void 0
      };
    }
  );
}
function normalizeFrameworkKind(value) {
  if (value === "react") return "react";
  if (value === "web-vitals" || value === "vitals") return "web-vitals";
  if (value === "spa" || value === "navigation") return "spa";
  if (value === "all" || value === void 0 || value === null || value === "") return "all";
  throw new GatewayError(
    "bad_framework_kind",
    "framework kind must be react, web-vitals, spa, or all"
  );
}
function readNetworkFilters(params) {
  const urlPattern = typeof params.urlPattern === "string" ? params.urlPattern : void 0;
  const urlRegex = typeof params.urlRegex === "string" ? params.urlRegex : void 0;
  const method = typeof params.method === "string" ? params.method.toUpperCase() : void 0;
  const statusMin = typeof params.statusMin === "number" ? params.statusMin : void 0;
  const statusMax = typeof params.statusMax === "number" ? params.statusMax : void 0;
  const typeSet = typeof params.type === "string" ? new Set(
    params.type.split(",").map((part) => part.trim().toLowerCase()).filter(Boolean)
  ) : void 0;
  return { urlPattern, urlRegex, method, statusMin, statusMax, typeSet };
}
function readHARLimit(params) {
  return typeof params.limit === "number" ? Math.max(1, Math.min(1e3, params.limit)) : 200;
}
function publicNetworkFilters(filters) {
  return {
    urlPattern: filters.urlPattern,
    urlRegex: filters.urlRegex,
    method: filters.method,
    statusMin: filters.statusMin,
    statusMax: filters.statusMax,
    types: filters.typeSet ? Array.from(filters.typeSet) : void 0
  };
}
function networkEntryMatches(entry, filters, requireResponse = false) {
  if (filters.urlPattern && !globMatch(filters.urlPattern, entry.url)) return false;
  if (filters.urlRegex && !new RegExp(filters.urlRegex).test(entry.url)) return false;
  if (filters.method && entry.method.toUpperCase() !== filters.method) return false;
  if (filters.statusMin !== void 0 && (entry.status ?? 0) < filters.statusMin) return false;
  if (filters.statusMax !== void 0 && (entry.status ?? 0) > filters.statusMax) return false;
  if (filters.typeSet && entry.type && !filters.typeSet.has(entry.type)) return false;
  if (filters.typeSet && !entry.type) return false;
  if (requireResponse) return entry.status !== void 0 || entry.errorText !== void 0;
  return true;
}
function publicNetworkEntry(entry) {
  const { startTime: _startTime, ...publicEntry } = entry;
  return publicEntry;
}
function networkEntryToHAR(entry, pageId) {
  const time = entry.durationMs ?? 0;
  const responseSize = entry.encodedDataLength ?? -1;
  const content = {
    size: responseSize,
    mimeType: entry.mimeType ?? "",
    comment: "Response body omitted by ABG metadata-only HAR redaction."
  };
  return {
    pageref: pageId,
    startedDateTime: entry.ts,
    time,
    request: {
      method: entry.method,
      url: entry.url,
      httpVersion: "HTTP/1.1",
      cookies: [],
      headers: [],
      queryString: queryStringPairs(entry.url),
      headersSize: -1,
      bodySize: 0,
      comment: "Request headers, cookies, authorization data, and body omitted by ABG redaction."
    },
    response: {
      status: entry.status ?? 0,
      statusText: entry.statusText ?? (entry.errorText ? "Failed" : ""),
      httpVersion: "HTTP/1.1",
      cookies: [],
      headers: entry.mimeType ? [{ name: "content-type", value: entry.mimeType }] : [],
      content,
      redirectURL: "",
      headersSize: -1,
      bodySize: responseSize,
      comment: "Sensitive response headers and body omitted by ABG redaction."
    },
    cache: {},
    timings: {
      blocked: -1,
      dns: -1,
      connect: -1,
      send: 0,
      wait: time,
      receive: 0,
      ssl: -1
    },
    comment: entry.errorText ? `Network failed: ${entry.errorText}` : "Metadata-only ABG HAR entry."
  };
}
function queryStringPairs(rawUrl) {
  try {
    const url = new URL(rawUrl);
    return Array.from(url.searchParams.entries()).map(([name, value]) => ({ name, value }));
  } catch {
    return [];
  }
}
function readNetworkBodyMaxBytes(params) {
  return typeof params.maxBytes === "number" ? Math.max(0, Math.min(262144, params.maxBytes)) : 16384;
}
async function getResponseBodyPreview(tabId, requestId, maxBytes) {
  const result = await browser2.debugger.sendCommand({ tabId }, "Network.getResponseBody", {
    requestId
  });
  const bytes = new TextEncoder().encode(result.body);
  const truncated = bytes.length > maxBytes;
  const preview = result.base64Encoded ? result.body.slice(0, maxBytes) : new TextDecoder().decode(bytes.slice(0, maxBytes));
  return {
    value: preview,
    base64Encoded: result.base64Encoded,
    encodedBytes: bytes.length,
    maxBytes,
    truncated
  };
}
async function waitForNetworkResponse(tabId, params) {
  const filters = readNetworkFilters(params);
  const timeoutMs = typeof params.timeoutMs === "number" ? Math.max(1, Math.min(3e5, params.timeoutMs)) : 3e4;
  const body = params.body === true;
  const maxBytes = readNetworkBodyMaxBytes(params);
  const started = Date.now();
  while (Date.now() - started <= timeoutMs) {
    const match = (networkBuffers.get(tabId) ?? []).slice().reverse().find((entry) => networkEntryMatches(entry, filters, true));
    if (match) {
      const response = publicNetworkEntry(match);
      if (body && match.requestId && match.status !== void 0) {
        try {
          response.body = await getResponseBodyPreview(tabId, match.requestId, maxBytes);
        } catch (error) {
          response.bodyError = error instanceof Error ? error.message : String(error);
        }
      }
      return {
        ok: true,
        mode: "wait_for_response",
        elapsedMs: Date.now() - started,
        response
      };
    }
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  return {
    ok: false,
    error: "timeout",
    mode: "wait_for_response",
    timeoutMs,
    filters: {
      urlPattern: filters.urlPattern,
      urlRegex: filters.urlRegex,
      method: filters.method,
      statusMin: filters.statusMin,
      statusMax: filters.statusMax,
      types: filters.typeSet ? Array.from(filters.typeSet) : void 0
    }
  };
}
function normalizeSandboxStorageKind(value) {
  if (value === "localStorage" || value === "local-storage") return "local-storage";
  if (value === "sessionStorage" || value === "session-storage") return "session-storage";
  throw new GatewayError(
    "bad_storage_kind",
    "storage kind must be local-storage or session-storage"
  );
}
async function sandboxSetViewport(tabId, params) {
  const width = typeof params.width === "number" ? Math.max(1, Math.min(4096, params.width)) : 0;
  const height = typeof params.height === "number" ? Math.max(1, Math.min(4096, params.height)) : 0;
  if (width <= 0 || height <= 0) {
    throw new GatewayError("bad_viewport", "width and height must be positive numbers");
  }
  const deviceScaleFactor = typeof params.deviceScaleFactor === "number" ? Math.max(0.1, Math.min(5, params.deviceScaleFactor)) : 1;
  const mobile = params.mobile === true;
  await attachDebugger(tabId);
  await browser2.debugger.sendCommand({ tabId }, "Emulation.setDeviceMetricsOverride", {
    width,
    height,
    deviceScaleFactor,
    mobile
  });
  return { ok: true, action: "viewport", width, height, deviceScaleFactor, mobile };
}
async function sandboxClearViewport(tabId) {
  await attachDebugger(tabId);
  await browser2.debugger.sendCommand({ tabId }, "Emulation.clearDeviceMetricsOverride");
  return { ok: true, action: "viewport-clear" };
}
async function sandboxStorage(tabId, storageKind, key, value) {
  return runFrameScript(
    tabId,
    void 0,
    { storageKind, key, value },
    (ctx, opts) => {
      const storage = opts.storageKind === "local-storage" ? ctx.win.localStorage : ctx.win.sessionStorage;
      if (opts.value === void 0) {
        const existed = storage.getItem(opts.key) !== null;
        storage.removeItem(opts.key);
        return {
          ok: true,
          action: "storage-delete",
          storageKind: opts.storageKind,
          key: opts.key,
          existed
        };
      }
      storage.setItem(opts.key, opts.value);
      return {
        ok: true,
        action: "storage-set",
        storageKind: opts.storageKind,
        key: opts.key,
        valueBytes: new TextEncoder().encode(opts.value).byteLength
      };
    }
  );
}
async function sandboxCreateTab(tabId, url) {
  const source = await browser2.tabs.get(tabId);
  const created = await browser2.tabs.create({ url, windowId: source.windowId, active: true });
  return { ok: true, action: "tab-create", tabId: created.id, url: created.url ?? url };
}
async function sandboxCloseTab(targetTabId) {
  const target = permittedTabs.get(targetTabId);
  if (target?.accessMode !== "all_tabs") {
    throw new GatewayError(
      "sandbox_tab_required",
      "tab-close is limited to tabs shared through sandbox all-tabs mode"
    );
  }
  await browser2.tabs.remove(targetTabId);
  return { ok: true, action: "tab-close", targetTabId };
}
async function clickSelector(tabId, selector, frame) {
  return runFrameScript(tabId, frame, { selector }, (ctx, opts) => {
    const el = ctx.doc.querySelector(opts.selector);
    if (!el) return { found: false };
    el.click();
    return { found: true, tag: el.tagName, frame: ctx.frame };
  });
}
async function clickAt(tabId, x, y) {
  await attachDebugger(tabId);
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
    type: "mouseMoved",
    x,
    y,
    button: "none"
  });
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
    type: "mousePressed",
    x,
    y,
    button: "left",
    clickCount: 1
  });
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
    type: "mouseReleased",
    x,
    y,
    button: "left",
    clickCount: 1
  });
  return { ok: true };
}
async function doubleClickSelector(tabId, selector, frame) {
  await attachDebugger(tabId);
  const point = await resolvePoint(tabId, { kind: "selector", selector, frame });
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
    type: "mouseMoved",
    x: point.x,
    y: point.y,
    button: "none"
  });
  for (const clickCount of [1, 2]) {
    await browser2.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
      type: "mousePressed",
      x: point.x,
      y: point.y,
      button: "left",
      clickCount
    });
    await browser2.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
      type: "mouseReleased",
      x: point.x,
      y: point.y,
      button: "left",
      clickCount
    });
  }
  return { ok: true, selector, x: point.x, y: point.y };
}
async function hoverSelector(tabId, selector, frame) {
  await attachDebugger(tabId);
  const point = await resolvePoint(tabId, { kind: "selector", selector, frame });
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
    type: "mouseMoved",
    x: point.x,
    y: point.y,
    button: "none"
  });
  return { ok: true, selector, x: point.x, y: point.y };
}
async function selectOption(tabId, selector, choice, frame) {
  return runFrameScript(
    tabId,
    frame,
    { selector, value: choice.value, label: choice.label },
    (ctx, opts) => {
      const select = ctx.doc.querySelector(opts.selector);
      if (!select) return { ok: false, found: false };
      if (!(select instanceof HTMLSelectElement)) {
        return { ok: false, found: true, error: "not_select" };
      }
      const before = Array.from(select.selectedOptions).map((option2) => option2.value);
      const options = Array.from(select.options);
      const option = options.find(
        (candidate) => opts.value !== void 0 ? candidate.value === opts.value : candidate.textContent?.replace(/\s+/g, " ").trim() === opts.label
      );
      if (!option) {
        return {
          ok: false,
          found: true,
          error: "option_not_found",
          selectedValues: before
        };
      }
      for (const candidate of options) {
        candidate.selected = candidate === option;
      }
      const after = Array.from(select.selectedOptions).map((selected) => selected.value);
      const changed = before.join("\0") !== after.join("\0");
      if (changed) {
        select.dispatchEvent(new Event("input", { bubbles: true }));
        select.dispatchEvent(new Event("change", { bubbles: true }));
      }
      return {
        ok: true,
        found: true,
        changed,
        selectedValues: after,
        selectedLabels: Array.from(select.selectedOptions).map(
          (selected) => (selected.textContent ?? "").replace(/\s+/g, " ").trim()
        ),
        frame: ctx.frame
      };
    }
  );
}
async function setChecked(tabId, selector, checked, frame) {
  return runFrameScript(tabId, frame, { selector, checked }, (ctx, opts) => {
    const input = ctx.doc.querySelector(opts.selector);
    if (!input) return { ok: false, found: false };
    if (!(input instanceof HTMLInputElement)) {
      return { ok: false, found: true, error: "not_input" };
    }
    const type = input.type.toLowerCase();
    if (type !== "checkbox" && type !== "radio") {
      return { ok: false, found: true, type, error: "not_checkable" };
    }
    const before = input.checked;
    if (before !== opts.checked) {
      input.checked = opts.checked;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    }
    return {
      ok: true,
      found: true,
      type,
      before,
      after: input.checked,
      changed: before !== input.checked,
      frame: ctx.frame
    };
  });
}
async function clickDescribedElement(tabId, id, params) {
  const described = await describeElements(tabId, {
    tabId,
    all: params.all,
    grid: params.grid,
    frame: readFrameParam(params),
    limit: typeof params.limit === "number" ? Math.max(params.limit, id + 1) : Math.max(80, id + 1)
  });
  const elements = described.elements;
  const target = elements.find((element) => element.id === id);
  if (!target?.bbox) return { ok: false, id };
  const x = target.bbox.x + target.bbox.w / 2;
  const y = target.bbox.y + target.bbox.h / 2;
  await clickAt(tabId, x, y);
  return { ok: true, id, x, y };
}
function readDragPoint(params, prefix) {
  const selector = prefix === "from" ? params?.fromSelector : params?.toSelector;
  const frame = readFrameParam(params);
  if (typeof selector === "string" && selector.length > 0)
    return { kind: "selector", selector, frame };
  const x = prefix === "from" ? params?.fromX : params?.toX;
  const y = prefix === "from" ? params?.fromY : params?.toY;
  if (typeof x === "number" && typeof y === "number") return { kind: "coords", x, y };
  throw new Error(`${prefix} selector or coordinates required`);
}
function describeDragPoint(point) {
  return point.kind === "selector" ? `selector ${quoteForIntent(point.selector)}` : `(${point.x}, ${point.y})`;
}
async function resolvePoint(tabId, point) {
  if (point.kind === "coords") return { x: point.x, y: point.y };
  const result = await runFrameScript(
    tabId,
    point.frame,
    { selector: point.selector },
    (ctx, opts) => {
      const el = ctx.doc.querySelector(opts.selector);
      if (!el) return null;
      const rect = el.getBoundingClientRect();
      return {
        x: ctx.offsetX + rect.left + rect.width / 2,
        y: ctx.offsetY + rect.top + rect.height / 2
      };
    }
  );
  if (!result)
    throw new GatewayError("selector_not_found", `selector not found: ${point.selector}`);
  return result;
}
async function drag(tabId, from, to, steps) {
  await attachDebugger(tabId);
  const fromPoint = await resolvePoint(tabId, from);
  const toPoint = await resolvePoint(tabId, to);
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
    type: "mouseMoved",
    x: fromPoint.x,
    y: fromPoint.y,
    button: "none"
  });
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
    type: "mousePressed",
    x: fromPoint.x,
    y: fromPoint.y,
    button: "left",
    buttons: 1,
    clickCount: 1
  });
  for (let i = 1; i <= steps; i++) {
    const t = i / steps;
    const x = fromPoint.x + (toPoint.x - fromPoint.x) * t;
    const y = fromPoint.y + (toPoint.y - fromPoint.y) * t;
    await browser2.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
      type: "mouseMoved",
      x,
      y,
      button: "left",
      buttons: 1
    });
    await new Promise((resolve) => setTimeout(resolve, 16));
  }
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
    type: "mouseReleased",
    x: toPoint.x,
    y: toPoint.y,
    button: "left",
    buttons: 0,
    clickCount: 1
  });
  return { ok: true, from: fromPoint, to: toPoint, steps };
}
async function fillField(tabId, selector, value, dryRun, frame, options = {}) {
  const frameResult = await runFrameScript(
    tabId,
    frame,
    { selector, value, dryRun, auditDiff: options.auditDiff === true },
    (ctx, opts) => {
      const sel = opts.selector;
      const val = opts.value;
      const previewOnly = opts.dryRun === true;
      const el = ctx.doc.querySelector(sel);
      if (!el) return { ok: false, found: false };
      const kindOf = (target) => {
        if (target instanceof HTMLInputElement) return "input";
        if (target instanceof HTMLTextAreaElement) return "textarea";
        if (target.isContentEditable) return "contenteditable";
        if (target.getAttribute("role") === "textbox") return "role-textbox";
        return "unsupported";
      };
      const currentText = (target) => {
        if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
          return target.value;
        }
        return target.textContent ?? "";
      };
      const currentSnapshot = (target) => {
        const text = currentText(target);
        if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
          return { text };
        }
        return { text, html: target.innerHTML };
      };
      const dispatchReplacementEvents = (target, text, inputType) => {
        const beforeInput = new InputEvent("beforeinput", {
          bubbles: true,
          cancelable: true,
          inputType,
          data: text
        });
        target.dispatchEvent(beforeInput);
        target.dispatchEvent(
          new InputEvent("input", {
            bubbles: true,
            inputType,
            data: text
          })
        );
        target.dispatchEvent(new Event("change", { bubbles: true }));
      };
      const selectEditableContents = (target) => {
        target.focus({ preventScroll: true });
        const range = ctx.doc.createRange();
        range.selectNodeContents(target);
        const selection = ctx.win.getSelection();
        selection?.removeAllRanges();
        selection?.addRange(range);
      };
      const kind = kindOf(el);
      if (kind === "unsupported") {
        return { ok: false, found: true, kind, replacementLength: val.length };
      }
      const beforeSnapshot = opts.auditDiff === true && !previewOnly ? currentSnapshot(el) : void 0;
      const withAuditDiff = (result2) => {
        if (!beforeSnapshot) return result2;
        return {
          ...result2,
          auditDiffSource: {
            before: beforeSnapshot,
            after: currentSnapshot(el)
          }
        };
      };
      const beforeLength = currentText(el).length;
      if (previewOnly) {
        return {
          ok: true,
          found: true,
          kind,
          dryRun: true,
          beforeLength,
          replacementLength: val.length,
          strategy: "preview",
          frame: ctx.frame
        };
      }
      if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
        const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        el.focus({ preventScroll: true });
        try {
          el.setSelectionRange(0, el.value.length);
        } catch {
        }
        el.dispatchEvent(
          new InputEvent("beforeinput", {
            bubbles: true,
            cancelable: true,
            inputType: "insertReplacementText",
            data: val
          })
        );
        const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
        if (setter) setter.call(el, val);
        else el.value = val;
        el.dispatchEvent(
          new InputEvent("input", {
            bubbles: true,
            inputType: "insertReplacementText",
            data: val
          })
        );
        el.dispatchEvent(new Event("change", { bubbles: true }));
        return withAuditDiff({
          ok: true,
          found: true,
          kind,
          beforeLength,
          afterLength: el.value.length,
          replacementLength: val.length,
          strategy: "valueSetter",
          frame: ctx.frame
        });
      }
      selectEditableContents(el);
      el.dispatchEvent(
        new InputEvent("beforeinput", {
          bubbles: true,
          cancelable: true,
          inputType: "insertReplacementText",
          data: val
        })
      );
      const inserted = document.execCommand("insertText", false, val);
      if (!inserted || currentText(el) !== val) {
        el.textContent = val;
        dispatchReplacementEvents(el, val, "insertReplacementText");
        return withAuditDiff({
          ok: true,
          found: true,
          kind,
          beforeLength,
          afterLength: currentText(el).length,
          replacementLength: val.length,
          strategy: "textContentFallback",
          frame: ctx.frame
        });
      }
      el.dispatchEvent(
        new InputEvent("input", {
          bubbles: true,
          inputType: "insertReplacementText",
          data: val
        })
      );
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return withAuditDiff({
        ok: true,
        found: true,
        kind,
        beforeLength,
        afterLength: currentText(el).length,
        replacementLength: val.length,
        strategy: "selectionReplacement",
        frame: ctx.frame
      });
    }
  );
  const { auditDiffSource, ...result } = frameResult;
  if (!auditDiffSource) return result;
  return {
    ...result,
    auditDiff: createAuditDiff(auditDiffSource.before, auditDiffSource.after, {
      excerptChars: options.auditDiffExcerptChars
    })
  };
}
async function pasteText(tabId, selector, value, frame) {
  const focusResult = await focusEditableElement(tabId, selector, frame);
  if (!focusResult.found || !focusResult.focused) {
    return {
      ok: false,
      found: focusResult.found,
      focused: focusResult.focused,
      pasted: false,
      viaClipboardFallback: false,
      pasteStrategy: null
    };
  }
  const viaClipboardFallback = await writeClipboardText(tabId, value);
  if (viaClipboardFallback) {
    await focusEditableElement(tabId, selector, frame);
  }
  await dispatchPasteShortcut(tabId);
  let pasted = await editableTextIncludes(tabId, selector, value, frame);
  if (pasted) {
    return {
      ok: true,
      found: true,
      focused: true,
      pasted,
      viaClipboardFallback,
      pasteStrategy: "native"
    };
  }
  await insertTextWithExecCommand(tabId, selector, value, frame);
  pasted = await editableTextIncludes(tabId, selector, value, frame);
  if (pasted) {
    return {
      ok: true,
      found: true,
      focused: true,
      pasted,
      viaClipboardFallback,
      pasteStrategy: "execCommand"
    };
  }
  await dispatchClipboardPasteEvent(tabId, selector, value, frame);
  pasted = await editableTextIncludes(tabId, selector, value, frame);
  return {
    ok: true,
    found: true,
    focused: true,
    pasted,
    viaClipboardFallback,
    pasteStrategy: pasted ? "clipboardEvent" : null
  };
}
async function pasteRichClipboard(tabId, selector, frame) {
  if (selector) {
    const focusResult = await focusElement(tabId, selector, frame);
    if (!focusResult.found || !focusResult.focused) {
      return {
        ok: false,
        found: focusResult.found,
        focused: focusResult.focused,
        tag: focusResult.tag,
        activeTag: focusResult.activeTag
      };
    }
    await dispatchPasteShortcut(tabId);
    return { ok: true, ...focusResult };
  }
  await dispatchPasteShortcut(tabId);
  return { ok: true };
}
async function clearEditable(tabId, selector, frame) {
  const focusResult = await focusEditableElement(tabId, selector, frame);
  if (!focusResult.found || !focusResult.focused) {
    return {
      ok: false,
      found: focusResult.found,
      focused: focusResult.focused,
      cleared: false,
      clearStrategy: null
    };
  }
  await clearWithExecCommand(tabId, selector, frame);
  if (await editableTextEmpty(tabId, selector, frame)) {
    return {
      ok: true,
      found: true,
      focused: true,
      cleared: true,
      clearStrategy: "execCommand"
    };
  }
  await clearWithSelectionRange(tabId, selector, frame);
  if (await editableTextEmpty(tabId, selector, frame)) {
    return {
      ok: true,
      found: true,
      focused: true,
      cleared: true,
      clearStrategy: "selectionRange"
    };
  }
  await clearWithSyntheticInput(tabId, selector, frame);
  if (await editableTextEmpty(tabId, selector, frame)) {
    return {
      ok: true,
      found: true,
      focused: true,
      cleared: true,
      clearStrategy: "syntheticInput"
    };
  }
  await dispatchSelectAllBackspaceShortcut(tabId);
  const cleared = await editableTextEmpty(tabId, selector, frame);
  return {
    ok: true,
    found: true,
    focused: true,
    cleared,
    clearStrategy: cleared ? "keyboardShortcut" : null
  };
}
async function focusElement(tabId, selector, frame) {
  return runFrameScript(tabId, frame, { selector }, (ctx, opts) => {
    const el = ctx.doc.querySelector(opts.selector);
    if (!el) return { found: false, focused: false };
    el.focus({ preventScroll: true });
    const active = ctx.doc.activeElement;
    return {
      found: true,
      focused: active === el || el.contains(active),
      tag: el.tagName.toLowerCase(),
      activeTag: active?.tagName.toLowerCase(),
      frame: ctx.frame
    };
  });
}
async function focusEditableElement(tabId, selector, frame) {
  return runFrameScript(tabId, frame, { selector }, (ctx, opts) => {
    const el = ctx.doc.querySelector(opts.selector);
    if (!el) return { found: false, focused: false };
    const editable = el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el.isContentEditable || el.getAttribute("role") === "textbox";
    if (!editable) return { found: false, focused: false };
    el.focus({ preventScroll: true });
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      const end = el.value.length;
      try {
        el.setSelectionRange(end, end);
      } catch {
      }
    } else if (el.isContentEditable) {
      const range = ctx.doc.createRange();
      range.selectNodeContents(el);
      range.collapse(false);
      const selection = ctx.win.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
    }
    return {
      found: true,
      focused: ctx.doc.activeElement === el || el.contains(ctx.doc.activeElement)
    };
  });
}
async function clearWithExecCommand(tabId, selector, frame) {
  await runFrameScript(tabId, frame, { selector }, (ctx, opts) => {
    const el = ctx.doc.querySelector(opts.selector);
    if (!el) return;
    el.focus({ preventScroll: true });
    ctx.doc.execCommand("selectAll");
    ctx.doc.execCommand("delete");
  });
}
async function clearWithSelectionRange(tabId, selector, frame) {
  await runFrameScript(tabId, frame, { selector }, (ctx, opts) => {
    const el = ctx.doc.querySelector(opts.selector);
    if (!el) return;
    el.focus({ preventScroll: true });
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      try {
        el.setSelectionRange(0, el.value.length);
      } catch {
      }
    } else if (el.isContentEditable || el.getAttribute("role") === "textbox") {
      const range = ctx.doc.createRange();
      range.selectNodeContents(el);
      const selection = ctx.win.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
    }
    ctx.doc.execCommand("delete");
  });
}
async function clearWithSyntheticInput(tabId, selector, frame) {
  await runFrameScript(tabId, frame, { selector }, (ctx, opts) => {
    const el = ctx.doc.querySelector(opts.selector);
    if (!el) return;
    el.focus({ preventScroll: true });
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      try {
        el.setSelectionRange(0, el.value.length);
      } catch {
      }
    } else if (el.isContentEditable || el.getAttribute("role") === "textbox") {
      const range = ctx.doc.createRange();
      range.selectNodeContents(el);
      const selection = ctx.win.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
    }
    const beforeInput = new InputEvent("beforeinput", {
      bubbles: true,
      cancelable: true,
      inputType: "deleteContent",
      data: null
    });
    const canceled = !el.dispatchEvent(beforeInput);
    if (!canceled && (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement)) {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (setter) setter.call(el, "");
      else el.value = "";
    }
    el.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContent" }));
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
  });
}
async function writeClipboardText(tabId, value) {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(value);
      return false;
    }
  } catch {
  }
  const [res] = await browser2.scripting.executeScript({
    target: { tabId },
    func: (text) => {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.setAttribute("readonly", "true");
      textarea.style.position = "fixed";
      textarea.style.left = "-9999px";
      textarea.style.top = "0";
      document.documentElement.appendChild(textarea);
      textarea.focus();
      textarea.select();
      const copied = document.execCommand("copy");
      textarea.remove();
      return copied;
    },
    args: [value]
  });
  if (!res?.result) {
    throw new GatewayError("clipboard_write_failed", "failed to write text to the clipboard");
  }
  return true;
}
async function dispatchSelectAllBackspaceShortcut(tabId) {
  await attachDebugger(tabId);
  const isMac = /Mac/i.test(navigator.platform);
  const modifierKey = isMac ? "Meta" : "Control";
  const modifierCode = isMac ? "MetaLeft" : "ControlLeft";
  const modifierMask = isMac ? 4 : 2;
  const modifierVirtualKey = isMac ? 91 : 17;
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyDown",
    key: modifierKey,
    code: modifierCode,
    windowsVirtualKeyCode: modifierVirtualKey,
    nativeVirtualKeyCode: modifierVirtualKey,
    modifiers: modifierMask
  });
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyDown",
    key: "a",
    code: "KeyA",
    windowsVirtualKeyCode: 65,
    nativeVirtualKeyCode: 65,
    modifiers: modifierMask
  });
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyUp",
    key: "a",
    code: "KeyA",
    windowsVirtualKeyCode: 65,
    nativeVirtualKeyCode: 65,
    modifiers: modifierMask
  });
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyUp",
    key: modifierKey,
    code: modifierCode,
    windowsVirtualKeyCode: modifierVirtualKey,
    nativeVirtualKeyCode: modifierVirtualKey,
    modifiers: 0
  });
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyDown",
    key: "Backspace",
    code: "Backspace",
    windowsVirtualKeyCode: 8,
    nativeVirtualKeyCode: 8,
    modifiers: 0
  });
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyUp",
    key: "Backspace",
    code: "Backspace",
    windowsVirtualKeyCode: 8,
    nativeVirtualKeyCode: 8,
    modifiers: 0
  });
}
async function dispatchPasteShortcut(tabId) {
  await attachDebugger(tabId);
  const isMac = /Mac/i.test(navigator.platform);
  const modifierKey = isMac ? "Meta" : "Control";
  const modifierCode = isMac ? "MetaLeft" : "ControlLeft";
  const modifierMask = isMac ? 4 : 2;
  const modifierVirtualKey = isMac ? 91 : 17;
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyDown",
    key: modifierKey,
    code: modifierCode,
    windowsVirtualKeyCode: modifierVirtualKey,
    nativeVirtualKeyCode: modifierVirtualKey,
    modifiers: modifierMask
  });
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyDown",
    key: "v",
    code: "KeyV",
    windowsVirtualKeyCode: 86,
    nativeVirtualKeyCode: 86,
    modifiers: modifierMask
  });
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyUp",
    key: "v",
    code: "KeyV",
    windowsVirtualKeyCode: 86,
    nativeVirtualKeyCode: 86,
    modifiers: modifierMask
  });
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyUp",
    key: modifierKey,
    code: modifierCode,
    windowsVirtualKeyCode: modifierVirtualKey,
    nativeVirtualKeyCode: modifierVirtualKey,
    modifiers: 0
  });
}
async function insertTextWithExecCommand(tabId, selector, value, frame) {
  await runFrameScript(tabId, frame, { selector, value }, (ctx, opts) => {
    const el = ctx.doc.querySelector(opts.selector);
    if (!el) return;
    el.focus({ preventScroll: true });
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      const end = el.value.length;
      try {
        el.setSelectionRange(end, end);
      } catch {
      }
    } else if (el.isContentEditable) {
      const range = ctx.doc.createRange();
      range.selectNodeContents(el);
      range.collapse(false);
      const selection = ctx.win.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
    }
    ctx.doc.execCommand("insertText", false, opts.value);
  });
}
async function dispatchClipboardPasteEvent(tabId, selector, value, frame) {
  await runFrameScript(tabId, frame, { selector, value }, (ctx, opts) => {
    const el = ctx.doc.querySelector(opts.selector);
    if (!el) return;
    el.focus({ preventScroll: true });
    const clipboardData = new DataTransfer();
    clipboardData.setData("text/plain", opts.value);
    const event = new ClipboardEvent("paste", {
      bubbles: true,
      cancelable: true,
      clipboardData
    });
    el.dispatchEvent(event);
  });
}
async function editableTextIncludes(tabId, selector, value, frame) {
  if (value.length === 0) return true;
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const text = await readEditableText(tabId, selector, frame).catch(() => "");
    if (text.includes(value)) return true;
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  return false;
}
async function editableTextEmpty(tabId, selector, frame) {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const text = await readEditableText(tabId, selector, frame).catch(() => "");
    if (text.trim().length === 0) return true;
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  return false;
}
async function readEditableText(tabId, selector, frame) {
  return runFrameScript(tabId, frame, { selector }, (ctx, opts) => {
    const el = ctx.doc.querySelector(opts.selector);
    if (!el) return "";
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) return el.value;
    return el.textContent ?? "";
  });
}
async function replaceDom(tabId, selector, html, frame) {
  return runFrameScript(tabId, frame, { selector, html }, (ctx, opts) => {
    const target = ctx.doc.querySelector(opts.selector);
    if (!target) return { found: false, inserted: 0, selector: opts.selector };
    const template = ctx.doc.createElement("template");
    template.innerHTML = opts.html.trim();
    const nodes = Array.from(template.content.childNodes);
    if (nodes.length === 0) return { found: false, inserted: 0, selector: opts.selector };
    target.replaceWith(...nodes);
    return {
      found: true,
      inserted: nodes.length,
      selector: opts.selector,
      frame: ctx.frame
    };
  });
}
async function uploadFile(tabId, selector, files, frame) {
  if (frame) {
    throw new GatewayError(
      "unsupported_frame_upload",
      "upload currently supports top-document input[type=file] only; use a top-document selector or file a frame upload follow-up"
    );
  }
  if (!await browser2.extension.isAllowedFileSchemeAccess()) {
    const failure = describeFileAttachFailure("Not allowed");
    throw new GatewayError(failure.code, failure.message);
  }
  await attachDebugger(tabId);
  const documentNode = await browser2.debugger.sendCommand({ tabId }, "DOM.getDocument", {
    depth: -1,
    pierce: true
  });
  const queryResult = await browser2.debugger.sendCommand({ tabId }, "DOM.querySelector", {
    nodeId: documentNode.root.nodeId,
    selector
  });
  if (!queryResult.nodeId) {
    throw new GatewayError("selector_not_found", `selector not found: ${selector}`);
  }
  const described = await browser2.debugger.sendCommand({ tabId }, "DOM.describeNode", {
    nodeId: queryResult.nodeId
  });
  const attrs = described.node.attributes ?? [];
  const attrMap = /* @__PURE__ */ new Map();
  for (let i = 0; i < attrs.length; i += 2) {
    const key = attrs[i];
    const value = attrs[i + 1];
    if (key !== void 0 && value !== void 0) attrMap.set(key.toLowerCase(), value);
  }
  if (described.node.nodeName.toLowerCase() !== "input" || attrMap.get("type")?.toLowerCase() !== "file") {
    throw new GatewayError("not_file_input", "selector does not point to input[type=file]");
  }
  if (files.length > 1 && attrMap.get("multiple") === void 0) {
    throw new GatewayError(
      "single_file_input",
      `selector points to a single-file input but ${files.length} files were given; the input needs the "multiple" attribute to accept more than one file`
    );
  }
  const backendNodeId = described.node.backendNodeId;
  const target = backendNodeId !== void 0 ? { backendNodeId } : { nodeId: queryResult.nodeId };
  try {
    await browser2.debugger.sendCommand({ tabId }, "DOM.setFileInputFiles", {
      ...target,
      files
    });
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    const failure = describeFileAttachFailure(detail);
    throw new GatewayError(failure.code, failure.message);
  }
  const [res] = await browser2.scripting.executeScript({
    target: { tabId },
    func: (sel) => {
      const el = document.querySelector(sel);
      if (!el) return { files: 0 };
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return { files: el.files?.length ?? 0 };
    },
    args: [selector]
  });
  return { ok: true, selector, files: res?.result?.files ?? 0 };
}
async function typeText(tabId, text) {
  await attachDebugger(tabId);
  for (const ch of text) {
    await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
      type: "keyDown",
      key: ch
    });
    await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
      type: "char",
      text: ch,
      unmodifiedText: ch
    });
    await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
      type: "keyUp",
      key: ch
    });
  }
  return { ok: true };
}
async function keyboardInsertText(tabId, text) {
  await attachDebugger(tabId);
  await browser2.debugger.sendCommand({ tabId }, "Input.insertText", { text });
  return { ok: true, insertedBytes: new TextEncoder().encode(text).byteLength };
}
var EXEC_COMMAND_ALLOWLIST = /* @__PURE__ */ new Set(["insertText", "delete", "selectAll", "undo", "redo"]);
function isAllowedExecCommand(value) {
  return typeof value === "string" && EXEC_COMMAND_ALLOWLIST.has(value);
}
async function execCommand(tabId, command, value) {
  const valueBytes = value === void 0 ? 0 : new TextEncoder().encode(value).byteLength;
  const [res] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (commandName, commandValue) => {
      const allowed = ["insertText", "delete", "selectAll", "undo", "redo"];
      if (!allowed.includes(commandName)) {
        return {
          ok: false,
          command: commandName,
          valueBytes: 0
        };
      }
      const active = document.activeElement;
      const activeElement = active ? active.tagName.toLowerCase() : void 0;
      const ok = commandValue === void 0 ? document.execCommand(commandName) : document.execCommand(commandName, false, commandValue);
      return {
        ok,
        command: commandName,
        valueBytes: commandValue === void 0 ? 0 : new TextEncoder().encode(commandValue).byteLength,
        activeElement
      };
    },
    args: [command, value]
  });
  return res?.result ?? { ok: false, command, valueBytes };
}
var KEY_CODE_MAP = {
  Enter: "Enter",
  Tab: "Tab",
  Escape: "Escape",
  Backspace: "Backspace",
  Delete: "Delete",
  ArrowUp: "ArrowUp",
  ArrowDown: "ArrowDown",
  ArrowLeft: "ArrowLeft",
  ArrowRight: "ArrowRight",
  Home: "Home",
  End: "End",
  PageUp: "PageUp",
  PageDown: "PageDown",
  " ": "Space",
  Space: "Space"
};
function modifiersToBitmask(modifiers) {
  let mask = 0;
  for (const m of modifiers) {
    const lc = m.toLowerCase();
    if (lc === "alt") mask |= 1;
    else if (lc === "ctrl") mask |= 2;
    else if (lc === "cmd" || lc === "meta") mask |= 4;
    else if (lc === "shift") mask |= 8;
  }
  return mask;
}
async function keyPress(tabId, key, code, modifiers) {
  await attachDebugger(tabId);
  const mods = modifiersToBitmask(modifiers);
  const resolvedCode = code ?? KEY_CODE_MAP[key] ?? (key.length === 1 ? `Key${key.toUpperCase()}` : key);
  const resolvedKey = key === "Space" ? " " : key;
  const base = { key: resolvedKey, code: resolvedCode, modifiers: mods };
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyDown",
    ...base
  });
  if (resolvedKey.length === 1) {
    await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
      type: "char",
      text: resolvedKey,
      ...base
    });
  }
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type: "keyUp",
    ...base
  });
  return { ok: true };
}
async function keyEdge(tabId, type, key, code, modifiers) {
  await attachDebugger(tabId);
  const mods = modifiersToBitmask(modifiers);
  const resolvedCode = code ?? KEY_CODE_MAP[key] ?? (key.length === 1 ? `Key${key.toUpperCase()}` : key);
  const resolvedKey = key === "Space" ? " " : key;
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", {
    type,
    key: resolvedKey,
    code: resolvedCode,
    modifiers: mods
  });
  return { ok: true, type };
}
async function waitFor(tabId, params) {
  const sleepMs = typeof params.sleepMs === "number" ? params.sleepMs : void 0;
  if (sleepMs !== void 0) {
    await new Promise((r) => setTimeout(r, Math.max(0, sleepMs)));
    return { ok: true, mode: "sleep", ms: sleepMs };
  }
  const timeoutMs = typeof params.timeoutMs === "number" ? params.timeoutMs : 1e4;
  const frame = readFrameParam(params);
  const text = typeof params.text === "string" ? params.text : void 0;
  if (text !== void 0) {
    return waitUntil(tabId, "text", timeoutMs, async () => {
      return runFrameScript(
        tabId,
        frame,
        { text },
        (ctx, opts) => (ctx.doc.body?.innerText ?? ctx.doc.documentElement.innerText ?? "").includes(opts.text)
      );
    });
  }
  const urlPattern = typeof params.urlPattern === "string" ? params.urlPattern : void 0;
  if (urlPattern !== void 0) {
    return waitUntil(tabId, "url", timeoutMs, async () => {
      const tab = await browser2.tabs.get(tabId);
      return globMatch(urlPattern, tab.url ?? "");
    });
  }
  const loadState = typeof params.loadState === "string" ? params.loadState : void 0;
  if (loadState !== void 0) {
    if (!["networkidle", "load", "domcontentloaded"].includes(loadState)) {
      throw new GatewayError(
        "bad_params",
        "loadState must be one of networkidle, load, or domcontentloaded"
      );
    }
    await attachDebugger(tabId);
    return waitUntil(
      tabId,
      "load",
      timeoutMs,
      async () => {
        if (loadState === "networkidle") return (activeNetworkRequests.get(tabId)?.size ?? 0) === 0;
        const [res] = await browser2.scripting.executeScript({
          target: { tabId },
          func: (state) => {
            if (state === "domcontentloaded")
              return document.readyState === "interactive" || document.readyState === "complete";
            return document.readyState === "complete";
          },
          args: [loadState]
        });
        return res?.result === true;
      },
      loadState === "networkidle" ? 500 : 0
    );
  }
  const predicate = typeof params.predicate === "string" ? params.predicate : void 0;
  if (predicate !== void 0) {
    return waitUntil(tabId, "predicate", timeoutMs, async () => {
      return runFrameScript(tabId, frame, { predicate }, (ctx, opts) => {
        const evaluate = ctx.win.eval;
        return Boolean(evaluate.call(ctx.win, opts.predicate));
      }).catch(() => false);
    });
  }
  const selector = typeof params.selector === "string" ? params.selector : void 0;
  if (!selector) throw new Error("wait_for needs --selector or --ms");
  const hidden = params.hidden === true;
  const pollMs = 200;
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const visible = await runFrameScript(tabId, frame, { selector }, (ctx, opts) => {
      const el = ctx.doc.querySelector(opts.selector);
      if (!el) return false;
      const rect = el.getBoundingClientRect();
      const style = getComputedStyle(el);
      const visible2 = rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
      return visible2;
    });
    const matches = hidden ? !visible : visible;
    if (matches) {
      return {
        ok: true,
        mode: "selector",
        found: true,
        elapsedMs: Date.now() - start,
        selector
      };
    }
    await new Promise((r) => setTimeout(r, pollMs));
  }
  return { ok: false, error: "timeout", mode: "selector", timeoutMs };
}
async function waitUntil(_tabId, mode, timeoutMs, predicate, stableMs = 0) {
  const pollMs = 200;
  const start = Date.now();
  let stableSince = null;
  while (Date.now() - start < timeoutMs) {
    const matches = await predicate();
    if (matches) {
      if (stableMs === 0) return { ok: true, mode, elapsedMs: Date.now() - start };
      stableSince = stableSince ?? Date.now();
      if (Date.now() - stableSince >= stableMs) {
        return { ok: true, mode, elapsedMs: Date.now() - start };
      }
    } else {
      stableSince = null;
    }
    await new Promise((r) => setTimeout(r, pollMs));
  }
  return { ok: false, error: "timeout", mode, timeoutMs };
}
async function runApprovedEval(tabId, params) {
  const settings = await getSettings();
  if (!settings.evalEnabled) {
    throw new GatewayError(
      "eval_disabled",
      "Approved JavaScript eval is disabled. Enable it in the ABG extension popup before running abg eval."
    );
  }
  const script = typeof params.script === "string" ? params.script : "";
  if (script.trim().length === 0) throw new Error("script required");
  const maxBytes = typeof params.maxBytes === "number" ? Math.max(1, Math.min(EVAL_HARD_MAX_BYTES, Math.floor(params.maxBytes))) : EVAL_DEFAULT_MAX_BYTES;
  const approvalMode = settings.trustedAutomationEnabled ? "trusted-automation" : "per-call";
  const approvalPopup = settings.trustedAutomationEnabled ? "skipped" : "shown";
  if (!settings.trustedAutomationEnabled) {
    if (params.approve !== true) {
      throw new GatewayError(
        "approval_required",
        "abg eval requires --approve unless Trusted automation / AutoMode is enabled in the ABG extension popup."
      );
    }
    const approval = await requestOperationApproval(
      "eval_script",
      tabId,
      `Run approved JavaScript eval (${new TextEncoder().encode(script).byteLength} bytes).`,
      script
    );
    if (approval.decision !== "allow") {
      throw new GatewayError("user_denied", approval.message);
    }
  }
  await attachDebugger(tabId);
  const expression = `(${evalPageFunction.toString()})(${JSON.stringify(script)}, ${maxBytes})`;
  const res = await browser2.debugger.sendCommand({ tabId }, "Runtime.evaluate", {
    expression,
    awaitPromise: true,
    returnByValue: true
  });
  if (res.exceptionDetails) {
    throw new GatewayError(
      "eval_failed",
      res.exceptionDetails.exception?.description ?? res.exceptionDetails.text
    );
  }
  const tab = await browser2.tabs.get(tabId);
  const value = res.result?.value;
  if (!value) {
    throw new GatewayError("eval_failed", "eval returned no result");
  }
  return {
    ...value,
    tabId,
    url: tab.url ?? "",
    title: tab.title ?? "",
    approval: {
      mode: approvalMode,
      approver: "local_extension_user",
      approvedAt: (/* @__PURE__ */ new Date()).toISOString(),
      popup: approvalPopup
    }
  };
}
function evalPageFunction(source, maxBytes) {
  const typeOf = (value) => {
    if (value === null) return "null";
    if (Array.isArray(value)) return "array";
    if (typeof Node !== "undefined" && value instanceof Node) return "dom-node";
    return typeof value;
  };
  const seen = /* @__PURE__ */ new WeakSet();
  const sanitize = (value, depth) => {
    if (value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
      return value;
    }
    if (typeof value === "undefined") return { __abgType: "undefined" };
    if (typeof value === "bigint") return { __abgType: "bigint", value: String(value) };
    if (typeof value === "symbol") return { __abgType: "symbol", value: String(value) };
    if (typeof value === "function") {
      const candidate = value;
      return { __abgType: "function", name: candidate.name ?? "" };
    }
    if (typeof Node !== "undefined" && value instanceof Node) {
      const element = value instanceof Element ? value : void 0;
      return {
        __abgType: "dom-node",
        nodeType: value.nodeType,
        nodeName: value.nodeName,
        id: element?.id || void 0,
        className: element?.className || void 0,
        text: value.textContent?.replace(/\s+/g, " ").trim().slice(0, 200) || void 0
      };
    }
    if (typeof value !== "object" || value === null) return String(value);
    if (seen.has(value)) return { __abgType: "circular" };
    seen.add(value);
    if (depth >= 6) return { __abgType: "max-depth", type: typeOf(value) };
    if (Array.isArray(value)) {
      const items = value.slice(0, 100).map((item) => sanitize(item, depth + 1));
      if (value.length > items.length) {
        items.push({ __abgType: "truncated-items", omitted: value.length - items.length });
      }
      return items;
    }
    const out = {};
    const keys = Object.keys(value);
    for (const key of keys.slice(0, 100)) {
      try {
        out[key] = sanitize(value[key], depth + 1);
      } catch (e) {
        out[key] = {
          __abgType: "property-error",
          message: e instanceof Error ? e.message : String(e)
        };
      }
    }
    if (keys.length > 100) out.__abgTruncatedKeys = keys.length - 100;
    return out;
  };
  const run = async () => {
    try {
      const globalEval = globalThis.eval;
      return await globalEval(source);
    } catch (e) {
      if (!(e instanceof SyntaxError)) throw e;
      const AsyncFunction = Object.getPrototypeOf(async () => {
      }).constructor;
      try {
        return await AsyncFunction(`"use strict";
return (${source});`)();
      } catch (expressionError) {
        if (!(expressionError instanceof SyntaxError)) throw expressionError;
      }
      return await AsyncFunction(`"use strict";
${source}`)();
    }
  };
  return run().then((value) => {
    const sanitized = sanitize(value, 0);
    const json = JSON.stringify(sanitized);
    const jsonBytes = new TextEncoder().encode(json).byteLength;
    const summary = {
      type: typeOf(value),
      jsonBytes,
      maxBytes,
      truncated: jsonBytes > maxBytes
    };
    if (jsonBytes > maxBytes) {
      return {
        ok: false,
        error: "result_too_large",
        message: `Eval result is ${jsonBytes} bytes, which exceeds the ${maxBytes} byte cap.`,
        resultSummary: summary
      };
    }
    return {
      ok: true,
      value: sanitized,
      resultSummary: summary
    };
  });
}
async function scrollTab(tabId, deltaX, deltaY, atX, atY) {
  await attachDebugger(tabId);
  let cursorX = atX;
  let cursorY = atY;
  if (cursorX === void 0 || cursorY === void 0) {
    const layout = await browser2.debugger.sendCommand({ tabId }, "Page.getLayoutMetrics");
    const vp = layout.cssVisualViewport ?? { clientWidth: 800, clientHeight: 600 };
    cursorX = cursorX ?? vp.clientWidth / 2;
    cursorY = cursorY ?? vp.clientHeight / 2;
  }
  await browser2.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", {
    type: "mouseWheel",
    x: cursorX,
    y: cursorY,
    deltaX,
    deltaY
  });
  return { ok: true, deltaX, deltaY, x: cursorX, y: cursorY };
}
async function scrollElement(tabId, selector, deltaX, deltaY, steps, frame) {
  return runFrameScript(tabId, frame, { selector, deltaX, deltaY, steps }, (ctx, opts) => {
    const el = ctx.doc.querySelector(opts.selector);
    if (!el) {
      return {
        ok: false,
        found: false,
        selector: opts.selector,
        deltaX: opts.deltaX,
        deltaY: opts.deltaY,
        steps: opts.steps
      };
    }
    for (let i = 0; i < opts.steps; i += 1) {
      el.scrollBy({ left: opts.deltaX, top: opts.deltaY, behavior: "auto" });
    }
    return {
      ok: true,
      found: true,
      selector: opts.selector,
      deltaX: opts.deltaX,
      deltaY: opts.deltaY,
      steps: opts.steps,
      scrollLeft: el.scrollLeft,
      scrollTop: el.scrollTop,
      scrollWidth: el.scrollWidth,
      scrollHeight: el.scrollHeight,
      clientWidth: el.clientWidth,
      clientHeight: el.clientHeight
    };
  });
}
async function scrollElementIntoView(tabId, selector, frame) {
  return runFrameScript(tabId, frame, { selector }, (ctx, opts) => {
    const el = ctx.doc.querySelector(opts.selector);
    if (!el) return { ok: false, found: false, selector: opts.selector };
    el.scrollIntoView({ block: "center", inline: "center", behavior: "auto" });
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    const visible = rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none" && rect.bottom >= 0 && rect.right >= 0 && rect.top <= ctx.win.innerHeight && rect.left <= ctx.win.innerWidth;
    return {
      ok: true,
      found: true,
      selector: opts.selector,
      frame: ctx.frame,
      box: {
        x: Math.round(ctx.offsetX + rect.left),
        y: Math.round(ctx.offsetY + rect.top),
        width: Math.round(rect.width),
        height: Math.round(rect.height)
      },
      visible
    };
  });
}
browser2.runtime.onMessage.addListener((rawMsg, sender, sendResponse) => {
  (async () => {
    if (isRecord(rawMsg) && rawMsg.type === "stream_dom_mutation" && sender.tab?.id) {
      emitStreamEvent(sender.tab.id, {
        kind: "dom_mutation",
        count: typeof rawMsg.count === "number" ? rawMsg.count : 0,
        url: typeof rawMsg.url === "string" ? rawMsg.url : void 0,
        title: typeof rawMsg.title === "string" ? rawMsg.title : void 0
      });
      sendResponse({ type: "ok" });
      return;
    }
    if (isRecord(rawMsg) && typeof rawMsg.type === "string" && rawMsg.type.startsWith("abg_offscreen_")) {
      handleOffscreenEvent(rawMsg);
      sendResponse({ type: "ok" });
      return;
    }
    const msg = parseRuntimeMessage(rawMsg);
    if (!msg) {
      const reply2 = { type: "error", message: "unknown message" };
      sendResponse(reply2);
      return;
    }
    sendResponse(await handleRuntimeMessage(msg));
  })().catch((e) => {
    const reply2 = {
      type: "error",
      message: e instanceof Error ? e.message : String(e)
    };
    sendResponse(reply2);
  });
  return true;
});
async function handleRuntimeMessage(msg) {
  if (msg.type === "get_state") {
    await reconcileAllTabsAccess();
    const [activeTab, incognitoAccessAllowed, allTabsAccess] = await Promise.all([
      browser2.tabs.get(msg.tabId).catch(() => void 0),
      isIncognitoAccessAllowed(),
      allTabsAccessState()
    ]);
    const sharedTabs = [];
    for (const [tabId, p] of permittedTabs) {
      sharedTabs.push({ tabId, title: p.title, url: p.url, accessMode: p.accessMode });
    }
    const annotationState = permittedTabs.has(msg.tabId) ? await manageAnnotationMode(msg.tabId, { action: "list" }).catch(() => ({
      ok: true,
      enabled: false,
      count: 0,
      annotations: []
    })) : { ok: true, enabled: false, count: 0, annotations: [] };
    return {
      type: "state",
      permitted: permittedTabs.has(msg.tabId),
      wsConnected,
      activeTab: {
        incognito: activeTab?.incognito === true,
        incognitoAccessAllowed
      },
      sharedTabs,
      allTabsAccess,
      personalDataAccess: await personalDataAccessState(),
      settings: await getSettings(),
      annotationState: {
        enabled: annotationState.enabled,
        count: annotationState.count
      }
    };
  }
  if (msg.type === "permit") {
    await permitTab(msg.tabId);
    return { type: "ok" };
  }
  if (msg.type === "revoke") {
    await revokeTab(msg.tabId, "user_revoked");
    return { type: "ok" };
  }
  if (msg.type === "set_operations_require_approval") {
    await setOperationsRequireApproval(msg.value);
    return { type: "ok" };
  }
  if (msg.type === "set_eval_enabled") {
    await setEvalEnabled(msg.value);
    return { type: "ok" };
  }
  if (msg.type === "set_trusted_automation_enabled") {
    await setTrustedAutomationEnabled(msg.value);
    return { type: "ok" };
  }
  if (msg.type === "set_profile_label") {
    await setProfileLabel(msg.value);
    return { type: "ok" };
  }
  if (msg.type === "set_gateway_websocket_url") {
    await setGatewayWebSocketUrl(msg.value);
    return { type: "ok" };
  }
  if (msg.type === "set_all_tabs_access") {
    await setAllTabsAccessEnabled(msg.value);
    return { type: "ok" };
  }
  if (msg.type === "set_bookmarks_access") {
    await setBookmarksAccessEnabled(msg.value);
    return { type: "ok" };
  }
  if (msg.type === "set_reading_list_access") {
    await setReadingListAccessEnabled(msg.value);
    return { type: "ok" };
  }
  if (msg.type === "annotation_action") {
    if (!permittedTabs.has(msg.tabId)) {
      return { type: "error", message: "tab is not shared with ABG" };
    }
    await attachDebugger(msg.tabId);
    await manageAnnotationMode(msg.tabId, { action: msg.action });
    return { type: "ok" };
  }
  if (msg.type === "get_approval_request") {
    const pending = pendingApprovals.get(msg.approvalId);
    if (!pending) {
      return { type: "error", message: "approval request not found" };
    }
    return { type: "approval_request", request: pending.request };
  }
  const resolved = finalizeApproval(
    msg.approvalId,
    resolutionForDecision(msg.decision, msg.streamId)
  );
  if (!resolved) {
    return { type: "error", message: "approval request not found" };
  }
  return { type: "ok" };
}
function parseRuntimeMessage(rawMsg) {
  if (!isRecord(rawMsg) || typeof rawMsg.type !== "string") return null;
  if (rawMsg.type === "get_state" && typeof rawMsg.tabId === "number") {
    return { type: "get_state", tabId: rawMsg.tabId };
  }
  if (rawMsg.type === "permit" && typeof rawMsg.tabId === "number") {
    return { type: "permit", tabId: rawMsg.tabId };
  }
  if (rawMsg.type === "revoke" && typeof rawMsg.tabId === "number") {
    return { type: "revoke", tabId: rawMsg.tabId };
  }
  if (rawMsg.type === "set_operations_require_approval" && typeof rawMsg.value === "boolean") {
    return { type: "set_operations_require_approval", value: rawMsg.value };
  }
  if (rawMsg.type === "set_eval_enabled" && typeof rawMsg.value === "boolean") {
    return { type: "set_eval_enabled", value: rawMsg.value };
  }
  if (rawMsg.type === "set_trusted_automation_enabled" && typeof rawMsg.value === "boolean") {
    return { type: "set_trusted_automation_enabled", value: rawMsg.value };
  }
  if (rawMsg.type === "set_profile_label" && typeof rawMsg.value === "string") {
    return { type: "set_profile_label", value: rawMsg.value };
  }
  if (rawMsg.type === "set_gateway_websocket_url" && typeof rawMsg.value === "string") {
    return { type: "set_gateway_websocket_url", value: rawMsg.value };
  }
  if (rawMsg.type === "set_all_tabs_access" && typeof rawMsg.value === "boolean") {
    return { type: "set_all_tabs_access", value: rawMsg.value };
  }
  if (rawMsg.type === "set_bookmarks_access" && typeof rawMsg.value === "boolean") {
    return { type: "set_bookmarks_access", value: rawMsg.value };
  }
  if (rawMsg.type === "set_reading_list_access" && typeof rawMsg.value === "boolean") {
    return { type: "set_reading_list_access", value: rawMsg.value };
  }
  if (rawMsg.type === "annotation_action" && typeof rawMsg.tabId === "number" && isAnnotationAction(rawMsg.action)) {
    return { type: "annotation_action", tabId: rawMsg.tabId, action: rawMsg.action };
  }
  if (rawMsg.type === "get_approval_request" && typeof rawMsg.approvalId === "string") {
    return { type: "get_approval_request", approvalId: rawMsg.approvalId };
  }
  if (rawMsg.type === "approval_decision" && typeof rawMsg.approvalId === "string" && isApprovalDecision(rawMsg.decision)) {
    return {
      type: "approval_decision",
      approvalId: rawMsg.approvalId,
      decision: rawMsg.decision,
      streamId: typeof rawMsg.streamId === "string" ? rawMsg.streamId : void 0
    };
  }
  return null;
}
function isRecord(value) {
  return typeof value === "object" && value !== null;
}
function isApprovalDecision(value) {
  return value === "allow" || value === "deny" || value === "timeout";
}
function isAnnotationAction(value) {
  return value === "start" || value === "stop" || value === "clear" || value === "list" || value === "add_region" || value === "add_selector";
}
function readAnnotationCommand(params) {
  const action = isAnnotationAction(params?.action) ? params.action : "list";
  return {
    action,
    selector: typeof params?.selector === "string" ? params.selector : void 0,
    comment: typeof params?.comment === "string" ? params.comment : void 0,
    x: typeof params?.x === "number" ? params.x : void 0,
    y: typeof params?.y === "number" ? params.y : void 0,
    width: typeof params?.width === "number" ? params.width : void 0,
    height: typeof params?.height === "number" ? params.height : void 0
  };
}
