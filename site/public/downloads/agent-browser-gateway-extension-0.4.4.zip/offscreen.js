"use strict";
(() => {
  // src/offscreen.ts
  var active = null;
  var DEFAULT_TIMESLICE_MS = 1e3;
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    const msg = message;
    if (msg?.target !== "abg-offscreen") return void 0;
    if (msg.cmd === "start") {
      startRecording(msg).then((result) => sendResponse(result)).catch(
        (error) => sendResponse({ ok: false, error: errorMessage(error) })
      );
      return true;
    }
    if (msg.cmd === "stop") {
      stopRecording(msg).then((result) => sendResponse(result)).catch(
        (error) => sendResponse({ ok: false, error: errorMessage(error) })
      );
      return true;
    }
    return void 0;
  });
  async function startRecording(msg) {
    if (active) {
      return { ok: false, error: "a recording is already active" };
    }
    const tabConstraints = {
      audio: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: msg.streamId } },
      video: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: msg.streamId } }
    };
    const tabStream = await navigator.mediaDevices.getUserMedia(tabConstraints);
    const audioCtx = new AudioContext();
    const mixDestination = audioCtx.createMediaStreamDestination();
    const tabSource = audioCtx.createMediaStreamSource(tabStream);
    tabSource.connect(audioCtx.destination);
    tabSource.connect(mixDestination);
    let micUsed = false;
    let micStream = null;
    if (msg.withMic) {
      try {
        micStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        audioCtx.createMediaStreamSource(micStream).connect(mixDestination);
        micUsed = true;
      } catch (error) {
        console.warn("[abg-recorder] microphone unavailable:", error);
      }
    }
    const mixed = new MediaStream([
      ...tabStream.getVideoTracks(),
      ...mixDestination.stream.getAudioTracks()
    ]);
    const mime = pickMimeType();
    const recorder = new MediaRecorder(mixed, mime ? { mimeType: mime } : void 0);
    const recording = {
      recordingId: msg.recordingId,
      recorder,
      audioCtx,
      tabStream,
      micStream,
      mixed,
      mime: recorder.mimeType || mime || "video/webm",
      micUsed,
      startedAt: performance.now(),
      seq: 0,
      sendChain: Promise.resolve()
    };
    active = recording;
    recorder.ondataavailable = (event) => {
      if (event.data.size === 0) return;
      const seq = recording.seq++;
      recording.sendChain = recording.sendChain.then(() => emitChunk(recording, seq, event.data));
    };
    recorder.onerror = (event) => {
      const detail = event.error;
      emitEvent({
        type: "abg_offscreen_error",
        recordingId: recording.recordingId,
        error: detail?.message ?? "MediaRecorder error"
      });
      teardown(recording);
    };
    const [videoTrack] = tabStream.getVideoTracks();
    if (videoTrack) {
      videoTrack.onended = () => {
        if (active?.recordingId === recording.recordingId && recorder.state !== "inactive") {
          recorder.stop();
        }
      };
    }
    const stopped = new Promise((resolve) => {
      recorder.onstop = () => resolve();
    });
    void finalizeOnStop(recording, stopped);
    recorder.start(msg.timesliceMs ?? DEFAULT_TIMESLICE_MS);
    return { ok: true, micUsed, mime: recording.mime };
  }
  async function stopRecording(msg) {
    const recording = active;
    if (!recording || recording.recordingId !== msg.recordingId) {
      return { ok: false, error: "no matching active recording" };
    }
    if (recording.recorder.state !== "inactive") {
      recording.recorder.stop();
    }
    return { ok: true };
  }
  async function finalizeOnStop(recording, stopped) {
    await stopped;
    await recording.sendChain;
    const durationMs = Math.round(performance.now() - recording.startedAt);
    emitEvent({
      type: "abg_offscreen_stopped",
      recordingId: recording.recordingId,
      durationMs,
      mime: recording.mime,
      micUsed: recording.micUsed,
      chunkCount: recording.seq
    });
    teardown(recording);
  }
  async function emitChunk(recording, seq, blob) {
    const dataBase64 = await blobToBase64(blob);
    emitEvent({
      type: "abg_offscreen_chunk",
      recordingId: recording.recordingId,
      seq,
      dataBase64
    });
  }
  function emitEvent(event) {
    try {
      void chrome.runtime.sendMessage(event).catch?.(() => {
      });
    } catch {
    }
  }
  function teardown(recording) {
    if (active?.recordingId === recording.recordingId) active = null;
    for (const track of recording.mixed.getTracks()) track.stop();
    for (const track of recording.tabStream.getTracks()) track.stop();
    if (recording.micStream) for (const track of recording.micStream.getTracks()) track.stop();
    recording.audioCtx.close().catch(() => {
    });
  }
  function pickMimeType() {
    const candidates = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"];
    for (const candidate of candidates) {
      if (MediaRecorder.isTypeSupported(candidate)) return candidate;
    }
    return "";
  }
  async function blobToBase64(blob) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let binary = "";
    const chunkSize = 32768;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    return btoa(binary);
  }
  function errorMessage(error) {
    return error instanceof Error ? error.message : String(error);
  }
})();
